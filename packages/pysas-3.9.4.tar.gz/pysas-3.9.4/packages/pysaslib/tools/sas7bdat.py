#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

import math

import numpy as np
from pandas.io.sas.sas7bdat import SAS7BDATReader


def read_sas(filename, nrows=None):
    # TODO: read encoding byte from the binary file and add encoding parameter here
    reader = SAS7BDATReader(filename, encoding="ISO8859-1")
    frame = reader.read(nrows)
    if frame is None:
        frame = zero(reader)
    else:
        for col in [col for col, type in zip(frame.columns, reader._column_types) if type == b"s"]:
            frame[col].replace({math.nan: None}, inplace=True)
            frame[col] = frame[col].astype("string")
    reader.close()
    return frame


def zero(reader):
    """
    Even for zero rows data set do not return None frame, meta information is still required.
    The code adjusted directly from SAS7BDATReader
    :param reader:
    :return:
    """
    nd = reader._column_types.count(b"d")
    ns = reader._column_types.count(b"s")

    reader._string_chunk = np.empty((ns, 0), dtype=np.object)
    reader._byte_chunk = np.zeros((nd, 8 * 0), dtype=np.uint8)

    reader._current_row_in_chunk_index = 0

    return reader._chunk_to_dataframe()
