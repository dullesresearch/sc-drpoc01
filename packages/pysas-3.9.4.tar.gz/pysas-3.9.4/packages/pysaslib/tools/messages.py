import logging
import time

import traceback

logger: logging.Logger = None
catch: bool = False


class LogOptions:
    columns = False


def init(log_step=None, columns=None, catch=False):
    global logger
    globals()['catch'] = catch
    if log_step:
        LogOptions.columns = columns
        logging.basicConfig(level=logging.INFO, format='%(asctime)s %(name)s %(levelname)s: %(message)s')
        logger = logging.getLogger('pysas')
        logger.level = logging.INFO


real_time = time.time()
cpu_time = time.process_time()


def log(name: str, outputs, shape, schema):
    global logger
    if logger:
        try:
            global real_time, cpu_time
            for out in (outputs or []):
                df = outputs[out]
                (rows, columns) = shape(df)
                logger.info("Frame %s created with %i rows and %i columns.", out, rows, len(columns))
                if LogOptions.columns:
                    schema(df, logger)
            current_real_time = time.time()
            current_cpu_time = time.process_time()
            logger.info("Step {}: real time {:.3f}, cpu time {:.3f}".format(
                name, current_real_time - real_time, current_cpu_time - cpu_time))
            real_time = current_real_time
            cpu_time = current_cpu_time
        except:
            if not catch:
                raise
            else:
                print("==================== Exception thrown ===========")
                traceback.print_exc()
