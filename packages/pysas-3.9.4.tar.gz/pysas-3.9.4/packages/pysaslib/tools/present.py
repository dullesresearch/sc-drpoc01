import io
import sys

import pandas as pd


def get_printout(out_dic):
    strio = io.StringIO()
    printout(out_dic, file=strio)
    printed = strio.getvalue()
    strio.close()
    return printed


def get_printout_object(obj, key=None):
    strio = io.StringIO()
    printout_object(obj, key, file=strio)
    printed = strio.getvalue()
    strio.close()
    return printed


def printout_object(obj, key=None, file=sys.stdout):
    if isinstance(obj, dict):
        obj = obj[key]
    if isinstance(obj, pd.DataFrame):
        print(obj.to_string(), file=file)
    else:
        print(obj, file=file)


# PG temporary
def output(_out_: dict):
    return as_data_frame(_out_)


def as_data_frame(_out_: dict):
    if _out_['source'] == 'freq':
        return _out_['out']
    elif _out_['source'] == 'describe':
        return _out_['transposed']
    else:
        raise NotImplementedError(f"The {_out_['source']} pcocrdure not implemented yet.")


def text(_out_: dict):
    printout(_out_, file=sys.stdout)


def printout(out_dic, file=sys.stdout):
    if out_dic['source'] == 'describe':
        return _describe_print(out_dic, file=file)
    elif out_dic['source'] == 'freq':
        return _freq_print(out_dic, file=file)
    else:
        raise NotImplementedError(f"Printing of the {out_dic['source']} not implemented yet.")


def _format_dict(d):
    return " ".join(f"{k}={v}" for k, v in dict(d).items())


def _format_by_values(columns, values):
    return _format_dict(zip(columns, values))


def _describe_print(out_dic, file):
    """
    Print output from the describe procedure. The expected output is a dictionary:
    out_dic = {'source': 'describe', 'by_columns': None, 'by_values': None, 'summary': None, 'transposed': None}
    """
    if out_dic.get('source') != 'describe':
        raise ValueError("Input dictionary must have the value out_dic['source'] = 'describe'.")

    if out_dic['by_columns'] is None:
        for d in [out_dic['summary'], out_dic['transposed']]:
            if isinstance(d, pd.DataFrame):
                print(file=file)
                print_dataframe(df=d, truncate=True, n='all', file=file)
                print(file=file)
    elif out_dic['by_columns']:
        by_vals, df_by, df2 = out_dic['by_values'], out_dic['summary'], out_dic['transposed']
        if isinstance(by_vals, list):
            by_header = '\n\n{0} {{}} {0}\n'.format('-' * 0)
            # Print the list of dataframes df_by according to by (list of dict)
            for i in range(len(by_vals)):
                print(by_header.format(_format_by_values(columns=out_dic['by_columns'], values=by_vals[i])),
                      file=file)
                if isinstance(df_by[i], pd.DataFrame):
                    print_dataframe(df=df_by[i], truncate=True, n='all', file=file)
            # Print third element of the out
            if isinstance(df2, pd.DataFrame):
                print(file=file)
                print_dataframe(df=df2, truncate=True, n='all', file=file)
    else:
        print(out_dic, file=file)


def _freq_print(out_dic, file):
    """
    Print output from the freq procedure. The expected output is a dictionary:
    out_dic = {'source': 'freq', 'dataframes': None, 'messages': None, 'out': None}
    """
    if out_dic.get('source') != 'freq':
        raise ValueError("Input dictionary must have the value out_dic['source'] = 'freq'.")

    for ds, ms in zip(out_dic['dataframes'], out_dic['messages']):
        print(ms, file=file)
        if isinstance(ds, pd.DataFrame):
            print_dataframe(df=ds, truncate=True, n='all', file=file)
        elif ds:
            print(ds, file=file)
    out_ = out_dic['out']
    if isinstance(out_, pd.DataFrame):
        print(file=file)
        print_dataframe(df=out_, truncate=True, n='all', file=file)
    elif out_:
        print(file=file)
        print(out_, file=file)
    return 0


def print_dataframe(df, truncate=True, n='all', file=sys.stdout):
    str_ = df.to_string()
    if truncate:
        str_list = str_.split('\n')
        if n == 'all':
            n = len(str_list)
        str_ = '\n'.join([val.rstrip() if ix < n else val for ix, val in enumerate(str_list)])
    print(str_, file=file)


def remove_trail_spaces(x):
    return '\n'.join([val.rstrip() for val in x.split('\n')])
