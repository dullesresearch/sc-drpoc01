#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import datetime as dt
import locale
import math
import typing

import pysaslib.settings as settings
from pysaslib.informats import date as in_date
from pysaslib.informats import dateampm as in_dateampm
from pysaslib.informats import datetime as in_datetime
from pysaslib.informats import ddmmyy as in_ddmmyy
from pysaslib.informats import mmddyy as im_mmddyy
from pysaslib.informats import time as im_time
from pysaslib.informats import yymmdd as in_yymmdd
from pysaslib.informats import yymmddxw as im_yymmddxw
from pysaslib.informats import yymmxw as im_yymmxw

POWER = [pow(10, -n) for n in range(0, 33)]


def sf(width=0):
    return SF(width)


def f(width=8, decimals=0):
    return F(width, decimals)


def schar(width=1):
    return SF(width)


def date(width=7):
    return DATE(width)


# TODO does it exist?
def dateampm(width, decimals=0):
    return DATEAMPM(width, decimals)


def datetime(width=18, decimals=0):
    return DATETIME(width, decimals)


def ddmmyy(width=6):
    return DDMMYY(width)


def mmddyy(width=6):
    return MMDDYY(width)


def time(width=8, decimals=0):
    return TIME(width, decimals)


def yymmdd(width=6):
    infmt = YYMMDD(width)
    if not settings.INFORMAT_YYMMDD_CACHE_DISABLE:
        infmt.dt.set_cache(dt.datetime.strptime(settings.INFORMAT_CACHE_DATES[0], '%Y-%m-%d'),
                           dt.datetime.strptime(settings.INFORMAT_CACHE_DATES[1], '%Y-%m-%d'),
                           width)
    return infmt


def yymmddb(width=8):
    return YYMMDDx('B', width)


def yymmddc(width=8):
    return YYMMDDx('C', width)


def yymmddd(width=8):
    return YYMMDDx('D', width)


def yymmddn(width=8):
    return YYMMDDx('N', width)


def yymmddp(width=8):
    return YYMMDDx('P', width)


def yymmdds(width=8):
    return YYMMDDx('S', width)


def yymmc(width=7):
    return YYMMx('C', width)


def yymmd(width=7):
    return YYMMx('D', width)


def yymmn(width=6):
    return YYMMx('N', width)


def yymmp(width=7):
    return YYMMx('P', width)


def yymms(width=7):
    return YYMMx('S', width)


class DATE:
    def __init__(self, width):
        self.width = width
        self.dt = in_date.DATE(width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class DATEAMPM:
    def __init__(self, width, decimals):
        self.width = width
        self.dt = in_dateampm.DATEAMPM(width, decimals)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class DATETIME:
    def __init__(self, width, decimals):
        self.dt = in_datetime.DATETIME(width, decimals)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return None if not value or value == '.' else self.dt.convert_value(value)


class DDMMYY:
    def __init__(self, width):
        self.width = width
        self.dt = in_ddmmyy.DDMMYY(width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class F:
    def __init__(self, width, decimals):
        self.width = width
        self.decimals = decimals

    def input(self, value: str) -> float:
        try:
            if value:
                atof = locale.atof(value)
                if self.decimals == 0 or "." in value:
                    return atof
                else:
                    return atof * POWER[self.decimals]
            else:
                return math.nan
        except ValueError:
            return math.nan


class MMDDYY:
    def __init__(self, width):
        self.width = width
        self.dt = im_mmddyy.MMDDYY(width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class SF:
    def __init__(self, width):
        self.width = width

    def input(self, value: str) -> str:
        result = value[:self.width]
        return result if result else None


class TIME:
    def __init__(self, width, decimals):
        self.width = width
        self.decimals = decimals
        self.dt = im_time.TIME(width, decimals)

    def input(self, value: str) -> typing.Union[dt.time, None]:
        return self.dt.convert_value(value)


class YYMMDDN:
    def __init__(self, width):
        self.width = width
        self.dt = im_yymmddxw.YYMMDDxw(sep='N', width=width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class YYMMN:
    def __init__(self, width):
        self.width = width
        self.dt = im_yymmxw.YYMMxw(sep='N', width=width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class YYMMDD:
    def __init__(self, width):
        self.width = width
        self.dt = in_yymmdd.YYMMDD(width=width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class YYMMDDx:
    def __init__(self, x, width):
        self.width = width
        self.x = x
        self.dt = im_yymmddxw.YYMMDDxw(sep=x, width=width)

    def input(self, value: str) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


class YYMMx:
    def __init__(self, x, width):
        self.width = width
        self.x = x
        self.dt = im_yymmxw.YYMMxw(sep=x, width=width)

    def input(self, value) -> typing.Union[dt.date, None]:
        return self.dt.convert_value(value)


def numeric(value: str):
    try:
        value = value.strip()
        if value and value != '.':
            return locale.atof(value)
        else:
            return math.nan
    except ValueError:
        return math.nan


def character(value: str):
    """
    read string value from file, replacing empty string and '.' (single dot) with NaN
    to match the intended semantic
    """
    return None if not value or value == '.' else value
