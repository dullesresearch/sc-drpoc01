#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
class MacroProcessor():
    def put(self, name: str, value: str):
        setattr(self, name.lower(), value)
