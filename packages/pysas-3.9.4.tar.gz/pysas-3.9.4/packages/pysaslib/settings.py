"""
pysaslib configuration module
"""

INFORMAT_CACHE_DATES = ['1970-01-01', '2050-12-31']
INFORMAT_YYMMDD_CACHE_DISABLE = False
