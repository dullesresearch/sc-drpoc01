#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import pandas as pd


def concat(frames):
    left = frames[0]
    right = frames[1]
    return pd.concat([left.drop(set(left.columns).intersection(right.columns), axis=1), right], axis=1)


def log(message):
    print(message)
