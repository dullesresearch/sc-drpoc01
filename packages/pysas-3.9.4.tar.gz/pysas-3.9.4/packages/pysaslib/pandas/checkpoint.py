#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import time
from pathlib import Path
from typing import List

import pandas as pd

import pysaslib.pandas.diff as diff


class Checkpoint:

    def __init__(self, path: str, modes: List[str] = None, case: bool = True, sort: bool = False, limit: int = 10):
        """
        :param path: Path to the library of benchmark datasets
        :param modes: List of modes: "verify", "restore"
        :param case: Check case on :meth:`.verify`
        :param sort: Ignore order of rows on :meth:`.verify`
        :param limit: Maximum number of messages :meth:`.verify` prints
        """
        self.path = path
        self.modes = set(modes)
        self.case = case
        self.sort = sort
        self.limit = limit

    def run(self, actual: pd.DataFrame, libref: str, dataset: str, generation: int, tag=""):
        start = time.time()
        try:
            if "verify" in self.modes:
                self.verify(actual, libref, dataset, generation, tag)

            if "restore" in self.modes:
                return self.restore(libref, dataset, generation)
            else:
                return actual
        finally:
            elapsed = time.time() - start
            if elapsed > 10:
                print("checkpoint elapsed time (reporting if more then 10 sec): {:.2}".format(elapsed))

    def verify(self, actual: pd.DataFrame, libref: str, dataset: str, generation: int, tag: str = "",
               expected: pd.DataFrame = None, ):
        if actual is None:
            print("checkpoint", tag, "[SKIP] : (actual is None) " + libref + "." + dataset, "gen=", generation)
            return
        if expected is None:
            filename = Path(self.path) / libref.lower() / f"{dataset.lower()}_{generation:02d}.sas7bdat"
            from pysaslib.tools import sas7bdat
            expected = sas7bdat.read_sas(filename)
        messages = diff.DataFrameDiff(
            expected,
            actual,
            maximum_relative_error=1e-8,
            maximum_absolute_error_for_zero=1e-8,
            ignore_column_case=not self.case,
            ignore_metadata_differences=True,
            ignore_row_order=self.sort,
            ignore_excessive_rows=True,
            cast_to_float=True,
        ).report_plain_text(limit=self.limit)
        mismatch = any([m.startswith('MISMATCH') for m in messages])
        if mismatch:
            print("checkpoint", tag, "[FAIL] : " + libref + "." + dataset, "gen=", generation)
        else:
            print("checkpoint", tag, "[OK] : " + libref + "." + dataset, "gen=", generation)
        for msg in messages:
            print("   ", msg)

    def restore(self, libref, dataset, generation):
        filename = Path(self.path) / libref.lower() / f"{dataset.lower()}_{generation:02d}.sas7bdat"
        from pysaslib.tools import sas7bdat
        expected = sas7bdat.read_sas(filename)
        return expected
