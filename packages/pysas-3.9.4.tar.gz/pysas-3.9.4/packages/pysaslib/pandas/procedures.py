from typing import List

import pandas as pd

import pysaslib.pandas.crosstab
import pysaslib.pandas.describe
import pysaslib.pandas.transpose


def transpose(df: pd.DataFrame = None,
              groupby: List[str] = None,
              value_vars: List[str] = None,
              prefix="COL",
              names: List[str] = None):
    return pysaslib.pandas.transpose.transpose(df, groupby=groupby, value_vars=value_vars, names=names, prefix=prefix)


def contents(data):
    print("Number of rows: " + str(len(data.index)))
    for col, type in zip(data.columns, data.dtypes):
        print('{:<12}  {}'.format(col, type))


def describe(df: pd.DataFrame = None,
             select: List[str] = None,
             groupby: List[str] = None,
             class_: List[str] = None,
             statistics: List[str] = None,
             min=None,
             max=None,
             sum=None,
             mean=None,
             std=None,
             n=None,
             nmiss=None,
             missing: bool = False,
             nway: bool = False,
             autoname: bool = False):
    all_args = locals()
    _statistics_, _out_ = list(), {}
    for arg in ['min', 'max', 'sum', 'mean', 'std', 'n', 'nmiss']:
        val = all_args[arg]
        if val:
            if isinstance(val, bool) and not autoname:
                _statistics_.append(arg.upper())
            else:
                _out_[arg] = 'autoname' if autoname else dict(zip(val[0], val[1]))
    if len(_statistics_) > 0:
        statistics = _statistics_
    return pysaslib.pandas.describe.describe(df, select=select, groupby=groupby, class_=class_,
                                             missing=missing, nway=nway, args=statistics, out=_out_)


def crosstab(df: pd.DataFrame = None,
             groupby: List[str] = None,
             tables: List[List[str]] = None,
             range: bool = False,
             missing: bool = False,
             out=False,
             format_numbers=False,
             format_func=None):
    """
    :param df: input Pandas dataframe
    :param groupby: list of dataframe column for grouping
    :param tables: list of containg column names or lists [col1, col2], [col1, col2, col3]
    :param range: if True, tables=['bc1','bn2'] means first and last columns in range. SAS: tables bc1--bn2
    :param missing: if True, keep dataframe's rows containing NA values, drop otherwise
    :param out: if True, the freq procedure returns last table in tables, None otherwise
    :param format_numbers: If true, formats numerical columns as strings using the format_func
    :param format_func: function, formatting input number as string using some formatting rules. Default None.
                        If format_numbers=True and format_func=None, the best(12) format is used.
    :return:  last table if out=True, None otherwise
    """
    for t in tables:
        result=pysaslib.pandas.crosstab.crosstab(df=df,
                                             groupby=groupby,
                                             tables=t,
                                             range=range,
                                             missing=missing,
                                             out=out,
                                             format_numbers=format_numbers,
                                             format_func=format_func)
    return result