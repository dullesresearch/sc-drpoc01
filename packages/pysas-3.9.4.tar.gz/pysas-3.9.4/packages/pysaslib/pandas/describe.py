import numpy as np
import pandas as pd
import datetime


calculations = {'N': lambda z: z.count(), 'NMISS': lambda z: z.isna().sum(),
                'MEAN': lambda z: z.mean(), 'STD': lambda z: z.std(),
                'MIN': lambda z: z.min(), 'MAX': lambda z: z.max(),
                'RANGE': lambda z: z.max() - z.min(),
                'SUM': lambda z: z.sum(), 'VAR': lambda z: z.var()}

all_options = {'N': 'N', 'NMISS': 'N Miss',
               'MEAN': 'Mean', 'STD': 'Std Dev',
               'MIN': 'Minimum', 'MAX': 'Maximum',
               'RANGE': 'Range',
               'SUM': 'Sum', 'VAR': 'Variance'}


def _calc_means(df, cols, means, labels = None):
    out_list = list()
    for c in cols:
        aggs = {}
        for m in means:
            aggs[m] = calculations[m]
            if labels:
                lbl = labels.get(c)
                col_name, alias = (lbl[0], lbl[1]) if lbl else (c, None)
                out_ = [col_name, alias]
            else:
                out_ = [c]
        df_agg = df[c].agg(list(aggs.values()))
        out_list.append(out_ + df_agg.to_list())
    return out_list


def _calc_means_group(df, cols, means, labels = None):
    out_list = list()
    aggs = {m: calculations[m] for m in means}
    for c in cols:
        df_agg = df[c].agg(list(aggs.values()))
        df_agg.columns = list(aggs.keys())
        if labels:
            lbl = labels.get(c)
            col_name, alias = (lbl[0], lbl[1]) if lbl else (c, None)
            df_agg['Variable'] = col_name
            df_agg['Label'] = alias
        else:
            df_agg['Variable'] = c
        out_list.append(df_agg)
    return pd.concat(out_list)


def _get_labels(cols, allcols, chars = ['.', '_']):
    labels = {}
    for bc in allcols:
        for nc in cols:
            for c in chars:
                if nc[:len(bc)+1] == bc + c:
                    labels[nc] = (nc.replace(c, '_'), bc)
    return labels if len(labels) > 0 else None


def _get_processing_options(df, vars, args, out):
    # Input arguments
    options = [o.upper() for o in args if o.upper() in all_options.keys()] if args \
        else ['N', 'MIN',  'MAX', 'MEAN', 'STD']
    options = options + [c for c in ['N', 'NMISS'] if c not in options]

    # Numeric columns in dataframe
    all_num_cols = [c for c in df.columns if pd.api.types.is_numeric_dtype(df[c])]
    num_cols = vars if vars else all_num_cols

    # Out options
    # Example: out = {'n': 'autoname', 'std': {'var1': 'var1_s', 'var2': 'var2_s', }}, 'mean': 'autoname', }
    if out:
        out_ = {}
        for k, v in out.items():
            key = k.upper()
            if type(v) == str and v.upper() == 'AUTONAME':
                val = {col: f"{col}_{all_options[key].replace(' ','')}" for col in num_cols}
            else:
                val = v
            out_[key] = val
        out = out_
        # Options for 1st and 2nd dataframes if the out parameter specified
        out_opt_1 = ['N', 'MEAN', 'STD', 'MIN', 'MAX']
        out_opt_2 = [o for o in out.keys() if o in all_options.keys()]
        options = out_opt_2 + [c for c in ['N', 'NMISS', 'MEAN', 'STD', 'MIN', 'MAX'] if c not in out_opt_2]
    else:
        out, out_opt_1, out_opt_2 = None, None, None

    # Captions for the 1st output dataframe
    captions = ['Variable'] + [all_options[o] for o in options]
    return num_cols, all_num_cols, out, options, out_opt_1, out_opt_2, captions


def _vars_sort_order(cols, labels=None):
    num_cols = {col: i for i, col in enumerate(cols)}
    if labels:
        for col in labels.keys():
            if col in num_cols.keys():
                num_cols[labels.get(col)[0]] = num_cols[col]
    return pd.DataFrame({'col': num_cols.keys(), 'index': num_cols.values()}).sort_values('index').set_index('col')


def _process_out_list(outlist, captions=None):
    if captions:
        df = pd.DataFrame(outlist, columns=captions)
    else:
        df = pd.DataFrame(outlist)
    for c in ['N', 'N Miss', 'NMISS']:
        if c in df.columns:
            df[c] = df[c].astype(np.int)
    return df


def _query_condition(rowdict: dict) -> str:
    conds = list()
    for k, v in rowdict.items():
        if pd.isna(v):
            cond = f"(@pd.isna(`{k}`))"
        elif type(v) == str:
            cond = f"(`{k}` == '{v}')"
        elif type(v) == bool:
            cond = f"(`{k}` == {v})"
        elif isinstance(v, (datetime.date, datetime.datetime, pd.Timestamp, np.datetime64)):
            cond = f"(`{k}` == @pd.Timestamp('{pd.Timestamp(v)}'))"
        else:
            cond = f"(`{k}` == {v})"
        conds.append(cond)
    return " & ".join(conds)


def _transform_output(outdf, options, labels=None, nmiss=True, n=True, set_index=False):
    out2 = outdf.copy()
    if labels:
        out2.drop(columns='Label', inplace=True)
    for c in ['N', 'N Miss', 'NMISS']:
        if c in out2.columns:
            out2[c] = out2[c].astype(np.int)
    out2['_FREQ_'] = out2['N'] + out2['NMISS']
    out2['_TYPE_'] = 0
    out2_tf = out2[['_TYPE_', '_FREQ_']].drop_duplicates()
    out2_tf['Obs'] = 1
    out2_tf.set_index('Obs', inplace=True)
    means_list = options if nmiss else [o for o in options if o != 'NMISS']
    means_list = means_list if n else [m for m in means_list if m != 'N']
    out2 = out2[['Variable'] + means_list].set_index('Variable').transpose()
    out2.rename(columns={'Variable': '_STAT_'}, inplace=True)
    out2.reset_index(inplace=True)
    out2['Obs'] = 1
    out2.set_index('Obs')
    out2 = pd.merge(out2_tf, out2, how='inner', on='Obs')
    out2.rename(columns={'index': '_STAT_'}, inplace=True)
    out2['Obs'] = range(1, out2.shape[0] + 1)
    if set_index:
        out2.set_index('Obs', inplace=True)
    else:
        out2.index = np.empty(out2.shape[0], dtype=str)
    return out2


def _transform_output_out(df, num_cols, out, class_cols=None, stats=None):
    """
    Transform dataframe if the out parameter given
    """
    out_keys = {k.upper(): out[k] for k in out.keys()}
    filter = df['_STAT_'].isin(out_keys.keys())
    n_rows, n_stats, n_vars = df[filter].shape[0], len(stats), len(num_cols)
    n_groups = int(n_rows / n_stats)
    df_list = list()
    for g in range(n_groups):
        df_ = df.iloc[g * n_stats: (g + 1) * n_stats, :]
        df_row = pd.DataFrame(df_[['_STAT_'] + num_cols].values.reshape(1, -1))
        out2_names = ['Obs', '_TYPE_', '_FREQ_']
        for i in range(len(df_row.columns)):
            val = df_row.iloc[0, i]
            if type(val) == str and val in out_keys:
                new_names = {list(out_keys[val].keys()).index(k) + i + 1: v for k, v in out_keys[val].items()}
                out2_names = out2_names + list(new_names.values())
                df_row.rename(columns=new_names, inplace=True)
        df_row['_TYPE_'] = df_['_TYPE_'].values[0]
        df_row['_FREQ_'] = df_['_FREQ_'].values[0].astype(np.int)
        df_row['Obs'] = g + 1
        if class_cols:
            for c in class_cols:
                df_row[c] = df_[c].values[0]
        out2_names = class_cols + out2_names if class_cols else out2_names
        df_list.append(df_row[out2_names])
    # Output dataframe
    out2_ = pd.concat(df_list)
    out2_.index = np.empty(out2_.shape[0], dtype=str)
    return out2_[['Obs'] + [c for c in out2_names if c != 'Obs']]


def _transform_output_group(outdf, options, class_cols, nmiss=True, n=True):
    means_list = options if nmiss else [o for o in options if o != 'NMISS']
    means_list = means_list if n else [m for m in means_list if m != 'N']
    out2_groups = outdf.assign(_FREQ_ = lambda x: x['N'] + x['NMISS'])\
        .groupby(class_cols, dropna=False).agg({'_TYPE_': min, '_FREQ_': min})
    # Transpose data for each group
    out2_list = list()
    for row in out2_groups.reset_index()[class_cols].to_dict(orient="records"):
        qry = _query_condition(row)
        out2_ = outdf.query(qry, engine='python')
        out2_.reset_index(inplace=True)
        out2_t = out2_[['Variable'] + means_list].set_index(['Variable']).transpose()
        for c in class_cols:
            out2_t[c] = row[c]
        out2_list.append(out2_t)
    # Create output dataframe
    out2 = pd.concat(out2_list)
    out2.reset_index(inplace=True)
    out2.rename(columns={'index': '_STAT_'}, inplace=True)
    out2.set_index(class_cols, inplace=True)
    return pd.merge(out2_groups, out2, how='inner', on=class_cols).sort_index(na_position='first')


def describe(df=None,
             select=None,
             groupby=None,
             class_=None,
             missing=False,
             nway=False,
             args=None,
             out=None):
    """
    :param df: input Pandas dataframe
    :param select: list of variables in the dataframe to be selected, None means all numerical columns
    :param groupby:
    :param missing: if True, prevents obs with missing values in class vars from being discarded. Default False.
    :param nway: if True, causes only _TYPE_=3 records to be produced. Default False.
    :param args: list of means to be calculated. If None (default) all means will be calculated
    :param out: Tuple with aliases for output columns as follows:
                out = {'sum': {'vn1': 'vn1_s', 'vn2': 'vn2_s'},
                       'mean': {'vn1': 'vn1', 'vn2': 'vn2'} }
    :param outset: indicates what will be returned by this functions
                    1 - out1 - dataframe with means in separate columns
                    2 - out2 - transposed dataframe out1
                    3 - both out1 and out2
    :return: a dictionary, depending of groupby parameter:
       - if groupby is None:
          out_dic = {'source': 'describe', 'by_columns': None, 'by_values': None,
                     'summary': df1, 'transposed': df2}
       - if groupby is not None (=[col1, ..., colN]):
          out_dic = {'source': 'describe',
                     'by_columns': [col1, ..., colN],
                     'by_values': [[val11, ..., valN1], [val12, ..., valN2], ..., [val1M, ..., valNM],
                     'summary': df1, 'transposed': df2}
    """
    if isinstance(args, list):
        args = [a.upper() for a in args]
    out_dic = {'source': 'describe', 'by_columns': None, 'by_values': None, 'summary': None, 'transposed': None}
    if groupby is None and class_ is None:
        out_dic['summary'], out_dic['transposed'] = _means_(df, vars=select, by=None, class_=None,
                                                            missing=missing, nway=nway,
                                                            args=args, out=out, outset=3)
    elif groupby and class_ is None:
        out = _means_by(df, vars=select, by=groupby, class_=None,
                         missing=missing, nway=nway,
                         args=args, out=out, outset=3)
        out_dic['by_columns'] = groupby
        out_dic['by_values'] = [list(d.values()) for d in out[0]]
        out_dic['summary'] = out[1] # list of dataframes
        out_dic['transposed'] = out[2]
    elif class_ and groupby is None:
        out_dic['summary'], out_dic['transposed'] = _means_class(df, vars=select, by=None, class_=class_,
                                                                 missing=missing, nway=nway,
                                                                 args=args, out=out, outset=3)
    elif groupby and class_:
        out = _means_by_class(df, vars=select, by=groupby, class_=class_,
                               missing=missing, nway=nway,
                               args=args, out=out, outset=3)
        out_dic['by_columns'] = groupby
        out_dic['by_values'] = [list(d.values()) for d in out[0]]
        out_dic['summary'] = out[1] # list of dataframes
        out_dic['transposed'] = out[2]
    return out_dic


def _means_(df=None,
            vars=None,
            by=None,
            class_=None,
            missing=False,
            nway=False,
            args=None,
            out=None,
            outset=3):
    """
    1. Calculate means if no by and class variables specified
    Cases 01-default, 01-default-miss, 10-var
    """
    # Process input arguments
    num_cols, all_num_cols, out, options, out_opt_1, out_opt_2, captions = _get_processing_options(df, vars, args, out)
    labels = _get_labels(num_cols, all_num_cols)
    captions = (['Variable', 'Label'] if labels else ['Variable']) + options # + [all_options[o] for o in options]
    out_list = _calc_means(df=df, cols=num_cols, means=options, labels=labels)
    out1 = _process_out_list(out_list, captions=captions)
    if out:
        out1.columns = ['Variable'] + options
        out1_ = out1[['Variable'] + out_opt_1].rename(columns=all_options)
    else:
        out1_ = out1
    # Prepare out dataframes
    out1_.index = np.empty(out1_.shape[0], dtype=str)
    if outset == 1:
        return out1_.rename(columns=all_options), None
    elif outset in [2, 3]:
        out2 = _transform_output(outdf=out1, options=options, labels=labels, nmiss=False)
        if out:
            # Transform 1st dataframe into the transposed dataframe (2nd)
            out2_ = _transform_output_out(df=out2, num_cols=num_cols, out=out, class_cols=None, stats=out_opt_2)
        else:
            out2_ = out2
        if outset == 3:
            return out1_.rename(columns=all_options), out2_
        else:
            return None, out2_


def _means_by(df=None,
              vars=None,
              by=None,
              class_=None,
              missing=False,
              nway=False,
              args=None,
              out=None,
              outset=3):
    """
    2. Calculate means if by variables specified
    Cases 30-by, 31-by-miss
    """
    # Process input arguments
    num_cols, all_num_cols, out, options, out_opt_1, out_opt_2, captions = _get_processing_options(df, vars, args, out)
    group_cols = by
    num_cols = [c for c in num_cols if c not in group_cols]
    labels = _get_labels(num_cols, all_num_cols)
    captions = (['Variable', 'Label'] if labels else ['Variable']) + [all_options[o] for o in options]

    df_by = pd.DataFrame(df[group_cols]).drop_duplicates().sort_values(group_cols, na_position='first')
    out1, out2 = list(), list()
    by_dict = df_by.to_dict(orient="records")
    for row in by_dict:
        qry = _query_condition(row)
        df_ = df.query(qry, engine='python')
        df_.reset_index(inplace=True)
        out_list = _calc_means(df=df_, cols=num_cols, means=options, labels=labels)
        col_names = (['Variable', 'Label'] if labels else ['Variable']) + options
        out_df = _process_out_list(out_list, col_names)
        if out:
            out_df = out_df[['Variable'] + out_opt_1]
        out_df2 = _transform_output(outdf=out_df, options=options, labels=labels, nmiss=False)
        for c in group_cols:
            out_df2[c] = row[c]
        out_df.rename(columns=all_options, inplace=True)
        out_df.index = np.empty(out_df.shape[0], dtype=str)
        out1.append(out_df)
        out2_cols = group_cols + [c for c in list(out_df2.columns) if c not in group_cols + ['Obs']]
        out2.append(out_df2[out2_cols])

    # Prepare out dataframes
    if outset == 1:
        return by_dict, out1, None
    elif outset in [2, 3]:
        out2_ = pd.concat(out2)
        out2_.sort_values(group_cols, inplace=True, na_position='first')
        out2_cols = ['Obs'] + list(out2_.columns)
        out2_['Obs'] = range(1, out2_.shape[0] + 1)
        out2_.index = np.empty(out2_.shape[0], dtype=str)
        if outset == 3:
            return by_dict, out1, out2_[out2_cols]
        else:
            return None, None, out2_[out2_cols]


def _means_class(df=None,
                 vars=None,
                 by=None,
                 class_=None,
                 missing=False,
                 nway=False,
                 args=None,
                 out=None,
                 outset=3):
    """
    3. Calculate means if class variables specified
    Cases 40-class, 42-class-miss, 44-class-miss-miss, 45-class-nway
    """
    # Process input arguments
    group_cols = class_
    num_cols, all_num_cols, out, options, out_opt_1, out_opt_2, captions = _get_processing_options(df, vars, args, out)
    num_cols = [c for c in num_cols if c not in group_cols]
    labels = _get_labels(num_cols, all_num_cols)
    num_cols_map = _vars_sort_order(num_cols, labels)
    captions = (['Variable', 'Label'] if labels else ['Variable']) + [all_options[o] for o in options]
    nmiss_flag = True if (out and 'NMISS' in out.keys()) else False
    n_flag = True if (out and 'N' in out.keys()) or (args is None) or ('N' in args) else False
    if not missing:
        df = df.dropna(subset=group_cols)

    # Process data according to class_ variables
    out1, out2 = _process_class_data(df, class_, nway, num_cols, num_cols_map,
                                     options, labels, captions,
                                     out, out_opt_2, nmiss_flag, n_flag)
    # Prepare out dataframes
    out1_ = None
    if outset in [1, 3]:
        out1_ = pd.concat(out1)
        for c in ['N', 'NMISS']:
            out1_[c] = out1_[c].astype(np.int)
        out1_['N Obs'] = (out1_['N'] + out1_['NMISS']).astype(np.int)
        out1_.set_index(group_cols + ['N Obs', 'Variable'], inplace=True)
        if out:
            out1_list = out_opt_1
        else:
            out1_list = ['Label'] + options if labels else options
        out1_ = out1_.loc[out1_['_TYPE_'] == int(out1[-1]['_TYPE_'].max()), out1_list].rename(columns=all_options)
    if outset == 1:
        return out1_, None
    elif outset in [2, 3]:
        if labels:
            num_cols = [labels[c][0] if c in labels.keys() else c for c in num_cols]
        out2_ = pd.concat(out2)[group_cols + ['_TYPE_', '_FREQ_', '_STAT_'] + num_cols]
        if out:
            # Transform out2 dataframe according to out options:
            out2_ = _transform_output_out(df=out2_, num_cols=num_cols, out=out,
                                          class_cols=group_cols, stats=out_opt_2)
            out2_cols = out2_.columns
        else:
            out2_ = pd.concat(out2)[group_cols + ['_TYPE_', '_FREQ_', '_STAT_'] + num_cols]
            out2_cols = ['Obs'] + list(out2_.columns)
            out2_.index = np.empty(out2_.shape[0], dtype=str)
            for c in ['N', 'NMISS', '_FREQ_']:
                if c in out2_.columns:
                    out2_[c] = out2_[c].astype(np.int)
            # Sort output dataframe 2
            out2_['_STAT_order'] = out2_['_STAT_'].map(_vars_sort_order(options)['index'])
            out2_.sort_values(['_TYPE_'] + group_cols + ['_STAT_order'], inplace=True, na_position='first')
            out2_['Obs'] = range(1, out2_.shape[0] + 1)
        return out1_, out2_[out2_cols]


def _means_by_class(df=None,
                    vars=None,
                    by=None,
                    class_=None,
                    missing=False,
                    nway=False,
                    args=None,
                    out=None,
                    outset=3
                    ):
    """
    4. Calculate means if both by and class_ variables specified
    # Case 70-out-by-class
    """
    # Process input arguments
    group_cols, class_cols = by, class_
    num_cols, all_num_cols, out, options, out_opt_1, out_opt_2, captions = _get_processing_options(df, vars, args, out)
    num_cols = [c for c in num_cols if c not in group_cols + class_cols]
    labels = _get_labels(num_cols, all_num_cols)
    captions = (['Variable', 'Label'] if labels else ['Variable']) + [all_options[o] for o in options]
    nmiss_flag = True if (out and 'NMISS' in out.keys()) else False
    n_flag = True if (out and 'N' in out.keys()) or (args is None) or ('N' in args) else False
    num_cols_map = _vars_sort_order(num_cols, labels)

    df_by = pd.DataFrame(df[group_cols]).drop_duplicates().sort_values(group_cols, na_position='first')
    out1, out2 = list(), list()
    by_dict = df_by.to_dict(orient="records")
    for row in by_dict:
        qry = _query_condition(row)
        df_ = df.query(qry, engine='python')

        out1_list, out2_list = _process_class_data(df_, class_, nway, num_cols, num_cols_map,
                                                   options, labels, captions,
                                                   out, out_opt_2, nmiss_flag, n_flag)
        out_df, out_df2 = out1_list[-1], pd.concat(out2_list)

        for c in group_cols:
            out_df2[c] = row[c]
        out2_cols = group_cols + class_cols \
                    + [c for c in list(out_df2.columns) if c not in group_cols + class_cols + ['Obs']]
        out2.append(out_df2[out2_cols])
        if out:
            out1_cols = class_cols + ['Variable', 'N Obs'] + out_opt_1
        else:
            out1_cols = class_cols + ['Variable', 'N Obs'] + options
        out_df['N Obs'] = (out_df['N'] + out_df['NMISS']).astype(np.int)
        out_df = out_df[out1_cols].set_index(class_cols + ['N Obs']).rename(columns=all_options)
        out1.append(out_df)

    # Prepare out dataframes
    if outset == 1:
        return by_dict, out1, None
    elif outset in [2, 3]:
        out2_ = pd.concat(out2)[group_cols + class_cols +  ['_TYPE_', '_FREQ_', '_STAT_'] + num_cols]
        if out:
            # Transform out2 dataframe according to out options:
            out2_ = _transform_output_out(df=out2_, num_cols=num_cols, out=out,
                                          class_cols=group_cols + class_cols, stats=out_opt_2)
            out2_cols = out2_.columns
        else:
            out2_['Obs'] = range(1, out2_.shape[0] + 1)
            out2_.index = np.empty(out2_.shape[0], dtype=str)
            out2_cols = ['Obs'] + list(out2_.columns)
        if outset == 2:
            return None, None, out2_[out2_cols]
        if outset == 3:
            return by_dict, out1, out2_[out2_cols]


def _process_class_data(df, class_, nway, num_cols, num_cols_map,
                        options, labels, captions,
                        out, out_opt_2, nmiss_flag, n_flag):
    # Define groups, _TYPE_ and _WAY_ for class variables:
    n_group_vars = len(class_)
    n_types = 2 ** n_group_vars
    types = [n_types - 1] if nway else list(range(n_types))
    df_gr = pd.DataFrame({'type': types})
    df_gr['code'] = df_gr['type'].apply(lambda t: "{0:b}".format(t).rjust(n_group_vars, '0'))
    df_gr['mask'] = df_gr['code'].apply(lambda c: [int(n) for n in c])
    df_gr['way'] = df_gr['mask'].apply(lambda z: sum(z))
    df_gr['columns'] = df_gr['mask'].apply(lambda d: [(class_[i] if d[i] else None) for i in range(n_group_vars)])
    df_gr.set_index('type', inplace=True)
    num_cols_ = [labels[c][0] if c in labels.keys() else c for c in num_cols] if labels else num_cols

    # Calculate means for each _TYPE_:
    out1, out2 = list(), list()
    for t in types:
        row = df_gr.loc[t]
        if t == 0:
            group_cols = None
            out_df = _calc_means(df=df, cols=num_cols, means=options, labels=labels)
            out_cols = (['Variable', 'Label'] if labels else ['Variable']) + options
            out_df = _process_out_list(outlist=out_df, captions=out_cols)
            if 'index' in out_df.columns:
                out_df.drop(columns='index', inplace=True)
            captions_2 = list(out_df.columns)
            if out:
                cols_list = ['Variable'] + options
                for c in ['N', 'NMISS']:
                    if c not in cols_list:
                        cols_list.append(c)
                opt_list = out_opt_2
            else:
                cols_list = captions_2
                opt_list = options
            out_df2 = _transform_output(outdf=out_df[cols_list], options=opt_list, labels=labels,
                                        nmiss=nmiss_flag, n=n_flag)
            out_df['_TYPE_'] = t
            out_df['_WAY_'] = row['way']
        else:
            # Group columns
            group_cols = [c for c in df_gr.loc[t, 'columns'] if c]
            out_df = _calc_means_group(df=df.groupby(group_cols, dropna=False),
                                       cols=num_cols, means=options, labels=labels)
            captions_2 = list(out_df.columns)
            # Sort dataframe
            out_df.reset_index(inplace=True)
            out_df['Variable_order'] = out_df['Variable'].map(num_cols_map['index'])
            out_df.sort_values(group_cols + ['Variable_order'], inplace=True, na_position='first')
            out_df['_TYPE_'] = t
            out_df['_WAY_'] = row['way']
            if out:
                cols_list = out_opt_2 + group_cols + ['_TYPE_', '_WAY_', 'Variable']
                for c in ['N', 'NMISS']:
                    if c not in cols_list:
                        cols_list.append(c)
                opt_list = out_opt_2
            else:
                cols_list = captions_2 + group_cols + ['_TYPE_', '_WAY_']
                opt_list = options
            out_df2 = _transform_output_group(outdf=out_df[cols_list], options=opt_list,
                                              class_cols=group_cols, nmiss=nmiss_flag, n=n_flag)
        for c in class_:
            if c not in out_df2.columns and c not in out_df2.index.names:
                out_df2[c] = None
        out_df2.reset_index(inplace=True)
        for c in class_:
            if c not in out_df.columns and c not in out_df.index.names:
                out_df[c] = None
        for c in ['N', 'NMISS', '_FREQ_']:
            if c in out_df.columns:
                out_df[c] = out_df[c].astype(np.int)
        out1.append(out_df)
        out2.append(out_df2[class_ + ['_TYPE_', '_FREQ_', '_STAT_'] + num_cols_])
    return out1, out2
