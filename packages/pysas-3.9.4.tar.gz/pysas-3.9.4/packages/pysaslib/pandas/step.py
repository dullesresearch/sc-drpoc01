#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import inspect
import itertools
import typing

import numpy as np
import pandas as pd

import pysaslib.tools.messages as msg


def init(log_step=None, columns=None):
    msg.init(log_step, columns=columns)


def _print_schema_(df, logger):
    for col, type in zip(df.columns, df.dtypes):
        logger.info("|--%s", '{:<12}  {}'.format(col, type))


def log(name: str, outputs=()):
    msg.log(name, outputs,
            lambda df: (df.shape[0], df.columns),
            lambda df, logger: _print_schema_(df, logger))


arrays: typing.List[str] = []


def run(*, df: pd.DataFrame = None, func=None,
        in_columns: typing.List[str] = None, out_columns: typing.List[str] = None,
        groupby=None,
        split=False):
    if groupby:
        return by(df=df, func=func, in_columns=in_columns,
                  out_columns=out_columns, groupby=groupby, split=split)

    global arrays
    signature = inspect.signature(func).return_annotation
    explicit_output = str(signature) == "typing.List[tuple]"
    filter = signature == bool
    copy = df[in_columns + arrays].copy()
    for col in copy.select_dtypes('string').columns:
        copy[col] = copy[col].replace({pd.NA: None})
    if filter:
        out = df[[func(*tuple) for tuple in copy.itertuples()]]
        out.reset_index(inplace=True, drop=True)
        return out
    elif out_columns is not None:
        rows = []
        drops = []
        for tuple in copy.itertuples():
            row = func(*tuple)
            if row is not None:
                if explicit_output:
                    rows.extend(row)
                else:
                    rows.append(row)
            else:
                drops.append(tuple[0])
        if explicit_output:
            result = pd.DataFrame(data=rows,
                                  columns=(["_n_", "_output_"] if split else ["_n_"]) + out_columns)
            return match(df=df, result=result)
        else:
            out = pd.DataFrame(rows, columns=out_columns)
            overwrite = set(df.columns).intersection(out.columns)
            if drops:
                copy = df.drop(index=drops)
                copy.reset_index(inplace=True, drop=True)
            else:
                copy = df
            concat = pd.concat([copy.drop(arrays, axis=1), out.drop(overwrite, axis=1)], axis=1)
            arrays = []
            concat[list(overwrite)] = out[list(overwrite)]
            return concat
    else:
        for tuple in copy.itertuples():
            func(*tuple)


def by(
        *,
        df: pd.DataFrame,
        groupby: typing.List[str],
        func: typing.Callable,
        split: bool = False,
        in_columns: typing.List[str] = None,
        out_columns: typing.List[str] = None,
) -> pd.DataFrame:
    """Apply ``func`` to each row in a group of rows defined by ``groupby``

    :param df: The dataframe that includes columns mentioned in ``in_columns``
        and ``groupby``.
    :param groupby: The list of columns to group rows by. Order-sensitive.
        Argument ``groupby=[a, b]`` produces a different effect from
        ``groupby=[b, a]`` due to behavior of FIRST and LAST in SAS.
    :param func: The function to apply to each row within a group. Must be
        an iterator that yields tuples.
    :param split: If `True`, function ``func`` yields an additional value
        (at position 0 in the yielded tuple) that refers to the target a row
        must go into.
    :param in_columns: The columns in ``df`` that will be available inside
        ``func``. If empty, ``func`` has access only to the row number
        (``_n_``) and group delimiters (``_first_a``, ``_last_a``, ...).
    :param out_columns: The list of columns that ``func`` yields. If empty,
        ``func`` operates as a filter.
    :return: A dataframe that combines columns from ``df`` and any additional
        columns ``func`` yielded. If ``func`` yielded columns from ``df``,
        this dataframe will have the updated columns. The order of rows
        in this dataframe may be different from the order of rows in ``df``.

    Examples
    --------

    Suppose you want to apply a function to a group of rows formed by columns
    "a", ..., and "n".

    Define ``func`` as::

        # Define persistent variables
        persistent_variable_1 = None
        ...

        def func(
                _n_,
                _first_a,
                _last_a,
                ...,
                _first_n,
                _last_n,
                in_column_1,
                ...
        ) -> Generator[Tuple[str, str, str, ...], None, None]:
            # Initialize out_columns
            out_column_1, out_column_2, ... = None

            # Initialize temporary variables that persist between rows
            nonlocal persistent_variable_1
            ...

            # Group delimiters work like FIRST.i and LAST.i in SAS:
            if _first_a:
                out_column_1 = "First observation in a group by [a]"
            ...
            if _first_n:
                out_column_1 = "First observation in a group by [a, ..., n]"

            # Output to multiple targets
            if in_column_1 == "send left":
                yield "left", out_column_1, out_column_2, ...
            if in_column_1 == "send right":
                yield "right", out_column_1, out_column_2, ...

            # Yield multiple rows per iteration
            yield "forward", out_column_1, out_column_2, ...
            yield "backward", out_column_1, out_column_2, ...

    And call the function via :py:func:`by`::

        output = by(
            df=df,
            groupby=["a", ..., "n"],
            func=func,
            split=True,
            in_columns=[in_column_1, ...],
            out_columns=[out_column_1, ...],
        )

    More examples are available in :py:func:`tests.pandas.test_step.test_by`.

    """
    if not isinstance(groupby, typing.List):
        raise TypeError(f"Argument groupby must be List[str]")
    if len(groupby) == 0:
        raise ValueError(f"Argument groupby is empty")
    for c in groupby:
        if not isinstance(c, str):
            raise TypeError(f"Argument groupby must be List[str]")
    if in_columns is None:
        in_columns = list()
    if out_columns is None:
        out_columns = list()

    global arrays
    in_columns_extra = in_columns + arrays

    tmp = df[groupby].copy()
    tmp.sort_values(groupby, na_position="first", inplace=True)

    tmp["_n_"] = tmp.groupby(groupby, dropna=False).transform("cumcount") + 1

    for i in range(len(groupby)):
        groupby_i = groupby[:i + 1]
        tmp_i = tmp[groupby_i].copy()
        tmpg_i = tmp_i.groupby(groupby_i, dropna=False)
        tmp_i["_cumcount"] = tmpg_i.transform("cumcount")
        tmp_i["_cumcount_last"] = tmpg_i["_cumcount"].transform("last")

        first_name_i = "_first_" + groupby_i[-1]
        last_name_i = "_last_" + groupby_i[-1]
        tmp[first_name_i] = tmp_i["_cumcount"] == 0
        tmp[last_name_i] = tmp_i["_cumcount"] == tmp_i["_cumcount_last"]

    tmp.drop(columns=groupby, inplace=True)

    tmp = pd.merge(
        tmp,
        df[in_columns_extra],
        how="left",
        left_index=True,
        right_index=True,
    )
    for c in tmp.select_dtypes("string").columns:
        tmp[c].replace({pd.NA: None}, inplace=True)

    # Function "func" receives arguments from "row" in the following order:
    # _n_, _first_a, _last_a, _first_b, ..., _last_n, *in_columns
    func_output = [
        list(itertools.zip_longest(
            [],
            func(*row[1:]),
            fillvalue=row[0],
        ))
        for row in tmp.itertuples(index=True, name=None)
    ]
    func_output_columns = (
            ["_index"]
            + (["_output_"] if split else [])
            + out_columns
    )
    func_output = pd.DataFrame(
        [(_index, *row) for _index, row in itertools.chain(*func_output)],
        columns=func_output_columns,
    )
    func_output.set_index("_index", inplace=True)

    MS = "_modified"
    output = pd.merge(
        df,
        func_output,
        how="right",
        left_index=True,
        right_index=True,
        suffixes=[None, MS],
    )
    output.index.name = None
    output.reset_index(drop=True, inplace=True)

    def is_dtype_sas_equal(c1: pd.Series.dtype, c2: pd.Series.dtype):
        """Check if dtypes ``c1`` and ``c2`` are equal in SAS terms"""
        from pandas.core.dtypes.common import (
            is_dtype_equal,
            is_numeric_dtype,
            is_string_dtype,
        )
        if is_dtype_equal(c1, c2):
            return True
        if is_numeric_dtype(c1) and is_numeric_dtype(c2):
            return True
        if is_string_dtype(c1) and is_string_dtype(c2):
            return True
        return False

    # Replace "in_columns" that have been modified by "func"
    for c in in_columns_extra:
        mc = c + MS
        if mc in output.columns:
            if not is_dtype_sas_equal(output[c].dtype, output[mc].dtype):
                raise ValueError(
                    f"New value in column {c} must have the old data type "
                    f"({output[mc].dtype})"
                )
            output[c] = output[mc]
            output.drop(columns=[mc], inplace=True)

    return output


def merge(frames: typing.List[pd.DataFrame], by=None, how='outer', indicators=()):
    left = frames[0]
    # normalize case for the right frame  to the match the case of the left frame
    proper = dict([(n.upper(), n) for n in left.columns])
    right = adjust_capitalization(frames[1], proper)
    common = set(left.columns).intersection(right.columns)

    for v in by:
        common.discard(v)
    r = right.rename(columns={n: "#" + n for n in common})
    m = left.merge(r, how=how, on=by, indicator=bool(indicators))
    for n in common:
        m[n] = m['#' + n].combine_first(m[n])
    m.drop(columns=["#" + n for n in common], inplace=True)
    if indicators and indicators[0]:
        m[indicators[0]] = np.where((m["_merge"] == 'left_only') | (m["_merge"] == 'both'),
                                    1, 0)
    if indicators and indicators[1]:
        m[indicators[1]] = np.where((m["_merge"] == 'right_only') | (m["_merge"] == 'both'),
                                    1, 0)
    if indicators:
        m.drop(columns=["_merge"], inplace=True)
    m.reset_index(inplace=True, drop=True)
    return m


def adjust_capitalization(df: pd.DataFrame, proper) -> pd.DataFrame:
    """
    :return adjusted column capitalization according to the map proper
    """
    adjust = [n for n in df.columns if n.upper() in proper.keys() and proper[n.upper()] != n]
    return df.rename(columns=dict([(n, proper[n.upper()]) for n in adjust])) if adjust else df


def concat(frames: typing.List[pd.DataFrame]):
    """
    :param frames:
    :return: concatenated frames, similar to pd.concat, but matches columns without case sensitivity
    """
    all = itertools.chain.from_iterable([f.columns for f in frames])
    proper = dict([(n.upper(), n) for n in reversed(list(all))])
    concat = pd.concat([adjust_capitalization(df, proper) for df in frames], axis=0)
    concat.reset_index(inplace=True, drop=True)
    return concat


def match(df: pd.DataFrame, result: pd.DataFrame):
    result.set_index("_n_", inplace=True, drop=True)
    result = df.merge(result, how='right', left_index=True, right_index=True)

    # for the variable which is both input and output
    # we create a new variable with prefix '#' in the temporary frame.
    # Afterwards do some renaming and coping to maintain the order of the columns in the data frame
    duplicated = list(filter(lambda c: c.startswith('#'), result.columns))
    orig = [c[1:] for c in duplicated]

    result[orig] = result[duplicated]
    result.reset_index(inplace=True, drop=True)
    result.drop(duplicated, axis=1, inplace=True)
    return result


def array(df: pd.DataFrame, name: str, elements: typing.List[str]):
    e = df[elements]
    e.insert(0, '_', 0)
    df[name] = list(e.itertuples(index=False, name=None))
    arrays.append(name)


def prefix(df: pd.DataFrame, prefix: str) -> typing.List[str]:
    prefix = prefix.upper()
    return [f for f in list(df.columns) if f.upper().startswith(prefix)]
    if isinstance(df, pyspark.sql.DataFrame):
        return [f.name for f in list(df.schema.fields) if f.name.upper().startswith(prefix)]
