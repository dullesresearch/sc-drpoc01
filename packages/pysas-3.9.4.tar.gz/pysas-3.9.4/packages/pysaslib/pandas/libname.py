#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import abc
import json
import os

import pandas as pd

from pysaslib.tools import sas7bdat


class disk:

    def __init__(self, path: str, head: int = None):
        """
        Collections of SAS7BDAT files implementing LIBNAME functionality

        Parameters
        ----------
        path : str
             directory with SAS7BDAT files
        head : int, defaults to None
            If specified, limit the number of rows to read from SAS7BDAT file
        """
        self.__dict__["_members_"] = {}
        self.__dict__["_dirty_"] = set()
        self.__dict__["_path_"] = path
        self.__dict__["_head_"] = head

    def __getattr__(self, member: str):
        lower = member.lower()
        filename = self._path_ + "/" + member.lower() + ".sas7bdat"
        if lower in self._members_:
            return self._members_[lower]
        elif os.path.exists(filename):
            self._members_[lower] = sas7bdat.read_sas(filename, self._head_)
            return self._members_[lower]
        else:
            raise AttributeError("Data set " + filename + " does not exist.")

    def __setattr__(self, member: str, frame: pd.DataFrame):
        lower = member.lower()
        self._members_[lower] = frame
        self._dirty_.add(lower)

    # Save all newly created data frames to the external file, for example CSV
    def save(self):
        for member in self._dirty_:
            filename = self._path_ + "/" + member.lower() + ".csv"
            self._members_[member].to_csv(filename)
            pass


class database:
    __metaclass__ = abc.ABCMeta

    def __init__(self, connection=None, schema=None,
                 head: int = None):
        """
        Collections of RDBMS tables

        Parameters
        ----------
        connection : database connection
        head : int, defaults to None
            If specified, limit the number of rows to read from database
        """
        self.__dict__["_connection_"] = connection
        self.__dict__["_members_"] = {}
        self.__dict__["_dirty_"] = set()
        self.__dict__["_schema_"] = schema
        self.__dict__["_head_"] = head

    def __getattr__(self, member: str):
        lower = member.lower()
        if lower in self._members_:
            return self._members_[lower]
        else:
            prefix = self._schema_ + "." if self._schema_ else ""
            # It seems that read_sql_table quotes the table name so for case preserving databases, such as Teradata
            # read_sql_table does not work

            # Parse SQL query and get metadata:
            qry = "SELECT * FROM " + prefix + member
            trim = self.get_special_column_types(qry)

            gen = pd.read_sql_query(qry, self._connection_, chunksize=self._head_)
            df = pd.DataFrame(next(gen)) if self._head_ else gen
            for (name, type) in trim.items():
                if type == 'CHAR':
                    df[name] = df[name].str.rstrip()
                    df[name] = df[name].astype("string")
                elif type == 'VARCHAR':
                    df[name] = df[name].astype("string")
                elif type in {'BYTEINT', 'SMALLINT', 'NUMBER'}:
                    df[name] = df[name].astype('float')

            self._members_[lower] = df
            return self._members_[lower]

    @abc.abstractmethod
    def get_special_column_types(self, qry):
        pass

    def __setattr__(self, member: str, frame: pd.DataFrame):
        lower = member.lower()
        self._members_[lower] = frame
        self._dirty_.add(lower)

    # Saving to database disabled for security reasons
    def save(self):
        for member in self._dirty_:
            pass


class teradata(database):
    def __init__(self, server=None, schema=None, user=None, password=None, head: int = None):
        import sqlalchemy
        connection = sqlalchemy.create_engine("teradatasql://{}:{}@{}"
                                              .format(user, password, server))
        connection.dialect.requires_name_normalize = False
        super().__init__(connection, schema, head)

    def get_special_column_types(self, qry):
        import sqlalchemy
        con: sqlalchemy.Engine = self.__dict__["_connection_"]
        with con.raw_connection().cursor() as cur:
            cur.execute('{fn teradata_rpo(S)}{fn teradata_fake_result_sets}' + qry)
            row = cur.fetchone()
            metadata = json.loads(row[7])
            columns = dict([(col['Name'], col['TypeName']) for col in metadata])
            return columns


class oracle(database):
    def __init__(self, server=None, schema=None, user=None, password=None, path=None, head: int = None):
        import sqlalchemy
        if "/" in path:
            (server, database) = path.split("/")
            service = "{}:1521/?service_name={}".format(server, database)
        else:
            service = path
        uri = "oracle+cx_oracle://{}:{}@{}".format(user, password, service)
        connection = sqlalchemy.create_engine(uri, max_identifier_length=128)
        connection.dialect.requires_name_normalize = False
        super().__init__(connection, schema, head)

    def get_special_column_types(self, qry):
        import cx_Oracle
        with self._connection_.raw_connection().cursor() as curs:
            curs.parse(qry)
            desc = curs.description
            convert = {cx_Oracle.DB_TYPE_CHAR: 'CHAR',
                       cx_Oracle.DB_TYPE_VARCHAR: 'VARCHAR',
                       cx_Oracle.DB_TYPE_NUMBER: 'NUMBER'}
            columns = dict([(c[0], convert.get(c[1])) for c in desc if c[1] in convert.keys()])
            return columns
