#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from itertools import zip_longest
from typing import List

import numpy as np
import pandas as pd
from pandas.core.dtypes.common import is_string_dtype, is_bool_dtype, is_numeric_dtype, is_dtype_equal, \
    is_datetime64_dtype, is_timedelta64_dtype, is_float_dtype, is_object_dtype

"""
Author: Anton Tarasenko
Email: antontarasenko@gmail.com

"""


class DataFrameDiff:
    def __init__(
            self, df1: pd.DataFrame, df2: pd.DataFrame,
            ignore_metadata_differences: bool = False,
            ignore_row_order: bool = False,
            ignore_excessive_rows: bool = False,
            ignore_column_order: bool = False,
            ignore_column_case: bool = False,
            ignore_columns: List[str] = None,
            maximum_relative_error: float = 0.0,
            maximum_absolute_error_for_zero: float = 0.0,
            cast_to_float: bool = False,
            columns_in_seconds: List[str] = None,
            columns_in_days: List[str] = None,
            extended_missing_objects: bool = False,
    ):
        """
        Find differences in two dataframes

        Two dataframes are compared with fast column operations.

        :param df1: Left dataframe (also "expected", "base", "benchmark")
        :param df2: Right dataframe (also "actual", "compare")
        :param ignore_metadata_differences: Compare values in the columns that
        have the same name and data type, regardless of the metadata
        comparison results
        :param ignore_row_order: Sort rows before comparison (used in case on
        PySpark frame, where order is not guaranteed)
        :param ignore_excessive_rows: Proceed with comparison if dataframes
        have different number of rows
        :param ignore_column_order: Ignore column order
        :param ignore_column_case: Ignore column name case
        :param ignore_columns: List of columns to ignore
        :param maximum_relative_error: Threshold for relative errors in
        numeric cells
        :param maximum_absolute_error_for_zero: Threshold for relative errors
        when one cell is zero
        :param cast_to_float: Ignore type differences between columns of the
        following types: type np.bool_, all subtypes of np.number
        :param columns_in_seconds: Interpret specified columns as seconds.
        Designed for cases when a column in the left and right dataframes
        stores semantically identical datetime values under different data
        types: integer, float, datetime, or timedelta. Integer and float
        columns will be interpreted as seconds. Respective datetime and
        timedelta columns will be handled automatically.
        :param columns_in_days: Interpret specified columns as days
        :param extended_missing_objects: In case of "string" or "object"
        column, treat empty lines as missing values
        """
        self.df1 = df1.copy()
        self.df2 = df2.copy()
        self.ignore_metadata_differences = ignore_metadata_differences
        self.ignore_excessive_rows = ignore_excessive_rows
        self.ignore_column_order = ignore_column_order
        self.ignore_column_case = ignore_column_case
        self.ignore_columns = ignore_columns
        self.maximum_relative_error = maximum_relative_error
        self.maximum_absolute_error_for_zero = maximum_absolute_error_for_zero
        self.cast_to_float = cast_to_float
        self.columns_in_seconds = columns_in_seconds
        self.columns_in_days = columns_in_days
        self.extended_missing_objects = extended_missing_objects

        self.prevent_diff = False

        self.original_df1_shape = self.df1.shape
        self.original_df2_shape = self.df2.shape
        self.rows_compared = 0
        self.columns_compared = 0
        self.cells_compared = 0
        self.different_cells_found = 0

        if self.ignore_column_case:
            self.df1.rename({c: c.upper() for c in self.df1.columns.tolist()}, axis='columns', inplace=True)
            self.df2.rename({c: c.upper() for c in self.df2.columns.tolist()}, axis='columns', inplace=True)
            if self.ignore_columns:
                self.ignore_columns = [c.upper() for c in self.ignore_columns]
            if self.columns_in_seconds:
                self.columns_in_seconds = [c.upper() for c in self.columns_in_seconds]
            if self.columns_in_days:
                self.columns_in_days = [c.upper() for c in self.columns_in_days]
        if self.ignore_columns is not None:
            columns = self.ignore_columns
            if self.columns_in_seconds:
                self.columns_in_seconds = [c for c in self.columns_in_seconds if c not in columns]
            if self.columns_in_days:
                self.columns_in_days = [c for c in self.columns_in_days if c not in columns]
            self.df1.drop(columns, axis='columns', errors='ignore', inplace=True)
            self.df2.drop(columns, axis='columns', errors='ignore', inplace=True)

        # Convert datetime columns to numeric columns (convert time to nanoseconds)
        # TODO: Arbitrary period support in numerical columns (not only seconds and days)
        # TODO: Float-integer type mismatch when date and time are equal
        # TODO: Missing values support
        # Type "datetime64" supports missing values (as NaT), but "pandas.to_numeric" converts to "int64",
        # which does not support missing values. If a dataframe contains missing values in a "datetime64"
        # column, they will be converted to integer "-9223372036854775808" for further comparison.
        if self.columns_in_seconds:
            for col in self.columns_in_seconds:
                if not (col in self.df1.columns and col in self.df2.columns):
                    raise ValueError('Column not found in the dataframes: {}'.format(col))
                if is_datetime64_dtype(self.df1[col].dtype) or \
                        is_timedelta64_dtype(self.df1[col].dtype):
                    self.df1[col] = pd.to_numeric(self.df1[col])
                elif is_numeric_dtype(self.df1[col].dtype):
                    self.df1[col] = self.df1[col] * 1000000000
                if is_datetime64_dtype(self.df2[col].dtype) or \
                        is_timedelta64_dtype(self.df2[col].dtype):
                    self.df2[col] = pd.to_numeric(self.df2[col])
                elif is_numeric_dtype(self.df2[col].dtype):
                    self.df2[col] = self.df2[col] * 1000000000
        if self.columns_in_days:
            for col in self.columns_in_days:
                if not (col in self.df1.columns and col in self.df2.columns):
                    raise ValueError('Column not found in the dataframes: {}'.format(col))
                if is_datetime64_dtype(self.df1[col].dtype) or \
                        is_timedelta64_dtype(self.df1[col].dtype):
                    self.df1[col] = pd.to_numeric(self.df1[col])
                elif is_numeric_dtype(self.df1[col].dtype):
                    self.df1[col] = self.df1[col] * 1000000000 * 86400
                if is_datetime64_dtype(self.df2[col].dtype) or \
                        is_timedelta64_dtype(self.df2[col].dtype):
                    self.df2[col] = pd.to_numeric(self.df2[col])
                elif is_numeric_dtype(self.df2[col].dtype):
                    self.df2[col] = self.df2[col] * 1000000000 * 86400

        if ignore_row_order:
            # TODO: Handle interaction with label-based slicing `DataFrame.loc` in `self.__diff(from_row, to_row)`
            # Due to index reset, `__diff(from_row, to_row)` and dependents work on a range of rows
            # that is different from the range that the user intended to use.
            # TODO: Check interaction with `ignore_excessive_rows`
            # Sort is called before cutting off excessive rows with `ignore_excessive_rows`. If both options
            # are set to True, excessive rows may cause differences in two dataframes as in this example:
            # entering [3, 2, 1] and [3, 2] leads to comparison of [1, 2] and [2, 3]
            # TODO: Handle interaction with value-related arguments (relative error, extended missing objects, etc.)
            # Rows are sorted before certain value transformations. This may cause counterintuitive behavior.
            # Check `test_ignore_row_order()` for examples.
            self.df1.sort_values(by=self.df1.columns.tolist(), inplace=True)
            self.df1.reset_index(inplace=True, drop=True)
            self.df2.sort_values(by=self.df2.columns.tolist(), inplace=True)
            self.df2.reset_index(inplace=True, drop=True)

    def __diff(self, from_row: int = 0, to_row: int = None):
        # FIXME: Calculation of variables `rows_compared` and `cells_compared`
        #  during multiple calls (part of diff_second_pass)
        # If :meth:`report_plain_text` is called multiple times, these
        # variables are accumulated across calls. We can't reset them in
        # `__diff` because then they will not be accumulated over batches.
        # A temporary workaround is to call DataFrameDiff's methods only
        # once and recreate DataFrameDiff objects if more repetitions
        # needed.
        self.columns_compared = 0

        if self.df1.equals(self.df2):
            self.rows_compared = self.df1.shape[0]
            self.columns_compared = self.df1.shape[1]
            self.cells_compared = self.rows_compared * self.columns_compared
            return

        metadata_messages = self.compare_metadata()
        if self.prevent_diff:
            if self.ignore_metadata_differences:
                # Proceed to compare columns that have the same name and data type
                # TODO: Handle difference in the number of rows without an error
                df1_dtypes = self.df1.dtypes.to_dict()
                df2_dtypes = self.df2.dtypes.to_dict()
                keep_columns = list()
                for column, dtype in df1_dtypes.items():
                    if column in df2_dtypes.keys() and is_dtype_equal(dtype, df2_dtypes[column]):
                        keep_columns.append(column)
                self.df1.drop(set(df1_dtypes.keys()).difference(keep_columns), axis='columns', inplace=True)
                self.df2.drop(set(df2_dtypes.keys()).difference(keep_columns), axis='columns', inplace=True)
                if (self.df1.shape[0] != self.df2.shape[0]):
                    if not self.ignore_excessive_rows:
                        raise ValueError('Cannot compare when ignore_excessive_rows=False')
            else:
                raise ValueError('Blocking errors in the structure of the dataframes')

        columns_names = self.df1.columns.tolist()

        rows_range = slice(from_row, to_row)
        self.rows_compared = self.rows_compared + self.df1.index[rows_range].shape[0] + 1

        for column_name in columns_names:
            s1 = self.df1.loc[rows_range, column_name]
            s2 = self.df2.loc[rows_range, column_name]

            if s1.equals(s2):
                self.columns_compared = self.columns_compared + 1
                self.cells_compared = self.cells_compared + s1.shape[0]
                continue

            if is_bool_dtype(s1.dtype):
                mismatch_condition = (~((s1.isna() & s2.isna()) | (s1 == s2))).fillna(True)
            elif is_numeric_dtype(s1.dtype):
                if (self.maximum_relative_error > 0) or (self.maximum_absolute_error_for_zero > 0):
                    # First find rows where values are almost equal, then negate the mask.
                    mismatch_condition = (~(
                            (s1.isna() & s2.isna()) |
                            (
                                    ~s1.isna() &
                                    ~s2.isna() &
                                    (
                                            (
                                                    ((s1 == 0) | (s2 == 0)) &
                                                    ((s1 - s2).abs() <= self.maximum_absolute_error_for_zero)
                                            ) |  # when "0.000.../0" (inf) or "0/0.000..." (0)
                                            ((s1 == 0) & (s2 == 0)) |  # when "0/0" (NaN)
                                            ((1 - s1.div(s2)).abs() <= self.maximum_relative_error)
                                        # when "x/y" (float)
                                    )
                            )
                    )).fillna(True)
                else:
                    mismatch_condition = (~((s1.isna() & s2.isna()) | (s1 == s2))).fillna(True)
            elif is_datetime64_dtype(s1.dtype) or is_timedelta64_dtype(s1.dtype):
                # 1.
                # Type `numpy.datetime64` is not a fundamental NumPy type according to documentation.
                # Meanwhile, `numpy.datetime64` is a subtype of the root data class `numpy.generic`.
                # Due to confusion, support of `datetime` types in NumPy and Pandas may be limited.
                # For more information:
                #   - https://numpy.org/doc/stable/reference/arrays.scalars.html
                #
                # 2.
                # In Pandas, there is the following correspondence between Python types and Pandas types:
                #   - `datetime.datetime` -> `datetype64[ns]`
                #   - `datetime.datetime` with timezone = `datetime64[ns, TZ]`
                #   - `datetime.date` -> `object`
                #   - `datetime.time` -> `object`
                #
                # 3.
                # NumPy type `numpy.datetime64` supports only Pandas type `datetime64[ns]`, not `datetime64[ns, TZ].
                # When a timezone is specified, `numpy.issubdtype` cannot recognize the data type. It returns:
                # ```
                # TypeError: Cannot interpret 'datetime64[ns, UTC]' as a data type
                # ```
                #
                # 4.
                # Type `numpy.timedelta64` is a subtype of `numpy.number`.
                # Type `numpy.datetime64` is not a subtype of `numpy.number`.
                mismatch_condition = (~((s1.isna() & s2.isna()) | (s1 == s2))).fillna(True)
            elif is_string_dtype(s1.dtype):
                # "String" dtype includes the following types:
                #
                # Literal   Pandas dtype    NumPy dtype
                # object    dtype('O')      dtype('O')
                # string    StringDtype     dtype('O')
                #
                # Columns that contain multiple basic types (int, float, str, NoneType, etc.) belong to the "object"
                # type and get handled here.
                if self.extended_missing_objects:
                    # Convert certain values to NaN to treat them as missing
                    # Empty string to "nan" conversion:
                    s1.replace('', np.nan, inplace=True)
                    s2.replace('', np.nan, inplace=True)
                    # "None" to "nan" conversion: Not needed because `isna()` below treats "None" as missing already
                mismatch_condition = (~((s1.isna() & s2.isna()) | (s1 == s2))).fillna(True)
            else:
                raise ValueError(
                    'Unsupported column type {} in column {}'.format(s1.dtype, column_name))

            self.columns_compared = self.columns_compared + 1
            self.cells_compared = self.cells_compared + s1.shape[0]
            self.different_cells_found = self.different_cells_found + s1[mismatch_condition].index.shape[0]

            yield column_name, s1[mismatch_condition].index, mismatch_condition

    def equals(self):
        if self.df1.equals(self.df2):
            return True
        else:
            for column, index, _ in self.__diff():
                if index.shape[0] > 0:
                    return False
            return True

    def count_diffs(self, from_row: int = 0, to_row: int = None):
        """
        Count how many cells differ in two dataframes. Check for difference in metadata beforehand,
        but do not add differences in metadata to the count. Raise an error if metadata differs.

        :param from_row: Starting comparison from this row
        :param to_row: Ending comparison at this row
        :return: Number of different cells
        """
        diffs = 0
        for column, index, _ in self.__diff(from_row=from_row, to_row=to_row):
            diffs = diffs + index.shape[0]
        return diffs

    def report_diffs(self, by: str = 'row', limit: int = None, strict_limit: bool = True):
        rows = []
        columns = []
        df1s = []
        df2s = []
        count_diffs = 0

        # FIXME: Handle when zero matches and index is empty
        if limit is not None:
            BATCH_SIZE = 10000
            N_BATCHES = int(np.ceil(self.df1.shape[0] / BATCH_SIZE))
            for batch in range(N_BATCHES):
                from_row = batch * BATCH_SIZE
                to_row = (batch + 1) * BATCH_SIZE - 1
                for column, index, diff_mask in self.__diff(from_row=from_row, to_row=to_row):
                    rows.append(index.to_numpy())
                    columns.append(np.full(index.shape[0], column))
                    df1s.append(self.df1.loc[slice(from_row, to_row), :].loc[diff_mask, column].to_numpy(dtype=object))
                    df2s.append(self.df2.loc[slice(from_row, to_row), :].loc[diff_mask, column].to_numpy(dtype=object))
                    count_diffs = count_diffs + index.shape[0]
                if count_diffs > limit:
                    break
        else:
            for column, index, diff_mask in self.__diff():
                rows.append(index.to_numpy())
                columns.append(np.full(index.shape[0], column))
                df1s.append(self.df1.loc[diff_mask, column].to_numpy(dtype=object))
                df2s.append(self.df2.loc[diff_mask, column].to_numpy(dtype=object))
                count_diffs = count_diffs + index.shape[0]

        diffs = pd.DataFrame(
            np.concatenate([
                np.concatenate(rows, axis=0).reshape((-1, 1)),
                np.concatenate(columns, axis=0).reshape((-1, 1)),
                np.concatenate(df1s, axis=0).reshape((-1, 1)),
                np.concatenate(df2s, axis=0).reshape((-1, 1))
            ], axis=1) if len(rows) > 0 else None,
            columns=['row', 'column', 'df1', 'df2']
        )
        diffs.sort_values(by=['row', 'column'] if by == 'row' else ['column', 'row'], inplace=True)

        if (limit is not None) and strict_limit:
            return diffs.head(n=limit)

        return diffs

    def report_plain_text(self, by: str = 'row', limit: int = None, strict_limit: bool = True):
        lines = list()

        metadata = self.compare_metadata()
        if len(metadata) > 0:
            for m in metadata:
                code, message, details = m['code'], m['message'], m['details']
                if code == '1':
                    if details['df1'][0] != details['df2'][0]:
                        lines.append('MISMATCH: Different number of rows, benchmark vs. actual: {} vs {}'.format(
                            details['df1'][0],
                            details['df2'][0],
                        ))
                    if details['df1'][1] != details['df2'][1]:
                        lines.append('MISMATCH: Different number of columns, benchmark vs. actual: {} vs {}'.format(
                            details['df1'][1],
                            details['df2'][1],
                        ))
                if code == '5':
                    lines.append('Trying to compare with order=True...')
                if code == '2' or code == '5':
                    if len(details['df1']) > 0:
                        lines.append('MISMATCH: Columns in the benchmark frame only{}: {}'.format(
                            ' (upper case)' if self.ignore_column_case else '',
                            ', '.join(details['df1'])
                        ))
                    if len(details['df2']) > 0:
                        lines.append('MISMATCH: Columns in the actual frame only{}: {}'.format(
                            ' (upper case)' if self.ignore_column_case else '',
                            ', '.join(details['df2'])
                        ))
                if code == '3':
                    df1_columns = [i[0] for i in details if i[0] is not None]
                    df2_columns = [i[1] for i in details if i[1] is not None]
                    unique_df1_columns = sorted(list(set(df1_columns).difference(set(df2_columns))))
                    unique_df2_columns = sorted(list(set(df2_columns).difference(set(df1_columns))))
                    if len(unique_df1_columns) > 0:
                        lines.append('MISMATCH: Columns in the benchmark frame only{}: {}'.format(
                            ' (upper case)' if self.ignore_column_case else '',
                            ', '.join(unique_df1_columns)
                        ))
                    if len(unique_df2_columns) > 0:
                        lines.append('MISMATCH: Columns in the actual frame only{}: {}'.format(
                            ' (upper case)' if self.ignore_column_case else '',
                            ', '.join(unique_df2_columns)
                        ))
                    for i, v in enumerate(details):
                        if v[0] != v[1]:
                            lines.append('MISMATCH: Column name #{}, {} vs {}'.format(
                                i,
                                v[0],
                                v[1]
                            ))
                if code == '4':
                    for column, dtypes in details.items():
                        lines.append('MISMATCH: Column {}, benchmark vs. actual: {} vs {}'.format(
                            column,
                            dtypes[0],
                            dtypes[1]
                        ))
                if code == '6':
                    for column, dtypes in details.items():
                        lines.append(
                            'INFO: Column {column} cast to float before comparison, '
                            'original types: {dt1} and {dt2}'.format(
                                column=column,
                                dt1=dtypes[0],
                                dt2=dtypes[1]
                            )
                        )

        # Previous block might have found errors in metadata that prevent calling diff on cells
        if self.prevent_diff and self.ignore_metadata_differences is False:
            return lines

        diffs = self.report_diffs(by=by, limit=limit, strict_limit=strict_limit).astype('str').fillna('NaN')
        lines.append('INFO: Original shapes, benchmark vs. actual: {} vs {}'.format(
            self.original_df1_shape,
            self.original_df2_shape,
        ))
        lines.append('INFO: Compared items: {} rows, {} columns, {} cells, {} mismatches in cells'.format(
            self.rows_compared,
            self.columns_compared,
            self.cells_compared,
            self.different_cells_found,
        ))
        for row in diffs.itertuples():
            try:
                float(row.df1)
                lines.append('MISMATCH: Row {}, column {}: {} vs {}'.format(
                    row.row,
                    row.column,
                    row.df1,
                    row.df2
                ))
            except ValueError:
                lines.append('MISMATCH: Row {}, column {}: \'{}\' vs \'{}\''.format(
                    row.row,
                    row.column,
                    row.df1,
                    row.df2
                ))
        return lines

    def __diff_mask_df(self):
        diff_masks = []
        columns = []
        for column, index, diff_mask in self.__diff():
            diff_masks.append(diff_mask)
            columns.append(column)
        diff_mask_df = pd.concat(diff_masks, axis='columns')
        return diff_mask_df

    def compare_metadata(self):
        messages = []

        if self.df1.shape != self.df2.shape:
            messages.append(
                {
                    'code': '1',
                    'message': 'Shapes do not match',
                    'details': {
                        'df1': self.df1.shape,
                        'df2': self.df2.shape
                    }
                }
            )
            # Proceed with comparison if shapes differ only in the number of rows (remove excessive rows)
            if self.ignore_excessive_rows and \
                    (self.df1.shape[0] != self.df2.shape[0]) and \
                    (self.df1.shape[1] == self.df2.shape[1]):
                cutoff = min(self.df1.shape[0], self.df2.shape[0])
                self.df1 = self.df1.iloc[0:cutoff, :]
                self.df2 = self.df2.iloc[0:cutoff, :]
            else:
                self.prevent_diff = True

        df1_columns = self.df1.columns.tolist()
        df2_columns = self.df2.columns.tolist()

        if self.ignore_column_order:
            if set(df1_columns) != set(df2_columns):
                messages.append(
                    {
                        'code': '2',
                        'message': 'Columns do not match (ignore_column_order on), unique columns in details',
                        'details': {
                            'df1': sorted(list(set(df1_columns).difference(set(df2_columns)))),
                            'df2': sorted(list(set(df2_columns).difference(set(df1_columns))))
                        }
                    }
                )
                self.prevent_diff = True
                return messages
        else:
            if df1_columns != df2_columns:
                messages.append(
                    {
                        'code': '3',
                        'message': 'Columns do not match (ignore_column_order off), pairs in details',
                        'details': [(i, j) for i, j in zip_longest(df1_columns, df2_columns)]
                    }
                )
                if set(df1_columns) != set(df2_columns):
                    messages.append(
                        {
                            'code': '5',
                            'message': 'Columns do not match after retry (ignore_column_order on), unique columns in details',
                            'details': {
                                'df1': sorted(list(set(df1_columns).difference(set(df2_columns)))),
                                'df2': sorted(list(set(df2_columns).difference(set(df1_columns))))
                            }
                        }
                    )
                    self.prevent_diff = True
                    return messages

        df1_dtypes = self.df1.dtypes.to_dict()
        df2_dtypes = self.df2.dtypes.to_dict()

        mismatching_dtypes = dict()
        cast_to_float = dict()
        for column in df1_columns:
            dt1 = self.df1[column].dtype
            dt2 = self.df2[column].dtype
            if not is_dtype_equal(dt1, dt2):
                if (is_numeric_dtype(dt1) or is_bool_dtype(dt1)) and \
                        (is_numeric_dtype(dt2) or is_bool_dtype(dt2)):
                    if self.cast_to_float:
                        # Omit type difference and report it separately
                        self.df1[column] = self.df1[column].astype('float')
                        self.df2[column] = self.df2[column].astype('float')
                        cast_to_float[column] = (str(dt1), str(dt2))
                        continue
                if is_string_dtype(dt1) and is_string_dtype(dt2):
                    # Types "string" and "object" are equivalent for comparison purposes
                    continue
                # float_and_object_null_columns
                if is_float_dtype(dt1) and is_object_dtype(dt2):
                    """
                    Workaround for the input bug when an object column of nulls is read as a float column of nulls.
                    Check `test_float_and_object_null_columns()` for examples.
                    """
                    if self.df1[column].isna().all() and self.df2[column].isna().all():
                        # Do not catch a type mismatch and proceed to value comparison instead
                        self.df1.drop(column, axis='columns', inplace=True)
                        self.df2.drop(column, axis='columns', inplace=True)
                        continue
                mismatching_dtypes[column] = (str(dt1), str(dt2))

        if len(cast_to_float) > 0:
            messages.append(
                {
                    'code': '6',
                    'message': 'Columns cast to float',
                    'details': cast_to_float
                }
            )

        if len(mismatching_dtypes) > 0:
            messages.append(
                {
                    'code': '4',
                    'message': 'Data types do not match, mismatching pairs in details',
                    'details': mismatching_dtypes
                }
            )
            self.prevent_diff = True
            return messages

        return messages
