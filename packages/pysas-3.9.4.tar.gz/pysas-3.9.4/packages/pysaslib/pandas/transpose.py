from typing import List


def transpose(df,
              groupby: List[str] = None,
              value_vars: List[str] = None,
              prefix=None,
              names: List[str] = None):
    raise ValueError("Pandas describe implementation not supported")
