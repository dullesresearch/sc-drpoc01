import numpy as np
import pandas as pd
import datetime
import random
import string
from typing import List
from pysaslib.format import best

captions = {'COUNT': 'Frequency', 'PERCENT': 'Percent',
            'COUNT_CUM': 'Cumulative Frequency', 'PERCENT_CUM': 'Cumulative Percent',
            'ROW_PCT': 'Row Pct', 'COL_PCT': 'Col Pct'}

freq_message = '\n                                                         The FREQ Procedure'


def crosstab(df=None,
             groupby: List[str] = None,
             tables: List[str] = None,
             range: bool = False,
             missing: bool = False,
             out=False,
             format_numbers=False,
             format_func=None):
    out_dic = {'source': 'freq', 'dataframes': None, 'messages': None, 'out': None}
    if format_numbers and format_func is None:
        format_func = best(12).put
    if range:
        if len(tables) != 2:
            raise ValueError('If range = True, the parameter tables should be: [column1, column2].')
        else:
            cols_list = list(df.columns)
            col_ixs = sorted([cols_list.index(c) for c in tables])
            tables = cols_list[col_ixs[0]:col_ixs[1]+1]

    # 1. Calculate FREQ for the list of tables
    if tables is None and groupby is None:
        cols = list(df.columns)
        # Format columns
        if format_numbers:
            df = _format_numbers(df, cols, format_func)
        outs, msgs = _calc_freq_one_column(df, columns=cols, rename=True)
        # Return the output dictionary
        out_dic['dataframes'] = outs
        out_dic['messages'] = msgs
        out_dic['out'] = _calc_freq_output(df, columns=cols[-1], groupby=None) if out else None
        return out_dic

    # 2. Calculate FREQ for the list of tables
    elif tables and groupby is None:
        return _calc_freq_tables(df, tables, missing, out=out, format_numbers=format_numbers, format_func=format_func)

    # 3. Calculate FREQ for the list of tables for each group in groupby list
    elif tables and groupby:
        if isinstance(groupby, str):
            groupby = [groupby]
        if not missing:
           df = _drop_na_values(df, groupby)
        by_dict = df[groupby].drop_duplicates().sort_values(groupby, na_position='first').to_dict(orient="records")
        group_header = '\n\n{0} {{}} {0}'.format('-' * 55)

        messages, dataframes = list(), list()
        for row in by_dict:
            messages.append(group_header.format(' '.join([f"{k}={v}" for k, v in row.items()])))
            dataframes.append(None)
            qry = query_condition(row)
            df_ = df.query(qry, engine='python')
            df_.reset_index(inplace=True)
            by_out = _calc_freq_tables(df=df_, tables=tables, missing=missing, out=False,
                                       format_numbers=format_numbers, format_func=format_func)
            messages = messages + by_out['messages']
            dataframes = dataframes + by_out['dataframes']

        # Return the output dictionary
        out_dic['messages'] = messages
        out_dic['dataframes'] = dataframes
        if out:
            cols = list()
            for x in tables[-1]:
                if isinstance(x, str):
                    cols.append(x)
                elif isinstance(x, list):
                    cols.extend(x)
            out_dic['out'] = _calc_freq_output(df=df, columns=groupby + cols, groupby=groupby)
        return out_dic

    else:
        pass


def _calc_freq_tables(df, tables, missing, out, format_numbers=False, format_func=None):
    out_dic = {'source': 'freq', 'dataframes': None, 'messages': None, 'out': None}
    outs = list()
    messages = list()
    for t in tables:
        t_ = [t] if isinstance(t, str) else t
        len_t = len(t_)
        # Drop NA values
        if not missing:
            df = _drop_na_values(df, t_)
        # Format dataframe columns
        if format_numbers:
            df = _format_numbers(df, t_, format_func)
        if len_t == 1:
            out, message = _calc_freq_one_column(df=df, columns=t_, rename=True)
        elif len_t == 2:
            df_groups, na_strings, cols_maps = _get_df_groups_na(df=df, col1=t_[0], col2=t_[1], k=16)
            out, message = _calc_freq_two_columns(df=df, cols=t_, df_groups=df_groups, na_strings=na_strings,
                                                  cols_maps=cols_maps, show_legend=False)
        elif len_t == 3:
            out, message = _calc_freq_three_columns(df=df, columns=t_, show_legend=False)
        else:
            raise NotImplementedError('Supported number of columns in a table is from 1 to 3.')
        outs = outs + out
        messages = messages + message
    # Return the output dictionary
    out_dic['dataframes'] = outs
    out_dic['messages'] = messages
    out_dic['out'] = _calc_freq_output(df, columns=tables[-1]) if out else None
    return out_dic


def _drop_na_values(df, columns):
    return df.dropna(subset=columns)


def _format_numbers(df, cols, format_func):
    for c in cols:
        if pd.api.types.is_numeric_dtype(df[c]):
            df[c] = df[c].apply(lambda z: format_func(z))
    return df


def _calc_freq_one_column(df, columns, rename=True):
    out_dfs, out_ms = list(), list()
    count_total = df.shape[0] / 100
    for col in columns:
        df_ = df.assign(_cnt_ = 1).loc[:, [col, '_cnt_']]
        df_ = df_.groupby(col, dropna=False).agg({'_cnt_': 'sum'}).rename(columns={'_cnt_': 'COUNT'})
        df_ = df_.sort_index(na_position='first')
        df_['PERCENT'] = df_['COUNT'].apply(lambda z: np.nan if count_total == 0 else np.round(z/count_total, 2))
        for c in ['COUNT', 'PERCENT']:
            df_[c + '_CUM'] = df_[c].cumsum()
        if rename:
            df_.rename(columns=captions, inplace=True)
        df_.reset_index(inplace=True)
        df_.index = np.empty(df_.shape[0], dtype = str)
        out_dfs.append(df_)
        out_ms.append(freq_message)
    return out_dfs, out_ms


def _calc_freq_output(df, columns, groupby=None):
    if isinstance(columns, str):
        columns = [columns]
    df_ = df.assign(_cnt_=1).groupby(columns, dropna=False).agg({'_cnt_': 'sum'}).rename(columns={'_cnt_': 'COUNT'})
    df_.sort_index(na_position='first', inplace=True)
    df_.reset_index(inplace=True)
    if groupby:
        df_gr = df_.assign(_cnt_=1).groupby(groupby, dropna=False).agg({'COUNT': 'sum'}).rename(columns={'COUNT': 'GR_COUNT'})
        df_ = pd.merge(df_, df_gr.reset_index(), how='inner', on=groupby)
        df_['PERCENT'] = df_.apply(lambda z: np.round(100 * z['COUNT'] / z['GR_COUNT'], 2), axis=1)
    else:
        count_total = df.shape[0]
        df_['PERCENT'] = df_['COUNT'].apply(lambda z: np.nan if count_total == 0 else np.round(100 * z/count_total, 2))
    df_.sort_values(columns, na_position='first', inplace=True)
    df_['Obs'] = list(range(1, df_.shape[0] + 1))
    return df_[columns + ['Obs', 'COUNT', 'PERCENT']].set_index(['Obs'])


def _get_df_groups_na(df, col1, col2, k=16):
    """
    1) Get all possible combinations of col1, col2 in a dataframe,
    2) Fill NaN values with random strings
    3) Get mappings between column aliases and original names
    """
    cols = [col1, col2]
    na_strings, col_dfs = list(), list()
    for i in range(2):
        # Generate 2 random strings to replace NaN values for joining dataframes
        na_strings.append(''.join(random.choices(string.ascii_letters + string.digits, k=k)))
        # Get sorted lists of unique values of cols,
        d = df[[cols[i]]].drop_duplicates().sort_values(by=[cols[i]], na_position='first') \
            .fillna(na_strings[i]).reset_index(drop=True)
        d['_cnt0_'] = 0
        # Get string aliases for cols
        d[f'_col{i+1}_order_'] = list(range(d.shape[0]))
        d[f'_col{i+1}_alias_'] = d.apply(lambda z: f"{int(z[f'_col{i+1}_order_']):04d}_{z[cols[i]]}", axis=1)
        col_dfs.append(d)
    # Cross join of two dataframes
    gr = pd.merge(col_dfs[0], col_dfs[1], how='inner', on='_cnt0_').set_index(cols)
    # Get mappings to restore original column names
    cols_maps = list()
    for i in range(2):
        cm = col_dfs[i][[f'_col{i+1}_order_', f'_col{i+1}_alias_', cols[i]]].to_dict('split')['data']
        cols_maps.append({rec[1]: 'NaN' if rec[1].endswith(na_strings[i]) else str(rec[2]) for rec in cm})
    return gr[['_col1_alias_', '_col2_alias_']], na_strings, cols_maps


def _calc_freq_two_columns(df, cols, df_groups, na_strings, cols_maps, show_legend=False):
    out_dfs = list()
    # Replace NA valus with given na_strings
    df_ = df[cols]
    for i in range(2):
        df_.loc[:, cols[i]] = df_[cols[i]].fillna(na_strings[i])
    # Group input dataframes by two given columns and precalculate counts
    df_ = df_.assign(_cnt_=1).groupby(cols, dropna=False).agg({'_cnt_': 'sum'})
    # Merge two dataframes
    df_ = pd.merge(df_groups, df_, how='left', left_index=True, right_index=True)
    df_['_cnt_'] = df_.apply(lambda r: 0 if pd.isna(r['_cnt_']) else int(r['_cnt_']), axis=1)
    df_.reset_index(inplace=True)
    # df_.sort_values(by=columns, na_position='first', inplace=True)
    # Calculate Frequency
    count_total = df.shape[0]
    ct1 = pd.crosstab(index=df_['_col1_alias_'],
                      columns=df_['_col2_alias_'],
                      values=df_['_cnt_'], aggfunc='sum',
                      margins=True, margins_name='Total', dropna=False)
    ct1.columns.name = cols[1]
    ct1.rename(columns=cols_maps[1], inplace=True)
    cols_maps[0]['Total'] = 'Total'
    ct1.index = pd.Index(map(cols_maps[0].get, ct1.index), name=cols[0])
    out_dfs.append(ct1)
    # Calculate Percent
    ct2 = out_dfs[0].copy()
    ct2 = ct2.apply(lambda r: np.nan if count_total == 0 else np.round(100 * r / count_total, 2), axis=1)
    out_dfs.append(ct2)
    # Calculate Row Pct
    ct3 = out_dfs[0].copy()
    for c in ct3.columns:
        ct3[c] = ct3.apply(lambda r: np.nan if r['Total'] == 0 else np.round(100 * r[c] / r['Total'], 2), axis=1)
    ct3['Total'] = ''
    ct3.loc['Total', :] = ''
    out_dfs.append(ct3)
    # Calculate Col Pct
    ct4 = out_dfs[0].copy()
    total_row = ct4.loc['Total', :].to_dict()
    for c in total_row.keys():
        ct4[c] = np.nan if total_row[c] == 0 else np.round(100 * ct4[c] / total_row[c], decimals=2)
    ct4['Total'] = ''
    ct4.loc['Total', :] = ''
    out_dfs.append(ct4)
    # Concatenate 4 dataframes and return the output dataframe
    for i in range(4):
        out_dfs[i]['order'] = i
        out_dfs[i]['row_num'] = range(out_dfs[0].shape[0])
        stat_col = ''  # 'statistic' column
        out_dfs[i].reset_index(inplace=True)
        if show_legend:
            out_dfs[i][stat_col] = {0: 'Frequency', 1: 'Percent', 2: 'Row Pct', 3: 'Col Pct'}[i]
        else:
            out_dfs[i][stat_col] = out_dfs[i].apply(lambda r: 'to_drop' if r[cols[0]] == 'Total' and i > 2 else '',
                                                    axis=1)
    out = pd.concat(out_dfs).sort_values(by=['row_num', 'order'], na_position='first')
    out = out.set_index([cols[0], stat_col]).drop(columns=['order', 'row_num'])
    if show_legend:
        vals_to_drop = [('Total', 'Row Pct'), ('Total', 'Col Pct')]
    else:
        vals_to_drop = [('Total', 'to_drop'), ('Total', 'to_drop')]
    out.drop(index=vals_to_drop, inplace=True)
    msg = freq_message + f'\n         Table of {cols[0]} by {cols[1]}' + \
          ('\n' if show_legend else '\nFrequency\nPercent\nRow Pct\nCol Pct')
    return [out], [msg]


def _calc_freq_three_columns(df, columns, show_legend=False):
    df_groups, na_strings, cols_maps = _get_df_groups_na(df=df, col1=columns[1], col2=columns[2], k=16)
    by_dict = df[[columns[0]]].drop_duplicates() \
        .sort_values(columns[0], na_position='first').to_dict(orient="records")
    outs, msgs = list(), list()
    for row in by_dict:
        qry = query_condition(row)
        table_num = by_dict.index(row) + 1
        out, message = _calc_freq_two_columns(df=df.query(qry, engine='python'), cols=columns[1:],
                                              df_groups=df_groups, na_strings=na_strings, cols_maps=cols_maps,
                                              show_legend=show_legend)

        message = freq_message + f'\n         Table {table_num} of {columns[1]} by {columns[2]}' + \
                                 ('\n' if show_legend else '\nFrequency\nPercent\nRow Pct\nCol Pct') + \
                                 f'\n        Controlling for {columns[0]}={row[columns[0]]}'
        outs.append(out[0])
        msgs.append(message)
    return outs, msgs


def query_condition(rowdict: dict) -> str:
    conds = list()
    for k, v in rowdict.items():
        if pd.isna(v):
            cond = f"(@pd.isna(`{k}`))"
        elif type(v) == str:
            cond = f"(`{k}` == '{v}')"
        elif type(v) == bool:
            cond = f"(`{k}` == {v})"
        elif isinstance(v, (datetime.date, datetime.datetime, pd.Timestamp, np.datetime64)):
            cond = f"(`{k}` == @pd.Timestamp('{pd.Timestamp(v)}'))"
        else:
            cond = f"(`{k}` == {v})"
        conds.append(cond)
    return " & ".join(conds)
