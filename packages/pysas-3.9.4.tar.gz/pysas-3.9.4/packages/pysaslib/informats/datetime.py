#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.informats.sasinformat import SASInformat


class DATETIME(SASInformat):
    cache = None

    def __init__(self, width: int, decimals: int):
        if width < 7 or width > 40:
            raise ValueError("Parameter width must be a number from 7 to 40")
        if decimals >= width - 1:
            raise ValueError("Parameter decimals must be a number less than w–1")
        informat = {
            (7, 0): ('%d%b%y', '18SEP14', 'datetime', 7, 0),
            (10, 0): ('%d%b%y:%H', '18SEP14:17', 'datetime', 10, 0),
            (11, 0): (' %d%b%y:%H', ' 18SEP14:17', 'datetime', 11, 0),
            (12, 0): ('  %d%b%y:%H', '  18SEP14:17', 'datetime', 12, 0),
            (15, 0): ('  %d%b%y:%H:%M', '  18SEP14:17:31', 'datetime', 15, 0),
            (16, 0): ('%d%b%y:%H:%M:%S', '18SEP14:17:31:45', 'datetime', 16, 0),
            (18, 0): ('  %d%b%y:%H:%M:%S', '  18SEP14:17:31:45', 'datetime', 18, 0),
            (18, 1): ('%d%b%y:%H:%M:%S.%f', '18SEP14:17:31:45.0', 'datetime', 18, 1),
            (19, 0): (' %d%b%Y:%H:%M:%S', ' 18SEP2014:17:31:45', 'datetime', 19, 0),
            (19, 1): (' %d%b%Y:%H:%M:%S', ' 18SEP2014:17:31:45', 'datetime', 19, 0),
            (20, 0): ('  %d%b%Y:%H:%M:%S', '  18SEP2014:17:31:45', 'datetime', 20, 0),
            (20, 1): ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.0', 'datetime', 20, 1),
            (21, 0): ('   %d%b%Y:%H:%M:%S', '   18SEP2014:17:31:45', 'datetime', 21, 0),
            (21, 1): (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.0', 'datetime', 21, 1),
            (21, 2): ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.04', 'datetime', 21, 2),
            (23, 3): (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.043', 'datetime', 23, 3),
            (25, 6): ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.043252', 'datetime', 25, 6),
            (26, 6): (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.043252', 'datetime', 26, 6),
            (27, 6): ('  %d%b%Y:%H:%M:%S.%f', '  18SEP2014:17:31:45.043252', 'datetime', 27, 6)
        }[width, decimals]
        self.sas_format = 'DATETIME{}.{}'.format(str(width), str(decimals))
        self.py_format = informat[0]
        self.sample = informat[1]
        self.date_type = informat[2]
        self.w = width
