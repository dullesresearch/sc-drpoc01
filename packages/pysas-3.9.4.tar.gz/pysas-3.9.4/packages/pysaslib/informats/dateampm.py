#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.informats.sasinformat import SASInformat


class DATEAMPM(SASInformat):
    cache = None

    def __init__(self, width: int, decimals: int):
        if width < 7 or width > 40:
            raise ValueError("Parameter width must be a number from 7 to 40.")
        if decimals >= width - 1:
            raise ValueError("Parameter decimals must be a number less than width–1.")
        informat = {
            (7, 0): ('%d%b%y', '18SEP14', 'datetime', 7, 0),
            (10, 0): ('%d%b%y:%H', '18SEP14:17', 'datetime', 10, 0),
            (11, 0): (' %d%b%y:%H', ' 18SEP14:17', 'datetime', 11, 0),
            (12, 0): ('  %d%b%y:%H', '  18SEP14:17', 'datetime', 12, 0),
            (18, 0): ('  %d%b%y:%I:%M %p', '  18SEP14:05:31 PM', 'datetime', 18, 0),
            (18, 1): ('  %d%b%y:%I:%M %p', '  18SEP14:05:31 PM', 'datetime', 18, 0),
            (19, 0): ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0),
            (19, 1): ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0),
            (20, 0): (' %d%b%y:%I:%M:%S %p', ' 18SEP14:05:31:45 PM', 'datetime', 20, 0),
            (21, 0): ('  %d%b%y:%I:%M:%S %p', '  18SEP14:05:31:45 PM', 'datetime', 21, 0),
            (21, 1): ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.0 PM', 'datetime', 21, 1),
            (23, 3): ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.043 PM', 'datetime', 23, 3),
            (26, 6): ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.043252 PM', 'datetime', 26, 6),
            (27, 6): (' %d%b%y:%I:%M:%S.%f %p', ' 18SEP14:05:31:45.043252 PM', 'datetime', 27, 6)
        }[width, decimals]
        self.sas_format = 'DATEAMPM{}.{}'.format(str(width), '' if decimals == 0 else str(decimals))
        self.py_format = informat[0]
        self.sample = informat[1]
        self.date_type = informat[2]
        self.w = width
