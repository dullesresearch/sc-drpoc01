#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.formats.dateandtime import SEPARATORS
from pysaslib.informats.sasinformat import SASInformat


class YYMMDDxw(SASInformat):
    cache = None

    def __init__(self, sep: str, width: int):
        informat = YYMMDDxw.get_format(sep, width)
        self.sas_format = informat[0]
        self.py_format = informat[1]
        self.sample = informat[2]
        self.date_type = informat[3]
        self.w = width

    @staticmethod
    def get_format(sep: str, width: int):
        """
        'YYMMDDN.': ('%Y%m%d', '20140918', 'date', 8, 0)
        :param sep: separator in a SAS format, acceptable values are in SEPARATORS dictionary, excepting ''
        :param width: width
        """
        sep_list = {k: v for k, v in SEPARATORS.items() if k not in ('')}
        separator = sep_list.get(sep)
        w_max = 8 if sep == 'N' else 10
        if width < 2 or width > w_max:
            raise ValueError("Parameter w must be a number from 2 to {} if x = {}.".format(w_max, sep))
        fmt_name = 'YYMMDD{}{}.'.format(sep, width)
        if 2 <= width <= 3:
            py_fmt = ' %y' if width == 3 else '%y'
            dt_sample = '14'.rjust(width, ' ')
        elif width == 4:
            py_fmt, dt_sample = '%y%m', '1409'
        elif width == 5:
            py_fmt = ' %y%m' if sep == 'N' else '%y{s}%m'.format(s=separator[0])
            dt_sample = ('14{s}09'.format(s=separator[0])).rjust(width, ' ')
        elif 6 <= width <= 7:
            py_fmt = ' %y%m%d' if width == 7 else '%y%m%d'
            dt_sample = '140918'.rjust(width, ' ')
        elif 8 <= width <= 9:
            py_fmt = '%Y%m%d' if sep == 'N' else '%y{s}%m{s}%d'.format(s=separator[0])
            py_fmt = ' ' + py_fmt if width == 9 else py_fmt
            dt_sample = ('20140918' if sep == 'N' else '14{s}09{s}18'.format(s=separator[0])).rjust(width, ' ')
        elif width == 10:
            py_fmt = '%Y{s}%m{s}%d'.format(s=separator[0])
            dt_sample = ('2014{s}09{s}18'.format(s=separator[0])).rjust(width, ' ')
        return fmt_name, py_fmt, dt_sample, 'date', width, 0
