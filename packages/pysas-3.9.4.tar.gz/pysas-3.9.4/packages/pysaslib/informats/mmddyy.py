#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.informats.sasinformat import SASInformat


class MMDDYY(SASInformat):
    cache = None

    def __init__(self, width: int):
        if width < 2 or width > 10:
            raise ValueError("Parameter width must be a number from 2 to 10.")
        sep = '/'
        informat = {
            2: ('%m', '09', 'date', 2, 0),
            3: (' %m', ' 09', 'date', 3, 0),
            4: ('%m%d', '0918', 'date', 4, 0),
            5: ('%m{}%d'.format(sep), '09{}18'.format(sep), 'date', 5, 0),
            6: ('%m%d%y', '091814', 'date', 6, 0),
            7: (' %m%d%y', ' 091814', 'date', 7, 0),
            8: ('%m{}%d{}%y'.format(sep, sep), '09{}18{}14'.format(sep, sep), 'date', 8, 0),
            9: (' %m{}%d{}%y'.format(sep, sep), ' 09{}18{}14'.format(sep, sep), 'date', 9, 0),
            10: ('%m{}%d{}%Y'.format(sep, sep), '09{}18{}2014'.format(sep, sep), 'date', 10, 0)
        }[width]
        self.sas_format = f'MMDDYY{width}.'
        self.py_format = informat[0]
        self.sample = informat[1]
        self.date_type = informat[2]
        self.w = width
