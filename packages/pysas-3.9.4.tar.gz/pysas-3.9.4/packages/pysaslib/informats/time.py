import datetime

import dateutil

from pysaslib.informats.sasinformat import SASInformat


class TIME(SASInformat):
    def __init__(self, width: int, dec: int):
        """
        'TIME.': ('%H:%M:%S.%f', '17:31:45.043252', 'time', 8, 0)
        param width: width
        param dec: the decimal fraction of seconds
        """
        if width < 2 or width > 20:
            raise ValueError("Parameter w must be a number from 2 to 20")
        if width < dec + 1:
            raise ValueError("Parameter d must be must be a number less than w-1")
        self.sas_format = 'TIME{}.{}'.format(width, '' if dec == 0 else str(dec))
        self.py_format = '%H:%M:%S.%f'  # This is generic format
        self.sample = '17:31:45.043252'
        self.date_type = 'time'
        self.w = width
        self.d = dec
        self.wd_diff = width if dec == 0 else width - dec - 1
        self.py_format_d = '{{:.{}f}}'.format(self.d)

    def format_d(self, ms):
        return '' if self.d == 0 else '.' + (self.py_format_d.format(ms / 1e6)).split('.')[1]

    def convert_value(self, value: str):
        """
         :param value: a string with SAS time in TIMEw.d format
         :return: datetime.datetime object if hours < 24, dateutil.relativedelta object otherwise
         """
        if not value or value == '.':
            return None
        else:
            hh, mm, ss, ms = 0, 0, 0, 0
            str_parts = value.strip().split('.')
            if len(str_parts) == 1:
                ms = 0
            elif len(str_parts) == 2:
                ms_len = max(6, self.d)
                ms = int(str_parts[1].ljust(ms_len, '0')) / 10 ** (ms_len - 6)
            else:
                raise ValueError(f'The value "{value}" can not be parsed using {self.sas_format} format.')
            time_parts = str_parts[0].split(':')
            if len(time_parts) == 1:
                hh = 0 if time_parts[0] == '' else int(time_parts[0])
            elif len(time_parts) == 2:
                hh, mm = int(time_parts[0]), int(time_parts[1])
            elif len(time_parts) == 3:
                hh, mm, ss = int(time_parts[0]), int(time_parts[1]), int(time_parts[2])
            else:
                raise ValueError(f'The value "{value}" can not be parsed using {self.sas_format} format.')
            if hh < 24:
                return datetime.datetime(1900, 1, 1, hh, mm, ss, int(ms))
            else:
                return dateutil.relativedelta.relativedelta(hours=hh, minutes=mm, seconds=ss, microseconds=ms)
