#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import datetime
import logging

import pysaslib.settings as settings
from pysaslib.formats.dateandtime import SEPARATORS
from pysaslib.informats.sasinformat import SASInformat

logger = logging.getLogger('pysas')


class YYMMDD(SASInformat):
    cache = None

    def __init__(self, width: int):
        """
        'YYMMDD.': ('%y%m%d', '140918', 'date', 6, 0)
        param w: width
        """
        if width < 6 or width > 32:
            raise ValueError("Parameter w must be a number from 6 to 32")
        self.sas_format = 'YYMMDD{}.'.format(width)
        self.py_format = '%y%m%d' if width < 8 else '%Y%m%d'
        self.sample = '140918'
        self.date_type = 'date'
        self.w = width
        self.repl_list = list(set(x[0] for x in SEPARATORS.values() if x[0] != ''))

    def convert_value(self, value: str) -> datetime.datetime:
        """
         :param value: a string with SAS time in YYMMDDw format
         :return: datetime.datetime object
        """
        if not value or value == "." or value == "0":
            return None
        elif self.cache:
            dt_ = self.cache.get(value)
            if dt_:
                return dt_
            else:
                dt_ = self._parse_date(value)
                if dt_ and 1980 <= dt_.year <= 2050:
                    # Add new value to cache
                    self.cache[value] = dt_
                return dt_
        else:
            return self._parse_date(value)

    def _parse_date(self, value):
        v = ''.join([s for s in value.strip() if s.isnumeric()])
        try:
            return datetime.datetime.strptime(v, self.py_format)
        except ValueError:
            logger.warning('Invalid argument "{}" for informat {}'.format(value, self.sas_format))
            return None

    # TODO: intialize for all width, but values on demand
    @classmethod
    def set_cache(cls, dt1, dt2, width):
        if not settings.INFORMAT_YYMMDD_CACHE_DISABLE:
            # initialize cache
            fmt = '%Y%m%d'.rjust(width - 2, ' ') if width >= 8 else '%y%m%d'.rjust(width, ' ')
            cls.cache = {datetime.datetime.strftime(d, fmt): d for d in
                         [dt1 + datetime.timedelta(days=x) for x in range((dt2 - dt1).days + 1)]}
