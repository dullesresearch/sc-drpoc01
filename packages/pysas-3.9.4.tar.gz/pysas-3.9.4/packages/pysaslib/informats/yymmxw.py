#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.formats.dateandtime import SEPARATORS
from pysaslib.informats.sasinformat import SASInformat


class YYMMxw(SASInformat):
    cache = None

    def __init__(self, sep: str, width: int):
        informat = YYMMxw.get_format(sep, width)
        self.sas_format = informat[0]
        self.py_format = informat[1]
        self.sample = informat[2]
        self.date_type = informat[3]
        self.w = width

    @staticmethod
    def get_format(sep: str, width: int):
        """
        'YYMMN.': ('%Y%m', '201409', 'date', 6, 0)
        :param sep: separator in a SAS format, acceptable values are in SEPARATORS dictionary, excepting '' and 'B'
        :param width: width
        """
        sep_list = {k: v for k, v in SEPARATORS.items() if k not in ('', 'B')}
        separator = sep_list.get(sep)
        if separator is None:
            raise ValueError("Parameter x must be must be one of charcters: {}.".format(', '.join(sep_list.keys())))
        w_max = 32
        w_min = 4 if sep == 'N' else 5
        if width < w_min or width > w_max:
            raise ValueError("Parameter w must be a number from {} to {} if x = {}.".format(w_min, w_max, sep))
        fmt_name = 'YYMM{}{}.'.format(sep, width)
        if width == 4:
            py_fmt, dt_sample = '%y%m', '1409'
        elif width == 5:
            py_fmt = ' %y%m' if sep == 'N' else '%y{s}%m'.format(s=separator[0])
            dt_sample = ('14{s}09'.format(s=separator[0])).rjust(width, ' ')
        elif width == 6:
            py_fmt = '%Y%m' if sep == 'N' else ' %y{s}%m'.format(s=separator[0])
            dt_sample = '201409' if sep == 'N' else ' 14{s}09'.format(s=separator[0])
        elif width >= 7:
            py_fmt = ' ' * (width - 7) + (' %Y%m' if sep == 'N' else '%Y{s}%m'.format(s=separator[0]))
            dt_sample = ('201409' if sep == 'N' else '2014{s}09'.format(s=separator[0])).rjust(width, ' ')
        return fmt_name, py_fmt, dt_sample, 'date', width, 0
