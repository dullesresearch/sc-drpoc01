#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.informats.sasinformat import SASInformat


class DDMMYY(SASInformat):
    cache = None

    def __init__(self, width: int):
        if width < 2 or width > 10:
            raise ValueError("Parameter width must be a number from 2 to 10.")
        sep = '/'
        informat = {
            2: ('%d', '18', 'date', 2, 0),
            3: (' %d', ' 18', 'date', 3, 0),
            4: ('%d%m', '1809', 'date', 4, 0),
            5: ('%d{}%m'.format(sep), '18{}09'.format(sep), 'date', 5, 0),
            6: ('%d%m%y', '180914', 'date', 6, 0),
            7: (' %d%m%y', ' 180914', 'date', 7, 0),
            8: ('%d{}%m{}%y'.format(sep, sep), '18{}09{}14'.format(sep, sep), 'date', 8, 0),
            9: (' %d{}%m{}%y'.format(sep, sep), ' 18{}09{}14'.format(sep, sep), 'date', 9, 0),
            10: ('%d{}%m{}%Y'.format(sep, sep), '18{}09{}2014'.format(sep, sep), 'date', 10, 0)
        }[width]
        self.sas_format = f'DDMMYY{width}.'
        self.py_format = informat[0]
        self.sample = informat[1]
        self.date_type = informat[2]
        self.w = width
