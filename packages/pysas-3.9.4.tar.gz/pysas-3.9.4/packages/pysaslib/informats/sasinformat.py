#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import datetime
import logging

logger = logging.getLogger('pysas')


class SASInformat:
    cache = None

    def __init__(self, width: int):
        self.w = width
        self.py_format = ''
        self.sas_format = ''

    def convert_value(self, value: str) -> datetime.datetime:
        """
         :param value: a string with time in SAS format
         :return: datetime.datetime object
        """
        return None if not value or value == '.' else self._parse_date(value)

    def _parse_date(self, value):
        try:
            return datetime.datetime.strptime(value, self.py_format)
        except ValueError:
            logger.warning('Invalid argument "{}" for informat {}'.format(value, self.sas_format))
            return None
