#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

from pysaslib.informats.sasinformat import SASInformat


class DATE(SASInformat):
    cache = None

    def __init__(self, width: int):
        if width < 5 or width > 11:
            raise ValueError("Parameter w must be a number from 5 to 11")
        informat = {
            5: ('%d%b', '18SEP', 'date', 5, 0),
            6: (' %d%b', ' 18SEP', 'date', 6, 0),
            7: ('%d%b%y', '18SEP14', 'date', 7, 0),
            8: (' %d%b%y', ' 18SEP14', 'date', 8, 0),
            9: ('%d%b%Y', '18SEP2014', 'date', 9, 0),
            10: (' %d%b%Y', ' 18SEP2014', 'date', 10, 0),
            11: ('%d-%b-%Y', '18-SEP-2014', 'date', 11, 0)
        }[width]
        self.sas_format = 'DATE{}.'.format(width)
        self.py_format = informat[0]
        self.sample = informat[1]
        self.date_type = informat[2]
        self.w = width
