#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
def vtype(variable):
    return None
