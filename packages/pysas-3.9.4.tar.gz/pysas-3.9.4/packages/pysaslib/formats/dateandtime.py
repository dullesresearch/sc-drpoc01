#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

import datetime
import logging

import dateutil
import numpy as np
import pandas as pd

sample_string = '2014-09-18 17:31:45.043252'
sample_date = datetime.datetime.fromisoformat(sample_string)

## SAS datetime formats implemented according to The Essential Guide to SAS Dates and Times,
## https://learning.oreilly.com/library/view/the-essential-guide/9781629590660/xhtml/ch02.xhtml

logger = logging.getLogger('pysas')

#
# Dictionary with supported SAS datetime formats:
# '<SAS format>' : ('<Python format>', '<EXAMPLE>', '<data type>', <w>, <d>)
#
FORMATS = {
    'DATE.': ('%d%b%y', '18SEP14', 'date', 7, 0),
    'DDMMYY.': ('%d/%m/%y', '18/09/14', 'date', 8, 0),
    'DDMMYYB.': ('%d %m %y', '18 09 14', 'date', 8, 0),
    'DDMMYYC.': ('%d:%m:%y', '18:09:14', 'date', 8, 0),
    'DDMMYYD.': ('%d-%m-%y', '18-09-14', 'date', 8, 0),
    'DDMMYYN.': ('%d%m%Y', '18092014', 'date', 8, 0),
    'DDMMYYP.': ('%d.%m.%y', '18.09.14', 'date', 8, 0),
    'DDMMYYS.': ('%d/%m/%y', '18/09/14', 'date', 8, 0),
    'MMDDYY.': ('%m/%d/%y', '09/18/14', 'date', 8, 0),
    'MMDDYYB.': ('%m %d %y', '09 18 14', 'date', 8, 0),
    'MMDDYYC.': ('%m:%d:%y', '09:18:14', 'date', 8, 0),
    'MMDDYYD.': ('%m-%d-%y', '09-18-14', 'date', 8, 0),
    'MMDDYYN.': ('%m%d%Y', '09182014', 'date', 8, 0),
    'MMDDYYP.': ('%m.%d.%y', '09.18.14', 'date', 8, 0),
    'MMDDYYS.': ('%m/%d/%y', '09/18/14', 'date', 8, 0),
    'DATEAMPM.': ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0),
    'DATETIME.': ('%d%b%y:%H:%M:%S', '18SEP14:17:31:45', 'datetime', 16, 0),
    'DTDATE.': ('%d%b%y', '18SEP14', 'date', 7, 0),
    #
    'YYMMDD.': ('%y-%m-%d', '14-09-18', 'date', 8, 0),
    'YYMMDDB.': ('%y %m %d', '14 09 18', 'date', 8, 0),
    'YYMMDDC.': ('%y:%m:%d', '14:09:18', 'date', 8, 0),
    'YYMMDDD.': ('%y-%m-%d', '14-09-18', 'date', 8, 0),
    'YYMMDDN.': ('%Y%m%d', '20140918', 'date', 8, 0),
    'YYMMDDP.': ('%y.%m.%d', '14.09.18', 'date', 8, 0),
    'YYMMDDS.': ('%y/%m/%d', '14/09/18', 'date', 8, 0),
    #
    'WEEKDATE.': ('%A, %B %d, %Y', 'Thursday, September 18, 2014', 'date', 28, 0),
    'WEEKDATX.': ('%A, %d %B %Y', 'Thursday, 18 September 2014', 'date', 28, 0),
    'DTWKDATX.': ('%A, %d %B %Y', 'Thursday, 18 September 2014', 'date', 28, 0),
    'WORDDATE.': ('%B %d, %Y', 'September 18, 2014', 'date', 0, 0),
    'WORDDATX.': ('%d %B %Y', '18 September 2014', 'date', 0, 0),
    #
    'MONYY.': ('%b%y', 'SEP14', 'datepart', 5, 0),
    'DTMONYY.': ('%b%y', 'SEP14', 'datepart', 5, 0),
    'DOWNAME.': ('%A', 'Thursday', 'datepart', 9, 0),
    'DAY.': ('%d', '18', 'datepart', 2, 0),
    #
    'YEAR.': ('%Y', '2014', 'datepart', 4, 0),
    'DTYEAR.': ('%Y', '2014', 'datepart', 4, 0),
    'YYMM.': ('%YM%m', '2014M09', 'datepart', 7, 0),
    'YYMMC.': ('%Y:%m', '2014:09', 'datepart', 7, 0),
    'YYMMD.': ('%Y-%m', '2014-09', 'datepart', 7, 0),
    'YYMMN.': ('%Y%m', '201409', 'datepart', 6, 0),
    #
    'HHMM.': ('%H:%M', '17:31', 'time', 5, 0),
    'HOUR.': ('%H', '17', 'time', 2, 0),
    # 'MMSS.': (None, '875', 'timedelta', 0, 0), #To be clarified
    'TIME.': ('%H:%M:%S', '17:31:45', 'time', 8, 0),
    'TIMEAMPM.': ('%I:%M:%S %p', '05:31:45 PM', 'time', 11, 0),
    'TOD.': ('%H:%M:%S', '17:31:45', 'time', 8, 0),
    #
    ##
    'DATE5.': ('%d%b', '18SEP', 'date', 5, 0),
    'DATE6.': (' %d%b', ' 18SEP', 'date', 6, 0),
    'DATE7.': ('%d%b%y', '18SEP14', 'date', 7, 0),
    'DATE8.': (' %d%b%y', ' 18SEP14', 'date', 8, 0),
    'DATE9.': ('%d%b%Y', '18SEP2014', 'date', 9, 0),
    'DATE10.': (' %d%b%Y', ' 18SEP2014', 'date', 10, 0),
    'DATE11.': ('%d-%b-%Y', '18-SEP-2014', 'date', 11, 0),
    'DATETIME18.': ('%d%b%Y:%H:%M:%S', '18SEP2014:17:31:45', 'datetime', 18, 0),
    'DATETIME19.': ('%Y-%m-%d %H:%M:%S', '2014-09-18 17:31:45', 'datetime', 19, 0),  # WRONG?
    'MMDDYY10.': ('%m-%d-%Y', '09-18-2014', 'date', 10, 0),
    'TIMEAMPM11.': ('%I:%M:%S %p', '05:31:45 PM', 'time', 11, 0),
    ##
}

#
# Dictionary with supported separators in SAS datetime formats
# '<SAS separator>' : ('<Python separator>', '<description>')
#
SEPARATORS = {'': ('/', 'slash (default)'),
              'B': (' ', 'space'),
              'C': (':', 'column'),
              'D': ('-', 'dash'),
              'N': ('', 'none'),
              'P': ('.', 'point'),
              'S': ('/', 'slash')
              }

# Days of the fist week of January 1900 (used for SAS format 'DOWNAME.')
week_days_190001 = {'MONDAY': 1, 'TUESDAY': 2, 'WEDNESDAY': 3, 'THURSDAY': 4, 'FRIDAY': 5, 'SATURDAY': 6, 'SUNDAY': 7}


class DT:
    def __init__(self, format, type='SAS'):
        """
        :param format: a character containing
                - SAS datetime format if type ='SAS',
                - Python datetime format if type ='Python'
                - Python dictionary if type = 'dictionary', for example:
                    dic = {'DDMMYY.': ('%d/%m/%y', '18/09/14', 'date', 8, 0)}
        :param type: type of datetime format, acceptable values: 'SAS', 'Python', 'dictionary'
        """
        if type == 'SAS':
            py_fmt = self.check_sas_format(format)
            self.__sas_format = format
        elif type == 'Python':
            sample = sample_date.strftime(format)  # Check Python format
            py_fmt = format, sample, 'datetime', len(sample), 6 if '%f' in format else 0
            self.__sas_format = None
        elif type == 'dictionary':
            self.__sas_format = list(format.keys())[0]
            py_fmt = list(format.values())[0]
        else:
            raise ValueError("Wrong value of parameter type. Acceptable values: 'SAS', 'Python', 'dictionary'.")
        self.__py_format = py_fmt[0]
        self.__sample = py_fmt[1]
        self.__date_type = py_fmt[2]
        self.__w = py_fmt[3]
        self.__d = py_fmt[4]
        # Modify Python format for processing ms when 0 < d < 6:
        if '%f' in self.__py_format and 0 < self.__d < 6:
            self.__process_ms = True
            self.__d_str = '<#ms#>'
            self.__py_format_d = self.__py_format.replace('%f', self.__d_str)
        else:
            self.__process_ms = False
            self.__d_str = None
            self.__py_format_d = None
        # Check date type character:
        if self.__date_type not in ['date', 'datetime', 'time', 'datepart']:
            raise NotImplementedError('Datetime type "{0}" not implemented yet.'.format(self.__date_type))

    @staticmethod
    def check_sas_format(fmt):
        """
        :param fmt: a character with SAS datetime format
        :return: a tuple ('<Python format>', '<EXAMPLE>', '<data type>', <w>, <d>)
                 if SAS format is in the sas_formats dictionary. The exception raised otherwise
        """
        if isinstance(fmt, str):
            try:
                fmt_val = FORMATS[fmt]
            except KeyError:
                raise NotImplementedError('SAS datetime format "{0}" not implemented yet.'.format(format))
        elif isinstance(fmt, dict):
            fmt_val = list(fmt.values())[0]
            # TODO: implement additional checks
        else:
            raise ValueError('Wrong data type of the parameter format. Acceptable types: str, dict.'.format(format))
        return fmt_val

    def to_sas_datetime(self, dtobj, upper=True):
        """
        :param dtobj: a datetime object, acceptable types:
                - datetime.datetime
                - numpy.datetime64
        :param upper: convert output character to upper case if True
        :return: Datetime string in SAS format
        """
        dt_ = pd.to_datetime(dtobj) if isinstance(dtobj, np.datetime64) else dtobj
        if not self.__process_ms:
            out_str = dt_.strftime(self.__py_format)
        else:
            # Process ms separately:
            ms_ = int(round(dtobj.microsecond / 10 ** (6 - self.__d), 0))
            out_str = dt_.strftime(self.__py_format_d).replace(self.__d_str, str(ms_).rjust(self.__d, '0'))
        return out_str.upper() if upper else out_str

    def put(self, value, method='vectorize', upper=True):
        """
        :param value: acceptable types:
                  - datetime.datetime, datetime.timedelta, dateutil.relativedelta
                  - numpy datetime64
                  - Pandas Series
        :param method: = 'vectorize', 'apply', 'map'
        :param upper: convert character to uppercase if True
        :return: Datetime character in SAS format
        """
        if isinstance(value, (datetime.date, datetime.time, datetime.datetime, np.datetime64)):
            return self.to_sas_datetime(value, upper)
        elif isinstance(value, pd.Series):
            if method == 'vectorize':
                return np.vectorize(self.to_sas_datetime)(value, upper)
            elif method == 'apply':
                return value.apply(lambda t: self.to_sas_datetime(t, upper))
            elif method == 'map':
                return value.map(self.to_sas_datetime)
            elif method == 'builtin':
                value.dt.strftime(self.__py_format)
            else:
                raise ('Wrong value "{0}" of the parameter method .'
                       'Acceptable values: vectorize, apply, map, builtin'.format(method))
        else:
            raise ValueError('The value parameter contains a wrong value of type{0}.'.format(type(value)))

    def put_df(self, df, incolumn, outcolumn, method='vectorize', upper=True):
        """
        :param df: a Pandas Datafrme
        :param incolumn: input column in Pandas Datafrme
        :param outcolumn: output column in Pandas Datafrme
        :param method: = 'vectorize', 'apply', 'map'
        :param upper: convert character to uppercase if True
        :return: Datetime character in SAS format
        """
        if isinstance(df, pd.DataFrame):
            if method == 'vectorize':
                df[outcolumn] = np.vectorize(self.to_sas_datetime)(df[incolumn], upper)
            elif method == 'apply':
                df[outcolumn] = df[incolumn].apply(lambda t: self.to_sas_datetime(t, upper))
            elif method == 'map':
                df[outcolumn] = df[incolumn].map(lambda t: self.to_sas_datetime(t, upper))
            elif method == 'builtin':
                df[outcolumn] = df[incolumn].dt.strftime(self.__py_format)
            else:
                raise ('Wrong value "{0}" of the parameter method.'
                       'Acceptable values: vectorize, apply, map, builtin'.format(method))
        else:
            raise ValueError('The parameter df contains a wrong value of type{0}.'.format(type(df)))

    @staticmethod
    def check_sas_sep(sep):
        """
        :param sep: a separator for SAS datetime format, acceptable values are in sas_separators dictionary
        :return: a tuple ('<separator>', '<explanation').
                 The exception raised if a separator not found sas_separators dictionary.
        """
        try:
            sep_val = SEPARATORS[sep]
        except KeyError:
            raise NotImplementedError('SAS datetime separator "{0}" not implemented yet.'.format(sep))
        return sep_val

    def convert_value(self, value):
        if self.__sas_format == 'DOWNAME.':
            dow = int(week_days_190001[value.upper()])
            return datetime.datetime(1900, 1, dow)
        elif self.__sas_format == 'DAY.':
            return datetime.datetime(1900, 1, int(value))
        elif self.__sas_format in ('DATE5.', 'DATE6.'):
            # Process two formats without year for the case of leap years:
            s_ = value + '1904'
            fmt_ = self.__py_format + '%Y'
            return datetime.datetime.strptime(s_, fmt_)
        else:
            return datetime.datetime.strptime(value, self.__py_format)

    def convert(self, value, method='vectorize'):
        if isinstance(value, str):
            return self.convert_value(value)
        elif isinstance(value, pd.Series):
            if method == 'vectorize':
                return np.vectorize(self.convert_value)(value)
            elif method == 'apply':
                return value.apply(lambda t: self.convert_value(t))
            elif method == 'map':
                return value.map(lambda t: self.convert_value(t))
            elif method == 'builtin':
                return pd.to_datetime(value, format=self.__py_format)
            else:
                raise ('The method parameter contains a wrong value "{0}".'
                       'Acceptable values: vectorize, apply, map, builtin'.format(method))
        else:
            raise ValueError('Wrong parameter value of type{0}.'.format(type(value)))

    @staticmethod
    def sasnum_to_datetime(sasnum):
        """
        Converts a SAS number to Python datetime object
        :param sasnum: SAS datetime number of float or int type (seconds after 1960-01-01)
        :return: Python datetime object
        """
        sec_day = 86400.0  # seconds in a day
        if sasnum < sec_day:
            td = datetime.timedelta(seconds=sasnum)
        else:
            td = datetime.timedelta(days=sasnum / sec_day)
        return datetime.datetime(1960, 1, 1) + td

    @staticmethod
    def sasnum_to_date(sasnum):
        """
        Converts a SAS number to Python datetime object
        :param sasnum: SAS date number of int type (days after 1960-01-01)
        :return: Python date object
        """
        return (datetime.datetime(1960, 1, 1) + datetime.timedelta(days=sasnum)).date()

    @staticmethod
    def DATEw(width: int):
        if width < 5 or width > 11:
            raise ValueError("Parameter w must be the number from 5 to 11")
        formats = {
            5: {'DATE5.': ('%d%b', '18SEP', 'date', 5, 0)},
            6: {'DATE6.': (' %d%b', ' 18SEP', 'date', 6, 0)},
            7: {'DATE7.': ('%d%b%y', '18SEP14', 'date', 7, 0)},
            8: {'DATE8.': (' %d%b%y', ' 18SEP14', 'date', 8, 0)},
            9: {'DATE9.': ('%d%b%Y', '18SEP2014', 'date', 9, 0)},
            10: {'DATE10.': (' %d%b%Y', ' 18SEP2014', 'date', 10, 0)},
            11: {'DATE11.': ('%d-%b-%Y', '18-SEP-2014', 'date', 11, 0)},
            'default': {'DATE.': ('%d%b%y', '18SEP14', 'date', 7, 0)}
        }
        return formats[width]

    @staticmethod
    def DAYw(width: int):
        if width < 2 or width > 32:
            raise ValueError("Parameter w must be a number from 2 to 32")
        fmt_name = 'DAY{}.'.format(width)
        return {fmt_name: ('%d'.rjust(width, ' '), '18'.rjust(width, ' '), 'datepart', width, 0)}

    @staticmethod
    def DDMMYYxw(width: int):
        """
        param x: separator, acceptable values: {'', 'B', 'C', 'D', 'N', 'P', 'S'}
        param w: width
        """
        if width < 2 or width > 10:
            raise ValueError("Parameter width must be a number from 2 to 10.")
        sep = '/'
        fmt_name = 'DDMMYY{}{}.'.format(sep, width)
        fmt = {
            2: {fmt_name: ('%d', '18', 'date', 2, 0)},
            3: {fmt_name: (' %d', ' 18', 'date', 3, 0)},
            4: {fmt_name: ('%d%m', '1809', 'date', 4, 0)},
            5: {fmt_name: ('%d{}%m'.format(sep), '18{}09'.format(sep), 'date', 5, 0)},
            6: {fmt_name: ('%d%m%y', '180914', 'date', 6, 0)},
            7: {fmt_name: (' %d%m%y', ' 180914', 'date', 7, 0)},
            8: {fmt_name: ('%d{}%m{}%y'.format(sep, sep), '18{}09{}14'.format(sep, sep), 'date', 8, 0)},
            9: {fmt_name: (' %d{}%m{}%y'.format(sep, sep), ' 18{}09{}14'.format(sep, sep), 'date', 9, 0)},
            10: {fmt_name: ('%d{}%m{}%Y'.format(sep, sep), '18{}09{}2014'.format(sep, sep), 'date', 10, 0)},
            'default': {fmt_name: ('%d{}%m{}%y'.format(sep, sep), '18{}09{}14'.format(sep, sep), 'date', 8, 0)}
        }
        return fmt[width]

    @staticmethod
    def DDMMYYw(width: int):
        """
        param w: width
        """
        return DT.DDMMYYxw(width=width)

    @staticmethod
    def DOWNAMEw(width: int):
        """
        param w: width
        """
        if width < 1 or width > 32:
            raise ValueError("Parameter width must be a number from 1 to 32.")
        fmt_name = 'DOWNAME{}.'.format(width)
        # !! Additional convertion needed: = 'Saturday'.rjust(w, ' ')[0:w]
        return {fmt_name: ('%A', 'Saturday'.rjust(width, ' ')[0:width], 'datepart', width, 0)}

    @staticmethod
    def MMDDYYxw(width: int):
        """
        param x: separator, acceptable values: {'', 'B', 'C', 'D', 'N', 'P', 'S'}
        param w: width
        """
        if width < 2 or width > 10:
            raise ValueError("Parameter width must be a number from 2 to 10")
        sep = '/'
        fmt_name = 'MMDDYY{}{}.'.format(sep, str(width))
        fmt = {
            2: {fmt_name: ('%m', '09', 'date', 2, 0)},
            3: {fmt_name: (' %m', ' 09', 'date', 3, 0)},
            4: {fmt_name: ('%m%d', '0918', 'date', 4, 0)},
            5: {fmt_name: ('%m{}%d'.format(sep), '09{}18'.format(sep), 'date', 5, 0)},
            6: {fmt_name: ('%m%d%y', '091814', 'date', 6, 0)},
            7: {fmt_name: (' %m%d%y', ' 091814', 'date', 7, 0)},
            8: {fmt_name: ('%m{}%d{}%y'.format(sep, sep), '09{}18{}14'.format(sep, sep), 'date', 8, 0)},
            9: {fmt_name: (' %m{}%d{}%y'.format(sep, sep), ' 09{}18{}14'.format(sep, sep), 'date', 9, 0)},
            10: {fmt_name: ('%m{}%d{}%Y'.format(sep, sep), '09{}18{}2014'.format(sep, sep), 'date', 10, 0)},
            'default': {fmt_name: ('%m{}%d{}%y'.format(sep, sep), '09{}18{}14'.format(sep, sep), 'date', 8, 0)}
        }
        return fmt[width]

    @staticmethod
    def MMDDYYw(width: int):
        """
        param w: width
        """
        return DT.MMDDYYxw(width)

    # TBD: YEARw., MMYYxw., MMYYw., YYMMw., YYMMxw.
    # TBD: MONNAMEw., MONTHw., MONYYw., YYMONw., YYQw., YYQxw., YYQRxw., QTRw., QTRRw.
    # TBD: YYMMDDxw., YYMMDDw., YYMMDDxw.,
    # TBD: WEEKDATEw., WEEKDATXw., WEEKDAYw.

    ## Datetime formats ##

    @staticmethod
    def DATEAMPMwd(width: int, dec: int):
        """
        'DATEAMPM.': ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0)
        param w: width
        param d: the decimal fraction of seconds
        """
        fmt_name = 'DATEAMPM{}.{}'.format(str(width), '' if dec == 0 else str(dec))
        fmt = {
            (7, 0): {fmt_name: ('%d%b%y', '18SEP14', 'datetime', 7, 0)},
            (10, 0): {fmt_name: ('%d%b%y:%H', '18SEP14:17', 'datetime', 10, 0)},
            (11, 0): {fmt_name: (' %d%b%y:%H', ' 18SEP14:17', 'datetime', 11, 0)},
            (12, 0): {fmt_name: ('  %d%b%y:%H', '  18SEP14:17', 'datetime', 12, 0)},
            (18, 0): {fmt_name: ('  %d%b%y:%I:%M %p', '  18SEP14:05:31 PM', 'datetime', 18, 0)},
            (18, 1): {fmt_name: ('  %d%b%y:%I:%M %p', '  18SEP14:05:31 PM', 'datetime', 18, 0)},
            (19, 0): {fmt_name: ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0)},
            (19, 1): {fmt_name: ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0)},
            (20, 0): {fmt_name: (' %d%b%y:%I:%M:%S %p', ' 18SEP14:05:31:45 PM', 'datetime', 20, 0)},
            (21, 0): {fmt_name: ('  %d%b%y:%I:%M:%S %p', '  18SEP14:05:31:45 PM', 'datetime', 21, 0)},
            (21, 1): {fmt_name: ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.0 PM', 'datetime', 21, 1)},
            (23, 3): {fmt_name: ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.043 PM', 'datetime', 23, 3)},
            (26, 6): {fmt_name: ('%d%b%y:%I:%M:%S.%f %p', '18SEP14:05:31:45.043252 PM', 'datetime', 26, 6)},
            (27, 6): {fmt_name: (' %d%b%y:%I:%M:%S.%f %p', ' 18SEP14:05:31:45.043252 PM', 'datetime', 27, 6)},
            ('default', 0): {fmt_name: ('%d%b%y:%I:%M:%S %p', '18SEP14:05:31:45 PM', 'datetime', 19, 0)}
        }
        return fmt[width, dec]

    @staticmethod
    def DATETIMEwd(width: int, dec: int):
        """
        'DATETIME.': ('%d%b%y:%H:%M:%S', '18SEP14:17:31:45', 'datetime', 16, 0),
        param w: width
        param d: the decimal fraction of seconds
        """
        fmt_name = 'DATETIME{}.{}'.format(str(width), str(dec))
        fmt = {
            (7, 0): {fmt_name: ('%d%b%y', '18SEP14', 'datetime', 7, 0)},
            (10, 0): {fmt_name: ('%d%b%y:%H', '18SEP14:17', 'datetime', 10, 0)},
            (11, 0): {fmt_name: (' %d%b%y:%H', ' 18SEP14:17', 'datetime', 11, 0)},
            (12, 0): {fmt_name: ('  %d%b%y:%H', '  18SEP14:17', 'datetime', 12, 0)},
            (15, 0): {fmt_name: ('  %d%b%y:%H:%M', '  18SEP14:17:31', 'datetime', 15, 0)},
            (16, 0): {fmt_name: ('%d%b%y:%H:%M:%S', '18SEP14:17:31:45', 'datetime', 16, 0)},
            (18, 0): {fmt_name: ('  %d%b%y:%H:%M:%S', '  18SEP14:17:31:45', 'datetime', 18, 0)},
            (18, 1): {fmt_name: ('%d%b%y:%H:%M:%S.%f', '18SEP14:17:31:45.0', 'datetime', 18, 1)},
            (19, 0): {fmt_name: (' %d%b%Y:%H:%M:%S', ' 18SEP2014:17:31:45', 'datetime', 19, 0)},
            (19, 1): {fmt_name: (' %d%b%Y:%H:%M:%S', ' 18SEP2014:17:31:45', 'datetime', 19, 0)},
            (20, 0): {fmt_name: ('  %d%b%Y:%H:%M:%S', '  18SEP2014:17:31:45', 'datetime', 20, 0)},
            (20, 1): {fmt_name: ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.0', 'datetime', 20, 1)},
            (21, 0): {fmt_name: ('   %d%b%Y:%H:%M:%S', '   18SEP2014:17:31:45', 'datetime', 21, 0)},
            (21, 1): {fmt_name: (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.0', 'datetime', 21, 1)},
            (21, 2): {fmt_name: ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.04', 'datetime', 21, 2)},  #
            (23, 3): {fmt_name: (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.043', 'datetime', 23, 3)},
            (25, 6): {fmt_name: ('%d%b%Y:%H:%M:%S.%f', '18SEP2014:17:31:45.043252', 'datetime', 25, 6)},
            (26, 6): {fmt_name: (' %d%b%Y:%H:%M:%S.%f', ' 18SEP2014:17:31:45.043252', 'datetime', 26, 6)},
            (27, 6): {fmt_name: ('  %d%b%Y:%H:%M:%S.%f', '  18SEP2014:17:31:45.043252', 'datetime', 27, 6)},
            ('default', 0): {fmt_name: ('%d%b%y:%H:%M:%S', '18SEP14:17:31:45', 'datetime', 16, 0)}
        }
        return fmt[width, dec]

    @staticmethod
    def YYMMDDxw(sep: str, width: int):
        """
        'YYMMDDN.': ('%Y%m%d', '20140918', 'date', 8, 0)
        :param sep: separator in a SAS format, acceptable values are in sas_separators dictionary, excepting ''
        :param width: width
        """
        sep_list = {k: v for k, v in SEPARATORS.items() if k not in ('')}
        separator = sep_list.get(sep)
        w_max = 8 if sep == 'N' else 10
        if width < 2 or width > w_max:
            raise ValueError("Parameter w must be a number from 2 to {} if x = {}.".format(w_max, sep))
        fmt_name = 'YYMMDD{}{}.'.format(sep, width)
        if 2 <= width <= 3:
            py_fmt = ' %y' if width == 3 else '%y'
            dt_sample = '14'.rjust(width, ' ')
        elif width == 4:
            py_fmt, dt_sample = '%y%m', '1409'
        elif width == 5:
            py_fmt = ' %y%m' if sep == 'N' else '%y{s}%m'.format(s=separator[0])
            dt_sample = ('14{s}09'.format(s=separator[0])).rjust(width, ' ')
        elif 6 <= width <= 7:
            py_fmt = ' %y%m%d' if width == 7 else '%y%m%d'
            dt_sample = '140918'.rjust(width, ' ')
        elif 8 <= width <= 9:
            py_fmt = '%Y%m%d' if sep == 'N' else '%y{s}%m{s}%d'.format(s=separator[0])
            py_fmt = ' ' + py_fmt if width == 9 else py_fmt
            dt_sample = ('20140918' if sep == 'N' else '14{s}09{s}18'.format(s=separator[0])).rjust(width, ' ')
        elif width == 10:
            py_fmt = '%Y{s}%m{s}%d'.format(s=separator[0])
            dt_sample = ('2014{s}09{s}18'.format(s=separator[0])).rjust(width, ' ')
        return {fmt_name: (py_fmt, dt_sample, 'date', width, 0)}

    @staticmethod
    def YYMMxw(sep: str, width: int):
        """
        'YYMMN.': ('%Y%m', '201409', 'date', 6, 0)
        :param sep: separator in a SAS format, acceptable values are in sas_separators dictionary, excepting '' and 'B'
        :param width: width
        """
        sep_list = {k: v for k, v in SEPARATORS.items() if k not in ('', 'B')}
        separator = sep_list.get(sep)
        if separator is None:
            raise ValueError("Parameter x must be must be one of charcters: {}.".format(', '.join(sep_list.keys())))
        w_max = 32
        w_min = 4 if sep == 'N' else 5
        if width < w_min or width > w_max:
            raise ValueError("Parameter w must be a number from {} to {} if x = {}.".format(w_min, w_max, sep))
        fmt_name = 'YYMM{}{}.'.format(sep, width)
        if width == 4:
            py_fmt, dt_sample = '%y%m', '1409'
        elif width == 5:
            py_fmt = ' %y%m' if sep == 'N' else '%y{s}%m'.format(s=separator[0])
            dt_sample = ('14{s}09'.format(s=separator[0])).rjust(width, ' ')
        elif width == 6:
            py_fmt = '%Y%m' if sep == 'N' else ' %y{s}%m'.format(s=separator[0])
            dt_sample = '201409' if sep == 'N' else ' 14{s}09'.format(s=separator[0])
        elif width >= 7:
            py_fmt = ' ' * (width - 7) + (' %Y%m' if sep == 'N' else '%Y{s}%m'.format(s=separator[0]))
            dt_sample = ('201409' if sep == 'N' else '2014{s}09'.format(s=separator[0])).rjust(width, ' ')
        return {fmt_name: (py_fmt, dt_sample, 'date', width, 0)}


class TIMEwd(DT):
    def __init__(self, width: int, dec: int):
        """
        'TIME.': ('%H:%M:%S.%f', '17:31:45.043252', 'time', 8, 0)
        param w: width
        param d: the decimal fraction of seconds
        """
        if width < 2 or width > 20:
            raise ValueError("Parameter w must be a number from 2 to 20")
        if width < dec + 1:
            raise ValueError("Parameter d must be must be a number less than w-1")
        self.__sas_format = 'TIME{}.{}'.format(width, '' if dec == 0 else str(dec))
        self.__py_format = '%H:%M:%S.%f'  # This is generic format
        self.__sample = '17:31:45.043252'
        self.__date_type = 'time'
        self.__w = width
        self.__d = dec
        self.__wd_diff = width if dec == 0 else width - dec - 1
        self.__py_format_d = '{{:.{}f}}'.format(self.__d)

    def format_d(self, ms):
        return '' if self.__d == 0 else '.' + (self.__py_format_d.format(ms / 1e6)).split('.')[1]

    def to_sas_datetime(self, dtobj, upper=True):
        """
        :param dtobj: a datetime object, acceptable types:
                - datetime.datetime, datetime.date, datetime.timedelta, dateutil.relativedelta
                - numpy.datetime64
        :param upper: convert output character to upper case if True
        :return: Datetime string in SAS format
        """
        if isinstance(dtobj, datetime.timedelta):
            dtobj = dateutil.relativedelta.relativedelta(seconds=int(dtobj.total_seconds()),
                                                         microseconds=dtobj.microseconds)
        elif isinstance(dtobj, np.datetime64):
            dtobj = pd.to_datetime(dtobj)

        if isinstance(dtobj, datetime.datetime):
            hh, mm, ss, ms = dtobj.hour, dtobj.minute, dtobj.second, dtobj.microsecond
        elif isinstance(dtobj, (datetime.timedelta, dateutil.relativedelta.relativedelta)):
            hh, mm, ss, ms = int(dtobj.days * 24 + dtobj.hours), dtobj.minutes, dtobj.seconds, dtobj.microseconds
        else:
            raise ValueError('Incorrect data type of the dtobj argument!')
        if hh > 99:
            raise ValueError(f'SAS format {self.__sas_format} is not suitable for dtobj = "{dtobj}".')
        if self.__wd_diff == 0:
            out_str_l = ''
        elif 1 <= self.__wd_diff <= 3:
            out_str_l = str(hh)
            if len(out_str_l) > self.__wd_diff:
                raise ValueError(f'Not possible to format the value "{dtobj}" using SAS format {self.__sas_format}.')
        elif 4 <= self.__wd_diff <= 6:
            out_str_l = f'{hh}:{mm:02d}'
        elif self.__wd_diff == 7 and hh > 9:
            out_str_l = f'{hh}:{mm:02d}'
        else:
            out_str_l = f'{hh}:{mm:02d}:{ss:02d}'
        out_str = (out_str_l + self.format_d(ms)).rjust(self.__w, ' ')
        return out_str.upper() if upper else out_str

    def convert_value(self, value: str) -> dateutil.relativedelta:
        """
         :param value: a string with SAS time in TIMEw.d format
         :return: datetime.datetime object if hours < 24, dateutil.relativedelta object otherwise
         """
        hh, mm, ss, ms = 0, 0, 0, 0
        str_parts = value.strip().split('.')
        if len(str_parts) == 1:
            ms = 0
        elif len(str_parts) == 2:
            ms_len = max(6, self.__d)
            ms = int(str_parts[1].ljust(ms_len, '0')) / 10 ** (ms_len - 6)
        else:
            raise ValueError(f'The value "{value}" can not be parsed using {self.__sas_format} format.')
        time_parts = str_parts[0].split(':')
        if len(time_parts) == 1:
            hh = 0 if time_parts[0] == '' else int(time_parts[0])
        elif len(time_parts) == 2:
            hh, mm = int(time_parts[0]), int(time_parts[1])
        elif len(time_parts) == 3:
            hh, mm, ss = int(time_parts[0]), int(time_parts[1]), int(time_parts[2])
        else:
            raise ValueError(f'The value "{value}" can not be parsed using {self.__sas_format} format.')
        if hh < 24:
            return datetime.datetime(1900, 1, 1, hh, mm, ss, int(ms))
        else:
            return dateutil.relativedelta.relativedelta(hours=hh, minutes=mm, seconds=ss, microseconds=ms)


def rand_dates(dt_start, dt_end, n):
    """
    Generating Pandas DatetimeIndex with random dates in range [dt_start, dt_end]
    :param dt_start: start date (a datetime object)
    :param dt_end: end date (a datetime object)
    :param n: Number of samples
    :return:
    """
    mult_ = 10 ** 9
    start_ = dt_start.value // mult_
    end_ = dt_end.value // mult_
    return pd.DatetimeIndex((mult_ * np.random.randint(start_, end_, n, dtype=np.int64)).view('M8[ns]'))


# Datetime format functions #

def dt(format):
    """
    :param format: a character with SAS datetime format. Example: 'DDMMYY.'
    :return: instance of class DT
    """
    return DT(format, 'SAS')


def DDMMYYsw(s):
    """
    :param s: separator in a SAS format, acceptable values are in sas_separators dictionary
    :param w: width of output character
    :return: instance of class DT
    """
    DT.check_sas_sep(s)
    mask = 'DDMMYY{}.'.format(s)
    return DT(mask, 'SAS')


def MMDDYYsw(s):
    """
    :param s: separator in a SAS format, acceptable values are in sas_separators dictionary
    :param w: width of output character
    :return: instance of class DT
    """
    DT.check_sas_sep(s)
    mask = 'MMDDYY{}.'.format(s)
    return DT(mask, 'SAS')


def YYMMDDsw(s):
    """
    :param s: separator in a SAS format, acceptable values are in sas_separators dictionary
    :return: instance of class DT
    """
    DT.check_sas_sep(s)
    mask = 'YYMMDD{}.'.format(s)
    return DT(mask, 'SAS')


def create_date_format(format):
    """
    :param format: a character with Python datetime format. Example: '%d %m %y'
    :return: instance of class DT
    """
    return DT(format, 'Python')
