#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import collections
import datetime as dt
import math
import os
from typing import Union, List, Tuple

import pysaslib.functions.character as funstr
import pysaslib.functions.dateandtime as fundatetime
import pysaslib.functions.finance as funfin
import pysaslib.functions.mathematical as funmath
import pysaslib.functions.statistics as funstat


# if return type is specified as Union[int, float] it means the function returns int or math.nan

class Lag:
    def __init__(self, size, init):
        self._queue_ = collections.deque([init] * size, maxlen=size)

    def lag(self, value):
        pop = self._queue_.pop()
        self._queue_.appendleft(value)
        return pop


def airy(x: float) -> float:
    return funmath.airy(x)


def any(arg: str, start: int, mask: List[bool]) -> int:
    return funstr.any(arg, start, mask)


def beta(a: float, b: float) -> float:
    return funmath.beta(a, b)


def betainv(p: float, a: float, b: float) -> float:
    return funmath.betainv(p, a, b)


def blackclprc(e: float, t: float, f: float, r: float, sigma: float) -> float:
    return funmath.blackclprc(e, t, f, r, sigma)


def blackptprc(e: float, t: float, f: float, r: float, sigma: float) -> float:
    return funmath.blackptprc(e, t, f, r, sigma)


def cats(*ss: Tuple[str, ...]) -> str:
    return funstr.cats(*ss)


def catt(*args: Tuple[str, ...]) -> str:
    return funstr.catt(*args)


def catx(separator: str, *args) -> str:
    values = [a.strip() for a in args if a]
    return separator.join(values)


def cdf(name: str, quantile: float, *args: Tuple[float, ...]):
    return funmath.cdf(name, quantile, *args)


def ceil(x: float) -> float:
    return funmath.ceil(x)


def century(year: int) -> int:
    return fundatetime.century(year)


def cinv(p: float, df: float, nc: float = 0) -> float:
    return funmath.cinv(p, df, nc)


def cnonct(x: float, df: float, p: float) -> float:
    return funmath.cnonct(x, df, p)


def comb(n: int, r: int) -> float:
    return funmath.comb(n, r)


def compare(arg1: str, arg2: str, modifiers: str = None) -> int:
    return funstr.compare(arg1, arg2, modifiers)


def compbl(s: str) -> str:
    return funstr.compbl(s, )


def compound(a: float, f: float, r: float, n: float) -> float:
    return funmath.compound(a, f, r, n)


def compress(source: str, chars: str = None, modifiers: str = None) -> str:
    return funstr.compress(source, chars, modifiers)


def constant(constant: str, parameter: int = None) -> float:
    return funmath.constant(constant, parameter)


def convx(y: float, f: float, *c: Tuple[float, ...]) -> float:
    return funmath.convx(y, f, *c)


def convxp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    return funmath.convxp(a, c, n, k, k0, y)


def count(string: str, characters: str = None, modifiers: str = None) -> int:
    return funstr.count(string, characters, modifiers)


def countc(string: str, characters: str = None, modifiers: str = None) -> int:
    return funstr.countc(string, characters, modifiers)


def countw(string: str, characters: str = None, modifiers: str = None) -> int:
    return funstr.countw(string, characters, modifiers)


def daccdb(p: float, v: float, y: float, r: float) -> float:
    return funmath.daccdb(p, v, y, r)


def daccdbsl(p: float, v: float, y: float, r: float) -> float:
    return funmath.daccdbsl(p, v, y, r)


def daccsl(p: float, v: float, y: float) -> float:
    return funmath.daccsl(p, v, y)


def daccsyd(p: float, v: float, y: float) -> float:
    return funmath.daccsyd(p, v, y)


def dacctab(p: float, v: float, *t: Tuple[float, ...]) -> float:
    return funmath.dacctab(p, v, *t)


def dairy(x: float) -> float:
    return funmath.dairy(x)


def datdif(start: Union[dt.datetime, None],
           end: Union[dt.datetime, None],
           basis: str) -> Union[int, float]:
    if start is None or end is None:
        return math.nan
    else:
        return fundatetime.datdif(start, end, basis)


def datejul(juliandate: int) -> dt.date:
    return fundatetime.datejul(juliandate)


def datepart(datetime: Union[dt.datetime, None]) -> Union[dt.date, None]:
    return fundatetime.datepart(datetime) if datetime is not None else None


def datetime() -> dt.datetime:
    return fundatetime.datetime(True)


def day(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.day(date) if date is not None else math.nan


def depdb(p: float, v: float, y: float, r: float) -> float:
    return funmath.depdb(p, v, y, r)


def depdbsl(p: float, v: float, y: float, r: float) -> float:
    return funmath.depdbsl(p, v, y, r)


def depsl(p: float, v: float, y: float) -> float:
    return funmath.depsl(p, v, y)


def depsyd(p: float, v: float, y: float) -> float:
    return funmath.depsyd(p, v, y)


def deptab(p: float, v: float, *t: Tuple[float, ...]) -> float:
    return funmath.deptab(p, v, *t)


def dequote(arg: str) -> str:
    return funstr.dequote(arg)


def deviance(distr: str, var: float, *params: Tuple[float, ...]) -> float:
    return funmath.deviance(distr, var, *params)


def dhms(date: Union[dt.date, None], hour: float, minute: float, second: float) -> Union[dt.datetime, None]:
    if date is None or math.isnan(hour) or math.isnan(minute) or math.isnan(second):
        return None
    else:
        return fundatetime.dhms(date, hour, minute, second)


def digamma(x: float) -> float:
    return funmath.digamma(x)


def divide(x: float, y: float) -> float:
    return funmath.divide(x, y)


def dur(y: float, f: float, *c: Tuple[float, ...]) -> float:
    return funmath.dur(y, f, *c)


def durp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    return funmath.durp(a, c, n, k, k0, y)


def erf(x: float) -> float:
    return funmath.erf(x)


def erfc(x: float) -> float:
    return funmath.erfc(x)


def fact(n: int) -> int:
    return funmath.fact(n)


def fileexist(file: str) -> bool:
    return os.path.exists(file)


def finance(calculation: str, *args: Tuple) -> float:
    return funfin.finance(calculation, *args)


def find(string: str, characters: str, modifiers: str = None, startpos: int = 1) -> int:
    return funstr.find(string, characters, modifiers, startpos)


def findc(string: str, characters: str, modifiers: str = None, startpos: int = 1) -> int:
    return funstr.findc(string, characters, modifiers, startpos)


def findw(string: str, word: str, startpos: int = None, characters: str = None, modifiers: str = None) -> int:
    return funstr.findw(string, word, startpos, characters, modifiers)


def finv(p: float, ndf: float, ddf: float) -> float:
    return funmath.finv(p, ndf, ddf)


def floor(x: float) -> float:
    return funmath.floor(x)


def fuzz(arg: float) -> float:
    return funmath.fuzz(arg)


def gaminv(p: float, a: float) -> float:
    return funmath.gaminv(p, a)


def gamma(arg: float) -> float:
    return funmath.gamma(arg)


def geodist(lat1: float, lon1: float, lat2: float, lon2: float, miles: bool, radian: bool) -> float:
    return funmath.geodist(lat1, lon1, lat2, lon2, miles, radian)


def hms(hour: float, minute: float, second: float) -> float:
    return fundatetime.hms(hour, minute, second)


def holiday(hol: str, year: int) -> dt.date:
    return fundatetime.holiday(hol, year)


def hour(datetime: Union[dt.datetime, None]) -> float:
    return fundatetime.hour(datetime) if datetime is not None else math.nan


def htmldecode(encoded: str) -> str:
    import pysaslib.functions.webtools as funweb
    return funweb.htmldecode(encoded)


def htmlencode(decoded: str, options: str = None) -> str:
    import pysaslib.functions.webtools as funweb
    return funweb.htmlencode(decoded, options)


def ibessel(n: int, x: float, k: int) -> float:
    return funmath.ibessel(n, x, k)


def index(source: str, excerpt: str) -> int:
    return funstr.index(source, excerpt) if source and excerpt else 0


def indexc(source: str, *excerpt: Tuple[str, ...]) -> int:
    return funstr.indexc(source, *excerpt)


def indexw(source: str, excerpt: str, delimiters: str = ' ') -> int:
    return funstr.indexw(source, excerpt, delimiters)


def int_(d: float) -> int:
    return funmath.int_(d)


def intck(interval: str,
          start: Union[dt.datetime, dt.date, None],
          end: Union[dt.datetime, dt.date, None]) -> Union[int, float]:
    if start is None or end is None:
        return math.nan
    else:
        return fundatetime.intck(interval, start, end)


def intnx(interval: str,
          start: Union[dt.datetime, dt.date, None],
          shift: float,
          alignment: str = 'SAME') \
        -> Union[dt.datetime, None]:
    if start is None or math.isnan(shift):
        return None
    else:
        return fundatetime.intnx(interval, start, int(shift), alignment)


def intrr(freq: float, *c: Tuple[float, ...]) -> float:
    return funmath.intrr(freq, *c)


def irr(freq: float, *c: Tuple[float, ...]) -> float:
    return funmath.irr(freq, *c)


def iswhitespace(c: str) -> bool:
    return funstr.iswhitespace(c)


def jbessel(n: float, x: float) -> float:
    return funmath.jbessel(n, x)


def juldate(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.juldate(date) if date is not None else math.nan


def juldate7(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.juldate7(date) if date is not None else math.nan


def julian(y: int, day: int) -> dt.date:
    return fundatetime.julian(y, day)


def lag(size, init):
    return Lag(size, init)


def largest(n: int, *values: Tuple[float, ...]) -> float:
    return funmath.largest(n, *values)


def left(arg: str) -> str:
    return arg.lstrip() if arg else None


def lgamma(x: float) -> float:
    return funmath.lgamma(x)


def log2(x: float) -> float:
    return funmath.log2(x)


def logbeta(a: float, b: float) -> float:
    return funmath.logbeta(a, b)


def logcdf(name: str, quantile: float, *args: Tuple[float, ...]) -> float:
    return funmath.logcdf(name, quantile, *args)


def logpdf(name: str, x: float, *params: Tuple[float, ...]) -> float:
    return funmath.logpdf(name, x, *params)


def logsdf(distr: str, quantile: float, *args: Tuple[float, ...]) -> float:
    return funmath.logsdf(distr, quantile, *args)


def lowcase(arg1: str) -> str:
    return funstr.lowcase(arg1)


def max(data: List[float]) -> float:
    return funstat.max(data)


def mdy(month: int, day: int, year: int) -> dt.date:
    return fundatetime.mdy(month, day, year)


def mean(data: List[float]) -> float:
    return funstat.mean(data)


def min(data: List[float]) -> float:
    return funstat.min(data)


def minute(datetime: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.minute(datetime) if datetime is not None else math.nan


def missing(arg: str) -> bool:
    return funstr.missing(arg)


def mod(arg1: float, arg2: float) -> float:
    return funmath.mod(arg1, arg2)


def modz(arg1: float, arg2: float) -> float:
    return funmath.modz(arg1, arg2)


def month(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.month(date) if date is not None else math.nan


def mort(a: float, p: float, r: float, n: float) -> float:
    return funmath.mort(a, p, r, n)


def netpv(r: float, freq: float, *c: Tuple[float, ...]) -> float:
    return funmath.netpv(r, freq, *c)


def nliteral(string: str) -> str:
    return funstr.nliteral(string)


def not_(arg: str, start: int, mask: List[bool]) -> int:
    return funstr.not_(arg, start, mask)


def npv(r: float, freq: float, *c: Tuple[float, ...]) -> float:
    return funmath.npv(r, freq, *c)


def nvalid(string: str, nvalid: str = 'V7') -> int:
    return funstr.nvalid(string, nvalid)


def ordinal(n: int, *values: Tuple[float, ...]) -> float:
    return funmath.ordinal(n, *values)


def pdf(name: str, x: float, *params: Tuple[float, ...]) -> float:
    return funmath.pdf(name, x, *params)


def perm(n: int, v: int = None) -> float:
    return funmath.perm(n, v)


def poisson(mean: float, arg: float) -> float:
    return funmath.poisson(mean, arg)


def probbeta(x: float, a: float, b: float) -> float:
    return funmath.probbeta(x, a, b)


def probbnml(p: float, n: int, m: int) -> float:
    return funmath.probbnml(p, n, m)


def probbnrm(x: float, y: float, r: float) -> float:
    return funmath.probbnrm(x, y, r)


def probchi(x: float, df: float, nc: float = 0) -> float:
    return funmath.probchi(x, df, nc)


def probf(x: float, ndf: float, ddf: float) -> float:
    return funmath.probf(x, ndf, ddf)


def probgam(x: float, a: float) -> float:
    return funmath.probgam(x, a)


def probhypr(N: int, K: int, n: int, x: int, r: float = 1.0) -> float:
    return funmath.probhypr(N, K, n, x, r)


def probit(p: float) -> float:
    return funmath.probit(p)


def probnegb(p: float, n: int, m: int) -> float:
    return funmath.probnegb(p, n, m)


def probnorm(x: float) -> float:
    return funmath.probnorm(x)


def probt(x: float, freedom: float, nc: float) -> float:
    return funmath.probt(x, freedom, nc)


def propcase(arg: str, delimiters: str = None) -> str:
    return funstr.propcase(arg, delimiters)


def pvp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    return funmath.pvp(a, c, n, k, k0, y)


def qtr(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.qtr(date) if date is not None else math.nan


def quantile(name: str, probability: float, *params: Tuple[float, ...]) -> float:
    return funmath.quantile(name, probability, *params)


def quote(arg: str, quote: str = '"') -> str:
    return funstr.quote(arg, quote)


def ranbin(seed: int, n: int, p: float) -> float:
    return funmath.ranbin(seed, n, p)


def rand(name: str, seed: int, *args: Tuple[float, ...]) -> float:
    return funmath.rand(name, seed, *args)


def ranexp(seed: int) -> float:
    return funmath.ranexp(seed)


def rangam(seed: int, alpha: float) -> float:
    return funmath.rangam(seed, alpha)


def rannor(seed: int) -> float:
    return funmath.rannor(seed)


def ranpoi(seed: int, mean: int) -> float:
    return funmath.ranpoi(seed, mean)


def rantbl(seed: int, *p: Tuple[float, ...]) -> float:
    return funmath.rantbl(seed, *p)


def ranuni(seed: int) -> float:
    return funmath.ranuni(seed)


def repeat(argument: str, n: int) -> str:
    return funstr.repeat(argument, n)


def right(string: str) -> str:
    return funstr.right(string)


def round_(number: float, digits: int = 0) -> float:
    return funmath.round_(number, digits)


def rounde(argument: float, unit: float) -> float:
    return funmath.rounde(argument, unit)


def roundz(argument: float, unit: float) -> float:
    return funmath.roundz(argument, unit)


def saving(f: float, p: float, r: float, n: float) -> float:
    return funmath.saving(f, p, r, n)


def scan(string: str, count: int = 1, characters: str = None, modifiers: str = None):
    return funstr.scan(string, count=count, characters=characters, modifiers=modifiers)


def scanq(string: str, n: int, characters: str = None) -> str:
    return funstr.scanq(string, n, characters)


def sdf(distr: str, quantile: float, *args: Tuple[float, ...]) -> float:
    return funmath.sdf(distr, quantile, *args)


def second(datetime: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.second(datetime) if datetime is not None else math.nan


def smallest(n: int, *values: Tuple[float, ...]) -> float:
    return funmath.smallest(n, *values)


def sort(array: List[float], convert: bool = False) -> Tuple[int, List[float]]:
    return funmath.sort(array, convert)


def soundex(arg: str) -> str:
    return funstr.soundex(arg)


def strip(arg: str) -> str:
    return funstr.strip(arg)


def subpad(string: str, position: int, length: int = None) -> str:
    return funstr.subpad(string, position, length)


def substr(arg, offset, *args):
    if len(args) == 1:
        return arg[offset - 1:offset - 1 + args[0]]
    else:
        return arg[offset - 1:]


def time() -> dt.time:
    return fundatetime.time()


def timepart(datetime: Union[dt.datetime, None]) -> Union[dt.time, None]:
    return fundatetime.timepart(datetime) if datetime is not None else None


def tinv(p: float, df: float, nc: float = 0) -> float:
    return funmath.tinv(p, df, nc)


def today() -> dt.date:
    return fundatetime.today(True)


def translate(source: str, *args: Tuple[str, ...]) -> str:
    return funstr.translate(source, *args)


def transtrn(source: str, target: str, replacement: str = None) -> str:
    return funstr.transtrn(source, target, replacement)


def trantab(source: str, argto: str, argfrom: str) -> str:
    return funstr.trantab(source, argto, argfrom)


def tranwrd(source: str, target: str, replacement: str = None) -> str:
    return funstr.tranwrd(source, target, replacement=replacement)


def trim(arg: str, *options) -> str:
    return arg.strip(*options) if arg else None


def trimn(arg: str) -> str:
    return funstr.trimn(arg)


def upcase(arg: str) -> str:
    return arg.upper() if arg else None


def urldecode(arg: str) -> str:
    import pysaslib.functions.webtools as funweb
    return funweb.urldecode(arg)


def urlencode(arg: str) -> str:
    import pysaslib.functions.webtools as funweb
    return funweb.urlencode(arg)


def verify(arg: str, *excerpt: Tuple[str, ...]) -> int:
    return funstr.verify(arg, *excerpt)


def week(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.week(date) if date is not None else math.nan


def weekday(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.weekday(date) if date is not None else math.nan


def year(date: Union[dt.datetime, None]) -> Union[int, float]:
    return fundatetime.year(date) if date is not None else math.nan


def yrdif(start: Union[dt.datetime, None],
          end: Union[dt.datetime, None],
          basis: str) -> float:
    if start is None or end is None:
        return math.nan
    else:
        return fundatetime.yrdif(start, end, basis)


def yyq(year: int, quarter: int) -> dt.date:
    return fundatetime.yyq(year, quarter)
