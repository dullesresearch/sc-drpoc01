#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import math
import numpy as np
import pandas as pd

import pysaslib.formats.dateandtime as dtf

POWER = [pow(10, -n) for n in range(0, 33)]


def sf(width=0):
    return SF(width)


def best(width=12):
    return BEST(width)


def f(width=1, decimals=0):
    return F(width, decimals)


def date(width=7):
    return DATE(width)


def dateampm(width=19, decimals=0):
    return DATEAMPM(width, decimals)


def datetime(width=16, decimals=0):
    return DATETIME(width, decimals)


def ddmmyy(width=8):
    return DDMMYY(width)


def mmddyy(width=8):
    return MMDDYY(width)


def time(width=8, decimals=0):
    return TIME(width, decimals)


def yymmdd(width=8):
    return YYMMDDx('D', width)


def yymmddb(width=8):
    return YYMMDDx('B', width)


def yymmddc(width=8):
    return YYMMDDx('C', width)


def yymmddd(width=8):
    return YYMMDDx('D', width)


def yymmddn(width=8):
    return YYMMDDx('N', width)


def yymmddp(width=8):
    return YYMMDDx('P', width)


def yymmdds(width=8):
    return YYMMDDx('S', width)


def yymmc(width=7):
    return YYMMx('C', width)


def yymmd(width=7):
    return YYMMx('D', width)


def yymmn(width=6):
    return YYMMx('N', width)


def yymmp(width=7):
    return YYMMx('P', width)


def yymms(width=7):
    return YYMMx('S', width)


def z(width=1, decimals=0):
    return Z(width, decimals)


class BEST:
    def __init__(self, width):
        if width < 1 or width > 32:
            raise ValueError("Parameter w must be a number from 1 to 32.")
        self.w = width
        self.max_fixed = -int('9' * (self.w - 1)) if self.w > 1 else None, int('9' * self.w)
        self.min_fixed = -float('0.' + '0' * (self.w - 4) + '1') if self.w > 1 else None, float('0.' + '0' * (self.w - 3) + '1')

    def put(self, value):
        if pd.isna(value):
            return np.nan
        else:
            # avail_space = self.w if value >= 0 else self.w - 1
            dec_part, int_part = math.modf(value)
            if value == 0:
                return '0'
            elif self.min_fixed[1] <= value <= self.max_fixed[1]:
                if dec_part == 0:
                    return str(value)
                else:
                    d_ = self.w - len(str(int(int_part))) - 1
                    fmt_ = '{{: {}.{}f}}'.format(self.w, d_ if d_ >= 0 else 0)
                    return fmt_.format(value)
            elif self.min_fixed[0] <= value <= self.max_fixed[0]:
                if dec_part == 0:
                    return str(value)
                else:
                    d_ = self.w - len(str(int(int_part))) - 2
                    fmt_ = '{{: {}.{}f}}'.format(self.w, d_ if d_ >= 0 else 0)
                    return fmt_.format(value)
            else:
                return f"{value:e}"


class DATE:
    def __init__(self, width):
        self.width = width
        self.dt = dtf.DT(dtf.DT.DATEw(width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class DATEAMPM:
    def __init__(self, width, decimals):
        if width < 7 or width > 40:
            raise ValueError("Parameter width must be a number from 7 to 40.")
        if decimals >= width - 1:
            raise ValueError("Parameter dec must be must be a number less than width–1.")
        self.dt = dtf.DT(dtf.DT.DATEAMPMwd(width, decimals), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class DATETIME:
    def __init__(self, width, decimals=0):
        if width < 7 or width > 40:
            raise ValueError("Parameter w must be a number from 7 to 40")
        if decimals >= width - 1:
            raise ValueError("Parameter d must be must be a number less than w–1")
        self.dt = dtf.DT(dtf.DT.DATETIMEwd(width, decimals), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class DDMMYY:
    def __init__(self, width):
        self.width = width
        self.dt = dtf.DT(dtf.DT.DDMMYYw(width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class F:
    def __init__(self, width, decimals):
        self.width = width
        self.decimals = decimals
        self.fmt = '{{:{}.{}f}}'.format(width, decimals)

    def put(self, value):
        if math.isnan(value):
            return '.'
        else:
            return self.fmt.format(value).strip()


class MMDDYY:
    def __init__(self, width):
        self.width = width
        self.dt = dtf.DT(dtf.DT.MMDDYYw(width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class SF:
    def __init__(self, width):
        self.width = width

    def put(self, value):
        return value[:self.width]


class TIME:
    def __init__(self, width, decimals):
        self.width = width
        self.decimals = decimals
        self.dt = dtf.TIMEwd(width, decimals)

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class YYMMDDN:
    def __init__(self, width):
        self.width = width
        self.dt = dtf.DT(dtf.DT.YYMMDDxw(sep='N', width=width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class YYMMN:
    def __init__(self, width):
        self.width = width
        self.dt = dtf.DT(dtf.DT.YYMMxw(sep='N', width=width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class YYMMDDx:
    def __init__(self, x, width):
        self.width = width
        self.x = x
        self.dt = dtf.DT(dtf.DT.YYMMDDxw(sep=x, width=width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class YYMMx:
    def __init__(self, x, width):
        self.width = width
        self.x = x
        self.dt = dtf.DT(dtf.DT.YYMMxw(sep=x, width=width), type='dictionary')

    def put(self, value):
        if isinstance(value, float) and math.isnan(value):
            return '.'
        else:
            return self.dt.put(value, upper=True)


class Z:
    def __init__(self, width, decimals):
        if width < 1 or width > 32:
            raise ValueError("Parameter w must be a number from 1 to 32.")
        if decimals < 0 or decimals > 31:
            raise ValueError("Parameter d must be a number from 0 to 31.")
        if width - decimals < 1:
            raise ValueError("Parameter w must be less than d.")
        self.w = width
        self.d = decimals
        self._fmt = '{{:0{}.{}f}}'.format(self.w, self.d)

    def put(self, value):
        return self._fmt.format(value)
