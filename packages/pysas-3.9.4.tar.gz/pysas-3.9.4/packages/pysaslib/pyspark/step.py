#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import itertools
import typing
from collections import OrderedDict

import pandas as pd
import pyspark.sql.functions as functions
import pyspark.sql.types as types
from pyspark.sql import DataFrame, SparkSession, Column
from pyspark.sql.types import StructField

import pysaslib.pyspark.libname as libname
import pysaslib.tools.messages as msg

import pysaslib.pandas.step

catch = False
strict = False
cache = False


def init(log_step=None, columns=None, catch=False, strict=False, cache=True):
    globals()['catch'] = catch
    globals()['strict'] = strict
    globals()['cache'] = cache
    msg.init(log_step, columns=columns, catch=catch)


def job(spark, sequence, step, desc):
    spark.sparkContext.setJobDescription("{} {}".format(sequence, step))
    spark.sparkContext.setLocalProperty("callSite.short", desc)


def print_schema(pdf: DataFrame, logger):
    # TODO: print to the logger instead of stdout, works only for local spark
    if pdf:
        pdf.printSchema()
    else:
        print("Empty data set")


def log(name: str, outputs=None):
    if cache:
        for output in (outputs or {}).values():
            output.cache()
    msg.log(name, outputs,
            lambda pdf: (pdf.count(), pdf.columns) if pdf else (None, []),
            lambda pdf, logger: print_schema(pdf, logger))


arrays: typing.List[str] = []


def output(_pdf_: pd.DataFrame, outputs, index, out_columns):
    _df_ = pd.DataFrame(outputs, index=index,
                        columns=out_columns)
    _pdf_ = _pdf_.merge(_df_, how='right', left_index=True, right_index=True)

    # for the variable which is both input and output
    # we create a new variable with prefix '#' in the temporary frame.
    # Afterwards do some renaming and coping to maintain the order of the columns in the data frame
    duplicated = list(filter(lambda c: c.startswith('#'), _pdf_.columns))
    orig = [c[1:] for c in duplicated]

    _pdf_[orig] = _pdf_[duplicated]
    _pdf_ = _pdf_.drop(duplicated, axis=1)
    return _pdf_


def combine(left, right):
    common = set(left.columns).intersection(right.columns)
    r = right.rename(columns={n: "#" + n for n in common})
    m = pd.merge(left, r, how='right', right_index=True, left_index=True, )
    for n in common:
        m[n] = m['#' + n]
    m.drop(columns=["#" + n for n in common], inplace=True)
    return m


# verify that PDF is consistent  with the schema
def verify(pdf: pd.DataFrame, schema: typing.List[StructField]):
    for c, t, s in zip(pdf.columns, pdf.dtypes, schema):
        if c != s.name:
            raise Exception("Name mismatch between Pandas PDF '{}' and Spark schema '{}'".format(c, s.name))
        good = frozenset([('bool', 'DoubleType'),
                          ('bool', 'BooleanType'),
                          ('float64', 'DoubleType'),
                          ('float64', 'IntegerType'),
                          ('float32', 'FloatType'),
                          ('int32', 'DoubleType'),
                          ('int32', 'IntegerType'),
                          ('int64', 'DoubleType'),
                          ('string', 'StringType'),
                          ('object', 'StringType'),
                          ('datetime64[ns]', 'TimestampType'), ])
        if (str(t), str(s.dataType)) not in good:
            raise Exception(
                "Type mismatch for name {} between Pandas PDF '{}' and Spark schema '{}'".format(c, t, s.dataType))


def run(df: DataFrame = None, groupby=None, func=None, in_columns=None, out_columns=None, schema=None, split=False,
        bucket=None):
    if groupby:
        return by(df=df, groupby=groupby, func=func,
                  in_columns=in_columns, bucket=bucket, out_columns=out_columns, schema=schema, split=split)

    else:
        output_schema = combine_schemas(df.schema, schema)

        def iter(iterator):
            for pdf in iterator:
                calculated = [list(func(row)) for row in pdf[in_columns].itertuples(name=None)]
                df = pd.DataFrame(itertools.chain(*calculated), columns=["_n_"] + out_columns)
                df.set_index("_n_", inplace=True)
                combined = combine(pdf, df)
                if strict:
                    verify(combined, output_schema.fields)
                yield combined

        return df.mapInPandas(iter, schema=output_schema)


def combine_schemas(orig, calculated):
    used = set([f.name for f in orig.fields])
    struct = types.StructType(orig.fields + [f for f in calculated if not f.name in used])
    return struct


def by(df: DataFrame,
       groupby: typing.List[str],
       func: typing.Callable,
       split: bool = False,
       in_columns: typing.List[str] = None,
       out_columns: typing.List[str] = None,
       schema: types.StructType = None,
       bucket: Column = None,
       ) -> DataFrame:
    """Group rows by ``groupby`` and apply ``func`` to each row in ``df``

    This function passes most parameters to :func:`pysaslib.pandas.step.by`.
    The other parameters are listed here:

    :param schema: The schema that maps the ``func`` output onto columns in
        the new Spark dataframe
    :param bucket: The column used to distribute ``by`` calls across the
        Spark cluster
    :return: The copy of ``df`` modified by ``func``
    """
    output_schema = combine_schemas(df.schema, schema)
    bucket_column = "#bucket#"

    def by_group_func(pdf: pd.DataFrame) -> pd.DataFrame:
        if bucket_column in pdf.columns:
            pdf.drop(columns=bucket_column, inplace=True)

        by_output = pysaslib.pandas.step.by(
            df=pdf,
            groupby=groupby,
            func=func,
            split=split,
            in_columns=in_columns,
            out_columns=out_columns,
        )

        if strict:
            verify(by_output, output_schema.fields)

        return by_output

    if bucket is None:
        return (
            df
                .groupby(groupby)
                .applyInPandas(by_group_func, schema=output_schema)
        )
    else:
        return (
            df
                .withColumn(bucket_column, bucket)
                .groupBy([bucket_column])
                .applyInPandas(by_group_func, schema=output_schema)
        )


def legacy_run(df, func=None,
               in_columns: typing.List[str] = None, out_columns: typing.List[str] = None):
    global arrays
    if out_columns:
        rows = []
        for tuple in df[in_columns + arrays].itertuples():
            rows.append(func(*tuple))
        out = pd.DataFrame(rows, columns=out_columns)
        overwrite = set(df.columns).intersection(out.columns)
        concat = pd.concat([df.drop(arrays, axis=1), out.drop(overwrite, axis=1)], axis=1)
        arrays = []
        concat[list(overwrite)] = out[list(overwrite)]
        return concat
    else:
        for tuple in df[in_columns + arrays].itertuples():
            func(*tuple)


def merge(frames: typing.List[DataFrame], by=[], how='outer', indicators=()):
    left = frames[0]
    proper = dict([(n.upper(), n) for n in left.columns])
    right = adjust_capitalization(frames[1], proper)
    common = set(left.columns).intersection(right.columns) - set(by)

    if indicators:
        condition = [left[column] == right[column] for column in by]

        m = left.join(right, condition, how)
        if indicators[0]:
            all_left_nulls = functions.lit(True)
            for column in by:
                all_left_nulls = all_left_nulls & left[column].isNull()
            m = m.withColumn(indicators[0],
                             functions.when(all_left_nulls, 0)
                             .otherwise(1))
        if indicators[1]:
            all_right_nulls = functions.lit(True)
            for column in by:
                all_right_nulls = all_right_nulls & right[column].isNull()
            m = m.withColumn(indicators[1],
                             functions.when(all_right_nulls, 0)
                             .otherwise(1))
        # remove duplicate entries, keeping the original ordering
        def get_column(column):
            if column in common or column in by:
                return functions.coalesce(left[column], right[column]).alias(column)
            return column
        ordering = [get_column(k) for nm, k in enumerate(m.columns) if k not in m.columns[:nm]]
        return m.select(ordering)
    else:
        for n in common:
            right = right.withColumnRenamed(n, "#" + n)
        m = left.join(right, how=how, on=by)
        for n in common:
            m = m.withColumn(n, functions.coalesce(left[n], right['#' + n]))
        for n in common:
            m = m.drop("#" + n)
        return m


def adjust_capitalization(df: DataFrame, proper) -> DataFrame:
    """
    :return adjusted column capitalization according to the map proper
    """
    adjust = [n for n in df.columns if n.upper() in proper.keys() and proper[n.upper()] != n]
    for n in adjust:
        df = df.withColumnRenamed(n, proper[n.upper()])
    return df


class CaseInsensitiveField:
    def __init__(self, field):
        self.field = field

    def __eq__(self, other):
        return self.field.name.upper() == other.field.name.upper()

    def __hash__(self):
        return self.field.name.upper().__hash__()

    def generate_null(self):
        return functions.lit(None).cast(self.field.dataType)


def concat(spark: SparkSession, frames: typing.List[DataFrame]) -> DataFrame:
    """
    :param frames:
    :return: concatenated frames, similar to pd.concat, but matches columns without case sensitivity
    """
    final_columns = OrderedDict()
    for df in frames:
        for field in df.schema.fields:
            final_columns[CaseInsensitiveField(field)] = 1

    schema = types.StructType([column.field for column in final_columns.keys()])
    resulting_df = spark.createDataFrame([], schema=schema)
    for df in frames:
        existing_fields = set(CaseInsensitiveField(field) for field in df.schema.fields)
        missing_fields = final_columns.keys() - existing_fields
        for missing_field in missing_fields:
            df = df.withColumn(missing_field.field.name, missing_field.generate_null())
        resulting_df = resulting_df.unionByName(df)

    return resulting_df


class Connection:
    def __init__(self, spark, dbtype, url=None, user=None, password=None):
        self.spark = spark
        self.driver = libname.JDBC_DRIVERS.get(dbtype)
        self.url = url
        self.user = user
        self.password = password

    def read_sql_query(self, query, partitions=None):
        if not partitions:
            partitions = self.spark.sparkContext.defaultParallelism
        return self.spark.read.format("jdbc") \
            .option("url", self.url) \
            .option("fetchsize", 10000) \
            .option("dbtable", "(" + query + ") p") \
            .option("user", self.user) \
            .option("password", self.password) \
            .option("driver", self.driver) \
            .load() \
            .repartition(partitions)


def connect(spark, dbtype, url=None, user=None, password=None):
    return Connection(spark, dbtype, url=url, user=user, password=password)


def keep(df: DataFrame, columns):
    return df.select(*columns)


def drop(df: DataFrame, columns):
    return df.drop(*columns)


def prefix(df: DataFrame, prefix: str) -> typing.List[str]:
    prefix = prefix.upper()
    return [f.name for f in list(df.schema.fields) if f.name.upper().startswith(prefix)]
