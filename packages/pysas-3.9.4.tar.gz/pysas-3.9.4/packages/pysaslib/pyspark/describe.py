from typing import List

from pyspark.sql.functions import lit, expr, broadcast, when, col


def describe(
        spark,
        df,
        groupby: List[str] = None,
        class_: List[str] = None,
        select: List[str] = None,
        nway=False,
        statistics: List[str] = None,
):
    # TODO: PG: temporary workaround to support the current tests, to be removed ASAP
    groupby = class_ if class_ else groupby

    supported_stats = ["N", "MIN", "MAX", "MEAN", "STD", "SUM"]
    if not statistics:
        statistics = supported_stats
    if len(set(statistics) - set(supported_stats)) > 0:
        raise Exception("Unsupported stats: {}".format(set(statistics) - set(supported_stats)))

    stats_df = spark.createDataFrame(enumerate(statistics), ["stat_idx", "_STAT_"])

    if nway == True:
        masks = [2 ** len(groupby) - 1]
    else:
        masks = list(range(2 ** len(groupby)))

    small_dfs = [stats_per_value(df, groupby, mask, statistics, stats_df, select) for mask in masks]
    big_df = small_dfs[0]
    for small_df in small_dfs[1:]:
        big_df = big_df.unionByName(small_df)

    ready_df = big_df.orderBy("_TYPE_", *groupby, "stat_idx").select(
        *groupby, "_TYPE_", "_FREQ_", "_STAT_", *select
    )

    if len(statistics) == 1:
        ready_df = ready_df.drop("_STAT_")

    return ready_df


stats_to_spark_functions = {"N": "COUNT"}


def statscol(c, stats):
    cond_parts = [
        when(col("_STAT_") == stat, col(f"{stats_to_spark_functions.get(stat, stat)}({c})"))
        for stat in stats
    ]
    cond = cond_parts[0]
    for cond_part in cond_parts[1:]:
        cond = cond_part.otherwise(cond)
    return cond.alias(c)


def stats_per_value(df, original_groupby, mask, stats, stats_df, select):
    groupby = [column for idx, column in enumerate(sorted(original_groupby)) if 2 ** idx & mask]
    result = (
        df.groupBy(groupby)
            .agg(
            expr("count(*)").alias("_FREQ_"),
            *[expr(stats_to_spark_functions.get(s, s) + f"({c})") for s in stats for c in select],
        )
            .join(broadcast(stats_df))
            .select(
            *groupby,
            "_STAT_",
            "_FREQ_",
            lit(mask).alias("_TYPE_"),
            "stat_idx",
            *[statscol(c, stats) for c in select],
        )
    )

    # add columns hidden by mask
    field_name_to_type = {field.name.lower(): field.dataType for field in df.schema.fields}
    for column in original_groupby:
        if column in groupby:
            continue  # already present
        result = result.withColumn(column, lit(None).cast(field_name_to_type[column.lower()]))

    return result
