#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import traceback

from pyspark.sql import DataFrame

import pysaslib.pandas.checkpoint as pandas_checkpoint
from pysaslib.pyspark import libname, step


class Checkpoint:

    def __init__(self, spark, path, modes=None, case=True, sort=None):
        self.checkpoint = pandas_checkpoint.Checkpoint(path, modes, case=case, sort=sort)
        self.spark = spark
        self.modes = modes

    def run(self, actual: DataFrame, libref: str, dataset: str, generation: int, tag=None):
        if "verify" in self.modes:
            self.verify(actual, libref, dataset, generation, tag)
        if "restore" in self.modes:
            return self.restore(libref, dataset, generation)
        else:
            return actual

    # noinspection PyBroadException
    def verify(self, actual: DataFrame, libref: str, dataset: str, generation: int, tag=None):
        try:
            self.checkpoint.verify(actual.toPandas() if actual else None, libref, dataset, generation, tag)
        except:
            if not step.catch:
                raise
            else:
                print("==================== Exception for step {}".format(tag))
                traceback.print_exc()

    def restore(self, libref, dataset, generation):
        return libname.pandas2spark(self.spark, self.checkpoint.restore(libref, dataset, generation))
