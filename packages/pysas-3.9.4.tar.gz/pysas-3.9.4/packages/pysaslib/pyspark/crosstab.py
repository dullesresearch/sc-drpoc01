from pyspark.sql import functions as F
import pandas as pd


def display(pdf):
    pd.set_option("display.max_column", None)
    print(pdf)


def rename_base_cols(df):
    return df.rename(columns={"COUNT": "Frequency", "PERCENT": "Percent"})


def one_column_freq(df):
    total = df["COUNT"].sum()
    report = rename_base_cols(df)
    report["Cumulative Frequency"] = report["Frequency"].cumsum()
    report["Cumulative Percent"] = round(report["Cumulative Frequency"] / total * 100, 2)
    return report


def two_columns_freq(pdf, column1, column2, all_variants):
    report = rename_base_cols(
        pdf.groupby([column1, column2], dropna=False)
        .sum()
        .reset_index()
        .merge(all_variants, how="outer", left_on=[column1, column2], right_on=[column1, column2])
        .fillna(value={"COUNT": 0})
    )

    row_stats = report.groupby(column1, dropna=False).sum()["Frequency"]
    col_stats = report.groupby(column2, dropna=False).sum()["Frequency"]

    report = (
        report.set_index(column1)
        .join(row_stats, rsuffix=" Row")
        .reset_index()
        .set_index(column2)
        .join(col_stats, rsuffix=" Column")
        .reset_index()
    )

    total = report["Frequency"].sum()
    report["Percent"] = report["Frequency"] / total * 100
    report["Row Pct"] = report["Frequency"] / report["Frequency Row"] * 100
    report["Col Pct"] = report["Frequency"] / report["Frequency Column"] * 100

    df = report.pivot(
        index=column1, columns=column2, values=["Frequency", "Percent", "Row Pct", "Col Pct"]
    )
    df.columns = [" ".join([str(c) for c in col]).strip() for col in df.columns.values]
    df = df.join(row_stats.rename("Frequency Total")).reset_index()
    df["Percent Total"] = df["Frequency Total"] / total * 100
    columns_stats = df.sum(axis=0)
    columns_stats[column1] = "Total"
    for statname in columns_stats.keys():
        if (not statname.startswith("Frequency")) and (not statname.startswith("Percent")):
            columns_stats[statname] = None

    df.loc["Total"] = columns_stats
    return df.round(2)


def get_all_variants(df, column1, column2):
    return df[[column1]].merge(df[[column2]], how="cross").drop_duplicates()


def three_columns_freq(df, column1, column2, column3):
    for index, value in enumerate(df[column1].unique()):
        print(f"Table {index+1} of {column2} by {column3}")
        print(f"Controlling for {column1}={value}")
        display(
            two_columns_freq(
                df[df[column1] == value], column2, column3, get_all_variants(df, column2, column3)
            )
        )


def pre_aggreagte(grouped_pdf, columns, by, missing):
    if missing is False:
        filtered = grouped_pdf.dropna(subset=columns).copy()
    else:
        filtered = grouped_pdf.copy()

    if len(by) > 0:
        counts_in_by_groups = filtered.groupby(by, dropna=False).sum().reset_index()
        filtered = filtered.merge(
            counts_in_by_groups, left_on=by, right_on=by, suffixes=("", "_total")
        )
        percent = round(filtered["COUNT"] / filtered["COUNT_total"] * 100, 2)
    else:
        percent = round(filtered["COUNT"] / filtered.sum()["COUNT"] * 100, 2)

    filtered["PERCENT"] = percent

    # ensure all objects are stringified
    for column in filtered:
        if pd.api.types.is_object_dtype(filtered[column]):
            filtered[column] = filtered[column].astype("str")

    return filtered[by + columns + ["COUNT", "PERCENT"]]


def show_freq(pdf, columns):
    if len(columns) == 1:
        display(one_column_freq(pdf))
    if len(columns) == 2:
        print(f"Table of {columns[0]} by {columns[1]}")
        display(
            two_columns_freq(
                pdf, columns[0], columns[1], get_all_variants(pdf, columns[0], columns[1])
            )
        )
    if len(columns) == 3:
        three_columns_freq(pdf, columns[0], columns[1], columns[2])

    return pdf


def show_freq_or_list(pdf, columns, list_):
    if list_:
        display(one_column_freq(pdf))
    else:
        show_freq(pdf, columns)


def freq_report(df, columns, by, agg, missing, list_):
    # first, group in spark
    grouped_pdf = df.groupBy(by + columns).agg(agg).orderBy(by + columns).toPandas()
    # then, add PERCENT column and handle missing flag
    pdf = pre_aggreagte(grouped_pdf, columns, by, missing)

    if len(by):
        groups = (
            pdf.groupby(by, dropna=False)
            .count()
            .reset_index()[by]
            .sort_values(by=by, na_position="first")
        )
        for group in groups.itertuples():
            header = " ".join(f"{gr[0]}={gr[1]}" for gr in zip(by, group[1:]))
            print("-------- " + header + " --------")
            small_df = pdf
            for column, value in zip(by, group[1:]):
                if value != value:  # nan
                    small_df = small_df[small_df[column].isna()]
                else:
                    small_df = small_df[small_df[column] == value]

            small_df = small_df.drop(columns=by).copy()
            show_freq_or_list(small_df, columns, list_)
    else:
        show_freq_or_list(pdf, columns, list_)

    return pdf


def crosstab(
    spark, df, tables=[], by=[], out=False, list_=False, missing=False, weight=None, title1=None
):
    if tables == []:  # 01-default case
        tables = [[c] for c in df.columns]

    agg = (F.sum(weight) if weight else F.count("*")).alias("COUNT")
    last_table = None
    for table in tables:
        if title1:
            print(title1)
        last_table = freq_report(df, table, by, agg, missing, list_=list_)
        print()
    if out:
        return spark.createDataFrame(last_table)
