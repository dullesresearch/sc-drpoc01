from typing import List

import pysaslib.pyspark.crosstab
import pysaslib.pyspark.describe
import pysaslib.pyspark.transpose


def transpose(spark,
              df,
              groupby: List[str] = None,
              value_vars: List[str] = None,
              names: List[str] = None,
              prefix='COL'):
    return pysaslib.pyspark.transpose.transpose(spark,
                                                df=df, groupby=groupby,
                                                value_vars=value_vars,
                                                names=names,
                                                prefix=prefix)


def crosstab(spark,
             df,
             tables: List[List[str]] = [],
             groupby: List[str] = [],
             out: bool = False,
             list_: bool = False,
             missing: bool = False,
             weight: str = None,
             title1: str = None):
    return pysaslib.pyspark.crosstab.crosstab(spark, df, tables, groupby, out, list_, missing, weight, title1)


def contents(data):
    print("Number of rows: " + str(data.count()))
    data.printSchema()


def describe(
        spark,
        df,
        groupby: List[str] = None,
        class_: List[str] = None,
        select: List[str] = None,
        nway=False,
        min=None,
        max=None,
        sum=None,
        count=None,
        std=None):
    statistics = []
    if min:
        statistics.append("MIN")
    if max:
        statistics.append("MAX")
    if sum:
        statistics.append("SUM")
    if count:
        statistics.append("N")
    if std:
        statistics.append("STD")
    return pysaslib.pyspark.describe.describe(spark, df,
                                              groupby=groupby,
                                              class_=class_,
                                              select=select,
                                              nway=nway,
                                              statistics=statistics)
