#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import abc
import builtins
import math
import os

import pandas as pd
import pyspark.sql.utils
from pysaslib.tools import sas7bdat, messages
from pyspark.sql import types
from pyspark.sql.dataframe import DataFrame
from pyspark.sql.functions import col

JDBC_DRIVERS = {"oracle": "oracle.jdbc.driver.OracleDriver",
                "teradata": "com.teradata.jdbc.TeraDriver",
                "db2": "com.ibm.db2.jcc.DB2Driver",
                }


class disk:

    def __init__(self, spark, path, head: int = None):
        self.__dict__["_members_"] = {}
        self.__dict__["_dirty_"] = builtins.set()
        self.__dict__["_spark_"] = spark
        self.__dict__["_head_"] = head
        self.__dict__["_path_"] = path

    def __getattr__(self, member):
        lower = member.lower()
        filename = self._path_ + "/" + member.lower() + ".parquet"
        if lower in self._members_:
            return self._members_[lower]
        else:
            try:
                frame = self._spark_.read.load(filename)
                self._members_[lower] = frame
                return frame
            except pyspark.sql.utils.AnalysisException:
                # fallback: load sas7bdat file from local file system and convert to pyspark DataFrame
                # useful for testing and POC
                filename = self._path_ + "/" + member.lower() + ".sas7bdat"
                if os.path.exists(filename):
                    pdf = sas7bdat.read_sas(filename, nrows=self._head_)
                    print("loaded Spark frame from local SAS data set: " + filename)
                    frame = pandas2spark(self._spark_, pdf)
                    self._members_[lower] = frame
                    return frame
                else:
                    raise

    def __setattr__(self, member, frame):
        lower = member.lower()
        self._members_[lower] = frame
        self._dirty_.add(lower)

    # Save all newly created data frames to the parquet file
    def save(self):
        for member in self._dirty_:
            filename = self._path_ + "/" + member.lower() + ".parquet"
            df = self._members_[member]
            df.write.parquet(filename, mode='overwrite')
            print("NOTE: The data set {} has {} observations and {} variables."
                  .format(filename, self._spark_.read.parquet(filename).count(), len(df.schema.fields)))


def pandas2spark(spark, pdf):
    schema = []
    for col_name in pdf.select_dtypes('string').columns:
        pdf[col_name] = pdf[col_name].replace({pd.NA: None})
    for (n, t) in zip(pdf.columns, pdf.dtypes):
        pyspark_type = {
            "string": types.StringType(),
            "object": types.StringType(),
            "datetime64[ns]": types.TimestampType(),
        }.get(str(t))
        if not pyspark_type:
            pyspark_type = types.DoubleType()
        schema.append(types.StructField(n, pyspark_type, True))
        if str(t) in ["float32", "float64"]:
            pdf[n].replace({math.nan: None}, inplace=True)

    frame = spark.createDataFrame(pdf, schema=types.StructType(schema))
    return frame


class database:
    __metaclass__ = abc.ABCMeta

    def __init__(self, spark, schema=None,
                 url: str = None, user: str = None, password: str = None, head: int = None):
        """
        """
        self.__dict__["_members_"] = {}
        self.__dict__["_dirty_"] = set()
        self.__dict__["_spark_"] = spark
        self.__dict__["_head_"] = head
        self.__dict__["_driver_"] = JDBC_DRIVERS.get(self.__class__.__name__)

        self.__dict__["_schema_"] = schema
        self.__dict__["_url_"] = url
        self.__dict__["_user_"] = user
        self.__dict__["_password_"] = password

    def __getattr__(self, member: str):
        lower = member.lower()
        return self.sysread(member)

    # noinspection SqlNoDataSourceInspection
    def sysread(self, member, partition=None):
        if member in self._members_:
            return self._members_[member]
        else:
            table = (self._schema_ + "." if self._schema_ else "") + member
            option = self._spark_.read.format("jdbc") \
                .option("url", self._url_) \
                .option("fetchsize", 10000) \
                .option("dbtable", self.limit(table, self._head_) if self._head_ else table) \
                .option("user", self._user_) \
                .option("password", self._password_) \
                .option("driver", self._driver_)

            if partition:
                column = partition.get("column")
                lower = partition.get("lower")
                upper = partition.get("upper")
                if not upper and not lower:
                    minmax: DataFrame = self._spark_.read.format("jdbc") \
                        .option("url", self._url_) \
                        .option("query",
                                "select min({}) as LOWER_, max({}) as UPPER_ from {}".format(column, column, table)) \
                        .option("user", self._user_) \
                        .option("password", self._password_) \
                        .option("driver", self._driver_) \
                        .load().first()
                    if not lower:
                        lower = int(minmax.LOWER_)
                    if not upper:
                        upper = int(minmax.UPPER_)
                partitions = partition.get("count")
                if not partitions:
                    executors = self._spark_.sparkContext.defaultParallelism
                    partitions = executors * 10 if executors else 16
                option = option \
                    .option("partitionColumn", column) \
                    .option("lowerBound", lower) \
                    .option("upperBound", upper) \
                    .option("numPartitions", partitions)
                if messages.logger:
                    messages.logger.info(
                        "Loading frame %s with partition column %s in the range %i:%i with %i partitions...",
                        member, column, lower, upper, partitions)

                # partitionColumn, lowerBound, upperBound

            df: DataFrame = option.load()
            for field in df.schema.fields:
                if field.dataType.simpleString().startswith('decimal'):
                    df = df.withColumn(field.name, col(field.name).cast('double'))
            self._members_[member] = df
            return self._members_[member]

    def __setattr__(self, member: str, frame: pd.DataFrame):
        lower = member.lower()
        self._members_[lower] = frame
        self._dirty_.add(lower)

    @abc.abstractmethod
    def limit(self, table, head):
        pass

    # Saving to database disabled for security reasons
    def save(self):
        for member in self._dirty_:
            pass


class teradata(database):

    def __init__(self, spark, server=None, schema=None, user=None, password=None, head: int = None):
        url = "jdbc:teradata://{}/database={},DBS_PORT=1025".format(server, schema)
        super().__init__(spark, schema=schema, url=url, user=user, password=password, head=head)

    def limit(self, table, head):
        return "(select top {} * from {}) tab".format(head, table)
        pass


class oracle(database):

    def __init__(self, spark, schema=None, user=None, password=None, path=None, head: int = None):
        if "/" in path:
            (server, database) = path.split("/")
            url = "jdbc:oracle:thin:@//{}/{}".format(server, database)
        else:
            url = "jdbc:oracle:thin:@//{}".format(path)

        super().__init__(spark, schema=schema, url=url, user=user, password=password, head=head)

    def limit(self, table, head):
        return "(select * from {} fetch first {} rows only) tab".format(table, head)
        pass
