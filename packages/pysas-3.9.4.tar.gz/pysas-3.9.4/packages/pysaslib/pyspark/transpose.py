from typing import List

from pyspark.sql.functions import *
from pyspark.sql.types import NumericType


def transpose(spark,
              df,
              groupby: List[str] = None,
              value_vars: List[str] = None,
              prefix="COL",
              names: List[str] = None):
    numeric_cols = get_numeric_cols(df)
    columns_order = spark.createDataFrame(
        list(enumerate(value_vars or df.columns)), ['col_index', '_NAME_'])

    if names:
        return transpose_by_names(df,
                                  groupby or [],
                                  value_vars or list(set(numeric_cols) - set(groupby) - set(names)),
                                  names,
                                  columns_order)

    if groupby:
        maxcols = df.groupBy(groupby).count().agg(max('count')).first()[0]
    else:
        maxcols = df.count()

    return transpose_by_not_names(df,
                                  groupby or [],
                                  value_vars or list(set(numeric_cols) - set(groupby or {})),
                                  maxcols,
                                  columns_order,
                                  prefix)


def get_numeric_cols(df):
    return [f.name for f in df.schema.fields if isinstance(f.dataType, NumericType)]


def transpose_by_not_names(df, groupby, cols_to_aggregate, maxcols, columns_order, prefix):
    rows_priority = (groupby or []) + ['col_index']
    return df.fillna(float('nan')).groupBy(groupby).agg(
        array(
            [struct(lit(c).alias('_NAME_'), collect_list(c).alias('values'))
             for c in cols_to_aggregate]
        ).alias('lists')
    ).withColumn('lists_exp', explode('lists')) \
        .join(broadcast(columns_order), col('_NAME_') == col('lists_exp._NAME_')) \
        .select(
        *groupby,
        'lists_exp._NAME_',
        *[when(col('lists_exp.values')[i] == float('nan'), lit(None)).otherwise(col('lists_exp.values')[i]).alias(
            prefix + str(i + 1)) for i in range(maxcols)]
    ).orderBy(rows_priority).drop('col_index')


def transpose_by_names(df, groupby, cols_to_aggregate, names, columns_order):
    rows_priority = (groupby or []) + ['col_index']
    expression = col(cols_to_aggregate[0])
    for c in cols_to_aggregate[1:]:
        expression = when(col('_NAME_') == c, col(c)).otherwise(expression)

    df_with_nn = df.replace('NaN', None).replace(float('nan'), None) \
        .withColumn('nn', concat(*[regexp_replace(c, '.0$', '') for c in names])) \
        .where(col('nn').isNotNull())

    final_df_columns_order = df_with_nn \
        .withColumn('lineno', monotonically_increasing_id()) \
        .groupBy('nn').agg(min('lineno')) \
        .orderBy('min(lineno)').select('nn').rdd.map(lambda r: r[0]).collect()

    return df_with_nn \
        .withColumn('names', array([lit(c) for c in cols_to_aggregate])) \
        .withColumn('_NAME_', explode('names')) \
        .withColumn('value', expression) \
        .groupBy(groupby + ['_NAME_']).pivot('nn').agg(sum('value')) \
        .join(broadcast(columns_order), '_NAME_') \
        .orderBy(rows_priority).drop('col_index') \
        .select(
        *groupby,
        '_NAME_',
        *final_df_columns_order
    )
