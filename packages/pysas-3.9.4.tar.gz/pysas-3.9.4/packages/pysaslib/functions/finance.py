#  Copyright 2008-2020 Dulles Research LLC. All Rights Reserved.

#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#


import functools
import math

import scipy

from pysaslib.functions.dateandtime import datdif, yrdif


class FinCalculation():
    def compute(self, *args):
        raise NotImplementedError('Function finance("{}", ...) currently not implemented.'
                                  .format(self.__class__.__name__))


class ACCRINT(FinCalculation):
    pass


class ACCRINTM(FinCalculation):
    pass


class AMORDEGRC(FinCalculation):
    pass


class AMORLINC(FinCalculation):
    pass


class COUPDAYBS(FinCalculation):
    pass


class COUPDAYS(FinCalculation):
    pass


class COUPDAYSNC(FinCalculation):
    pass


class COUPNCD(FinCalculation):
    pass


class COUPNUM(FinCalculation):
    pass


class COUPPCD(FinCalculation):
    pass


class CUMIPMT(FinCalculation):
    """
    Calculator of cumulative interest paid between two periods
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 6:
            return self.f(args[0], args[1], args[2], args[3], args[4], args[5])
        elif arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4], False)
        else:
            raise ValueError('Function CUMIPMT expects 5 <= len(args) <= 6')

    @staticmethod
    def f(rate, nper, pv, sp, ep, type):
        """
         Calculation based on this explanation:
         https://wiki.openoffice.org/wiki/Documentation/How_Tos/Calc:_CUMIPMT_function"
         :param rate: interest rate as a fraction for single period.
         :param nper: number of payment periods.
         :param pv:   present value.
         :param sp:   first period in the calculation.
         :param ep:   last period in the calculation.
         :param type: False if due at the end of the period, True otherwise.
         return: cumulative interest.
        """
        v = 0
        p = sp
        while p <= ep:
            v += IPMT.f(rate, p, nper, pv, 0, type)
            p += 1
        return v


class CUMPRINC(FinCalculation):
    """
    Calculator of cumulative principal that is paid on a loan between two periods.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 6:
            return self.f(args[0], args[1], args[2], args[3], args[4], args[5])
        elif arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4], False)
        else:
            raise ValueError('Function CUMPRINC expects 5 <= len(args) <= 6')

    @staticmethod
    def f(rate, nper, pv, sp, ep, type):
        """
        Calculation based on this explanation:
            https://wiki.openoffice.org/wiki/Documentation/How_Tos/Calc:_CUMPRINC_function
        :param rate: interest rate as a fraction for single period.
        :param nper: number of payment periods.
        :param pv:   present value.
        :param sp:   first period in the calculation.
        :param ep:   last period in the calculation.
        :param type: False if due at the end of the period, True otherwise.
        return: cumulative principal.
        """
        v = 0.
        p = sp
        while p <= ep:
            v += PPMT.f(rate, p, nper, pv, 0, type)
            p += 1.
        return v


class DB(FinCalculation):
    pass


class DDB(FinCalculation):
    pass


class DISC(FinCalculation):
    pass


class DOLLARDE(FinCalculation):
    """
    Calculator of dollar price, expressed as a fraction, to a dollar price, expressed as a decimal number.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 2:
            return self.f(args[0], int(args[1]))
        else:
            raise ValueError('Function DOLLARDE expects len(args) = 2')

    @staticmethod
    def f(fd, denominator):
        """
        Calculation influenced by this explanation:
            https://support.office.com/en-US/article/DOLLARDE-function-db85aab0-1677-428a-9dfd-a38476693427"
        :param fd: number expressed as a fraction.
        :param denominator: denominator of a fraction.
        return: dollar value as a decimal.
        """
        dv = int(fd)
        f = fd - dv
        return dv + f * 100. / denominator


class DOLLARFR(FinCalculation):
    """
    Calculator of dollar price, expressed as a decimal number, to a dollar price, expressed as a fraction.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 2:
            return self.f(args[0], int(args[1]))
        else:
            raise ValueError('Function DOLLARFR expects len(args) = 2')

    @staticmethod
    def f(fd, denominator):
        """
        Calculation influenced by this explanation:
        https://support.office.com/en-US/article/DOLLARDE-function-db85aab0-1677-428a-9dfd-a38476693427
        :param fd: decimal number.
        :param denominator: denominator of a fraction.
        return:  dollar value as a fraction.
        """
        dv = int(fd)
        f = fd - dv
        return dv + f * denominator / 100.


class DURATION(FinCalculation):
    pass


class EFFECT(FinCalculation):
    pass


class FV(FinCalculation):
    """
    Calculator of future value of an investment
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4])
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], False)
        elif arg_len == 3:
            return self.f(args[0], args[1], args[2], 0., False)
        else:
            raise ValueError('Function FV expects 3 <= len(args) <= 5.')

    @staticmethod
    def f(rate, nper, payment, pv, type):
        """
        Calculation based on this formula and explanation:
            http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate:    interest rate as a fraction for single period.
        :param nper:    number of payment periods.
        :param payment: payment that is made each period.
        :param pv:      present value.
        :param type:    {@code false} if due at the end of the period, {@code true} otherwise.
        return: the yield of a security with an odd last period.
        """
        nr = math.pow(1. + rate, nper)
        payment = payment * (1. + rate) if type else payment
        return -(payment * (nr - 1.) / rate + pv * nr)


class FVSCHEDULE(FinCalculation):
    """
    Calculator of future value of the initial principal after applying a series of compound interest rates.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len > 1:
            return self.f(args[0], args[1:arg_len])
        else:
            raise ValueError('Function FVSCHEDULE expects len(args) > 1.')

    @staticmethod
    def f(principal, schedule):
        """
        Calculation based on this formula and explanation:
            https://wiki.openoffice.org/wiki/Documentation/How_Tos/Calc:_FVSCHEDULE_function
        :param principal: present value.
        :param schedule:  (list) sequence of interest rates to apply.
        return: future value.
        """
        v = [principal] + [1 + rate for rate in schedule]
        return functools.reduce(lambda x, y: x * y, v, 1)


class INTRATE(FinCalculation):
    pass


class IPMT(FinCalculation):
    """
    Calculator of interest payment for an investment for a given period.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 6:
            return self.f(args[0], args[1], args[2], args[3], args[4], args[5])
        elif arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4], False)
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], 0., False)
        else:
            raise ValueError('Function IPMT expects 4 <= len(args) <= 6.')

    @staticmethod
    def f(rate, period, nper, pv, fv, type):
        """
        Calculation based on this formula and explanation:
        http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate:   interest rate as a fraction for single period.
        :param period: period for which you want to calculate the depreciation.
        :param nper:   number of payment periods.
        :param pv:     present value.
        :param fv:     future value.
        :param type:   False if due at the end of the period, True otherwise.
        return: the yield of a security with an odd last period.
        """
        pv = 0 if pv is None else pv
        fv = 0 if fv is None else fv
        pmt = PMT.f(rate, nper, pv, fv, type)
        v = FV.f(rate, period - 1, pmt, pv, type) * rate
        return v / (1 + rate) if type else v


class IRR(FinCalculation):
    def compute(self, *args):
        arg_len = len(args)
        if arg_len > 0:
            return self.f(args)
        else:
            raise ValueError('Function IRR expects len(args) > 0.')

    @staticmethod
    def f(*values):
        """
        Calculation based on this formula and explanation:
            https://support.office.com/en-US/article/IRR-function-64925eaa-9988-495b-b290-3ad0c163c1bc
        :param values: sequence of the cash flows.
        return: rate of return.
        """
        NR_INI = 0.1
        NR_EPS = 1e-9  # 1e-7 in Excel
        NR_ITS = 50  # 20 in Excel
        BS_LEFT = -1000.
        BS_RIGHT = +1000.
        BS_SHRINK = 8

        def func(rate):
            return NPV.f(rate, *values)

        try:
            # TODO SolverBS doesn't converge to  SolverNR(values).solve(NR_INI, NR_ITS, NR_EPS);
            x0 = scipy.optimize.bisect(f=func, a=BS_LEFT, b=BS_RIGHT, xtol=NR_EPS, maxiter=NR_ITS, disp=True)
            return x0
        except Exception as e:
            raise ArithmeticError("Failure to solve equation while computing FINANCE('IRR',...): " + str(e))


class ISPMT(FinCalculation):
    """
    Calculator of interest paid during a specific period of an investment.
    ISPMT considers a fixed rate loan, where you repay the same amount
    of capital at the start of each period, and pay interest on the outstanding
    balance at the end of each period. The interest you pay will depend of the
    remaining outstanding balance each period, and will decline with time.
    ISPMT returns that interest.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3])
        else:
            raise ValueError('Function ISPMT expects len(args) > 0.')

    @staticmethod
    def f(rate, period, nper, pv):
        """
        Calculation based on this explanation and examples:
            https://wiki.openoffice.org/wiki/Documentation/How_Tos/Calc:_ISPMT_function
        :param rate:   interest rate as a fraction for single period.
        :param period: period to calculate the interest rate.
        :param nper:   number of payment periods.
        :param pv:     present value.
        return: interest paid during a specific period of an investment.
        """
        return -(pv - pv / nper * period) * rate


class MDURATION(FinCalculation):
    pass


class MIRR(FinCalculation):
    pass


class NOMINAL(FinCalculation):
    pass


class NPER(FinCalculation):
    """
    Calculator of number of periods for an investment.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], bool(args[4]))
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], False)
        elif arg_len == 3:
            return self.f(args[0], args[1], args[2], 0., False)
        else:
            raise ValueError('Function NPER expects 3 <= len(args) <= 5.')

    @staticmethod
    def f(rate, payment, pv, fv, type):
        """
        Calculation influenced by this formula and explanation:
            http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate    interest rate as a fraction for single period.
        :param payment payment that is made each period.
        :param pv      present value.
        :param fv      future value.
        :param type    False if due at the end of the period, True otherwise.
        return: the yield of a security with an odd last period.
        """
        payment = payment * (1. + rate) if type else payment
        nr = (payment - fv * rate) / (payment + pv * rate)
        return math.log(nr) / math.log(1. + rate)


class NPV(FinCalculation):
    """
    Calculator of net present value of an investment based on
    a series of periodic cash flows and a discount rate.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len > 0:
            return self.f(args[0], args[1:arg_len])
        else:
            raise ValueError('Function NPV expects 3 <= len(args) <= 5.')

    @staticmethod
    def f(rate, values):
        """
        Calculation based on this formula and explanation:
            https://support.office.com/en-US/article/NPV-function-8672CB67-2576-4D07-B67B-AC28ACF2A568"
        :param rate:   interest rate as a fraction.
        :param values: (list) sequence of the cash flows.
        return: net present value.
        """
        rate, r, v = rate + 1, 1., 0.
        for value in values:
            r *= rate
            v += value / r
        return v


class ODDFPRICE(FinCalculation):
    pass


class ODDFYIELD(FinCalculation):
    pass


class ODDLPRICE(FinCalculation):
    pass


class ODDLYIELD(FinCalculation):
    pass


class PMT(FinCalculation):
    """
    Calculator of periodic payment for an annuity
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4])
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], False)
        elif arg_len == 3:
            return self.f(args[0], args[1], args[2], 0., False)
        else:
            raise ValueError('Functio PMT expects 3 <= len(args) <= 5')

    @staticmethod
    def f(rate, nper, pv, fv, type):
        """
        Calculation based on this formula and explanation:
        http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate: interest rate as a fraction for single period.
        :param nper: number of payment periods.
        :param pv:   present value.
        :param fv:   future value.
        :param type: False if due at the end of the period, True otherwise.
        return: the yield of a security with an odd last period.
        """
        pv = 0. if pv is None else pv
        nr = math.pow(1. + rate, nper)
        v = -(pv * nr + fv) * rate / (nr - 1.)
        return v / (1. + rate) if type else v


class PPMT(FinCalculation):
    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 6:
            return self.f(args[0], args[1], args[2], args[3], args[4], args[5])
        elif arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4], False)
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], 0., False)
        else:
            raise ValueError('Function PPMT expects 4 <= len(args) <= 6.')

    @staticmethod
    def f(rate, period, nper, pv, fv, type):
        """
        Calculation based on this formula and explanation:
            http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate:   interest rate as a fraction for single period.
        :param period: period for which you want to calculate the depreciation.
        :param nper:   number of payment periods.
        :param pv:     present value.
        :param fv:     future value.
        :param type:   False if due at the end of the period, True otherwise.
        return: the yield of a security with an odd last period.
        """
        return PMT.f(rate, nper, pv, fv, type) - IPMT.f(rate, period, nper, pv, fv, type)


class PRICE(FinCalculation):
    pass


class PRICEDISC(FinCalculation):
    pass


class PRICEMAT(FinCalculation):
    pass


class PV(FinCalculation):
    """
    Calculator of present value of an investment.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4])
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], False)
        elif arg_len == 3:
            return self.f(args[0], args[1], args[2], 0., False)
        else:
            raise ValueError('Function PV expects 3 <= len(args) <= 5.')

    @staticmethod
    def f(rate, nper, payment, fv, type):
        """
        Calculation influenced by this formula and explanation:
            http://www.experts-exchange.com/articles/1948/A-Guide-to-the-PMT-FV-IPMT-and-PPMT-Functions.html
        :param rate:    interest rate as a fraction for single period.
        :param nper:    number of payment periods.
        :param payment: payment that is made each period.
        :param fv:      future value.
        :param type:    {@code false} if due at the end of the period, {@code true} otherwise.
        return: the yield of a security with an odd last period.
        """
        nr = math.pow(1. + rate, nper)
        payment = payment * (1. + rate) if type else payment
        return -(payment * (nr - 1.) / rate + fv) / nr


class RATE(FinCalculation):
    """
    Calculator of the interest rate per period of an annuity.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], bool(args[4]))
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], False)
        elif arg_len == 3:
            return self.f(args[0], args[1], args[2], 0., False)
        else:
            raise ValueError('Function RATE expects 3 <= len(args) <= 5.')

    @staticmethod
    def f(nper, payment, pv, fv, type):
        """
        Calculation influenced by this FunMath#mort(double, double, double, double) formula.
        :param nper    number of payment periods.
        :param payment payment that is made each period.
        :param pv      present value.
        :param fv      future value.
        :param type    False if due at the end of the period, True otherwise.
        returns the yield of a security with an odd last period.
        see Newton-Rafson solver
        """
        NR_INI = 0.1
        NR_EPS = 1e-10
        NR_ITS = 50

        def func_deriv(rate):
            u = 1. + rate
            f1 = -(pv * math.pow(u, nper) + fv)
            df1 = -pv * nper * math.pow(u, nper - 1.)
            f2 = (u - 1.) / (math.pow(u, nper) - 1.)
            df2 = 1. / (math.pow(u, nper) - 1.) - (u - 1.) * (nper * math.pow(u, nper - 1.)) \
                  / math.pow(math.pow(u, nper) - 1., 2.)
            f3 = 1. / u
            df3 = -1. / (u * u)
            if type:
                drv1 = f1 * f2 * df3 + f1 * df2 * f3 + df1 * f2 * f3
            else:
                drv1 = f1 * df2 + df1 * f2
            fun = PMT.f(rate, nper, pv, fv, type) - payment
            return fun, drv1

        try:
            sl = scipy.optimize.root_scalar(func_deriv, fprime=True, x0=NR_INI, method='newton', maxiter=NR_ITS,
                                            xtol=NR_EPS)
            return sl.root
        except Exception as e:
            raise ArithmeticError("Failure to solve equation while computing FINANCE('RATE',...): " + str(e))


class RECEIVED(FinCalculation):
    """
    Calculator of amount received at maturity for a fully invested security.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 5:
            return self.f(args[0], args[1], args[2], args[3], args[4])
        elif arg_len == 4:
            return self.f(args[0], args[1], args[2], args[3], 0)
        else:
            raise ValueError('Function RECEIVED expects 4 <= len(args) <= 5.')

    @staticmethod
    def f(settlement, maturity, investment, discount, basis):
        """
        Calculation influenced by this formula and explanation:
            https://support.office.com/en-US/article/RECEIVED-function-7a3f8b93-6611-4f81-8576-828312c9b5e5
        :param settlement: settlement date.
        :param maturity:   maturity date.
        :param investment: invested amount.
        :param discount:   discount rate.
        :param basis:     day count value.
        return: amount received
        """
        BASIS = ["30u/360",  # US(NASD)
                 "act/act", "act/360", "act/365",
                 "30e/360"  # European
                 ]
        try:
            yd = yrdif(settlement, maturity, BASIS[basis])
        except Exception as e:
            raise RuntimeError("Failed to compute year difference: " + str(e))
        return investment / (1. - discount * yd)


class SLN(FinCalculation):
    pass


class SYD(FinCalculation):
    pass


class TBILLEQ(FinCalculation):
    """
    Calculator of bond-equivalent yield for a treasury bill.
    """

    def compute(self, *args):
        arg_len = len(args)
        if arg_len == 3:
            return self.f(args[0], args[1], args[2])
        else:
            raise ValueError('Function TBILLEQ expects len(args) = 3.')

    @staticmethod
    def f(settlement, maturity, discount):
        """
        Calculation influenced by this formula and explanation:
            https://support.office.com/en-US/article/TBILLEQ-function-2ab72d90-9b4d-4efe-9fc2-0f81f2c19c8c
        TODO There are multiple discrepancies with Excel calculations and Internet sources.
        TODO While act/360 is the only basis that perfectly fits SAS example, reverse computations show it could be a source of problems.

        :param settlement: settlement date.
        :param maturity:   maturity date.
        :param discount:   discount rate.
        return: bond-equivalent yield.
        """
        dif = datdif(settlement, maturity, "act/360")
        return 365 / (360 / discount - dif)


class TBILLPRICE(FinCalculation):
    pass


class TBILLYIELD(FinCalculation):
    pass


class VDB(FinCalculation):
    pass


class XIRR(FinCalculation):
    pass


class XNPV(FinCalculation):
    pass


class YIELD(FinCalculation):
    pass


class YIELDDISC(FinCalculation):
    pass


class YIELDMAT(FinCalculation):
    pass


calculations = {
    'ACCRINT': ACCRINT(),
    'ACCRINTM': ACCRINTM(),
    'AMORDEGRC': AMORDEGRC(),
    'AMORLINC': AMORLINC(),
    'COUPDAYBS': COUPDAYBS(),
    'COUPDAYS': COUPDAYS(),
    'COUPDAYSNC': COUPDAYSNC(),
    'COUPNCD': COUPNCD(),
    'COUPNUM': COUPNUM(),
    'COUPPCD': COUPPCD(),
    'CUMIPMT': CUMIPMT(),
    'CUMPRINC': CUMPRINC(),
    'DB': DB(),
    'DDB': DDB(),
    'DISC': DISC(),
    'DOLLARDE': DOLLARDE(),
    'DOLLARFR': DOLLARFR(),
    'DURATION': DURATION(),
    'EFFECT': EFFECT(),
    'FV': FV(),
    'FVSCHEDULE': FVSCHEDULE(),
    'INTRATE': INTRATE(),
    'IPMT': IPMT(),
    'IRR': IRR(),
    'ISPMT': ISPMT(),
    'MDURATION': MDURATION(),
    'MIRR': MIRR(),
    'NOMINAL': NOMINAL(),
    'NPER': NPER(),
    'NPV': NPV(),
    'ODDFPRICE': ODDFPRICE(),
    'ODDFYIELD': ODDFYIELD(),
    'ODDLPRICE': ODDLPRICE(),
    'ODDLYIELD': ODDLYIELD(),
    'PMT': PMT(),
    'PPMT': PPMT(),
    'PRICE': PRICE(),
    'PRICEDISC': PRICEDISC(),
    'PRICEMAT': PRICEMAT(),
    'PV': PV(),
    'RATE': RATE(),
    'RECEIVED': RECEIVED(),
    'SLN': SLN(),
    'SYD': SYD(),
    'TBILLEQ': TBILLEQ(),
    'TBILLPRICE': TBILLPRICE(),
    'TBILLYIELD': TBILLYIELD(),
    'VDB': VDB(),
    'XIRR': XIRR(),
    'XNPV': XNPV(),
    'YIELD': YIELD(),
    'YIELDDISC': YIELDDISC(),
    'YIELDMAT': YIELDMAT()
}


def finance(calculation: str, *args: tuple) -> float:
    """
    :param calculation: the name of financial calculation
    :param args: a tuple with calculation parameters
    return: result of the calculation
    """
    calculation = calculation.strip().upper()
    func = calculations[calculation]
    return func.compute(*args)
