#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

# Category: Character
import re
import typing
import unicodedata
from collections import Counter

import jellyfish


class StrConst:
    LIMIT = 256
    CHARS = [None] * LIMIT
    CHARS_CATEG = [None] * LIMIT
    ALNUM = [None] * LIMIT
    ALPHA = [None] * LIMIT
    DIGIT = [None] * LIMIT
    FIRST = [None] * LIMIT
    GRAPH = [None] * LIMIT
    CONTROL = [None] * LIMIT
    LOWER = [None] * LIMIT
    NAME = [None] * LIMIT
    PRINT = [None] * LIMIT
    PUNCT = [None] * LIMIT
    SPACE = [None] * LIMIT
    XDIGIT = [None] * LIMIT
    UPPER = [None] * LIMIT
    WORD_DELIMITERS = [ch for ch in " !$%&()*+,-./;<^|"]
    PUNCTUATION = "! \" # $ % & ' ( ) * + , - . / : ; < = > ? @ [ \\ ] ^ _ ` { | } ~".split(" ")
    HEX = "abcdefABCDEF"
    ENGLISH = "abcdefghigklmnopqrstuvwxyz_ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    DELIMITERS_SPACES = [ch for ch in " \t\f\n\r"]
    DELIMITERS = [ch for ch in " \t\f\n\r!$%&()*+,-./;<^|"]
    BLANKS = " "
    ZERO_LENGTH_STRING = ""
    NLITERAL = r"'(.*)'[Nn]"
    NLITERAL2 = "^('([^']|'')*'(n|N)|\"([^\"]|\"\")*\"(n|N))$"  # regexp pattern
    TRIM = 255
    SEP = '\u0100'
    MAX_NAME_LENGTH = 32
    SOUNDEX_DICT = {
        "BFPV": "1",
        "CGJKQSXZ": "2",
        "DT": "3",
        "L": "4",
        "MN": "5",
        "R": "6",
        "AEIOUHWY": "#"
    }

    def set_values(self):
        for i in range(self.LIMIT):
            ch = chr(i)
            self.CHARS[i] = ch
            self.CHARS_CATEG[i] = unicodedata.category(ch)
            self.ALNUM[i] = ch.isalnum()
            self.ALPHA[i] = ch.isalpha()
            self.DIGIT[i] = ch.isdigit()
            self.FIRST[i] = ch.isalpha() or ch in ["_", "$"]
            self.GRAPH[i] = (ch != " ")
            self.CONTROL[i] = self.is_iso_control(ch)
            self.LOWER[i] = ch.islower() and not self.is_iso_control(ch)
            self.NAME[i] = self.is_java_identifier(ch)
            self.PRINT[i] = (ch >= ' ')  # ??
            self.SPACE[i] = ch.isspace()
            self.XDIGIT[i] = ch.isdigit() or (ch in [c for c in self.HEX])
            self.UPPER[i] = ch.isupper()
            self.PUNCT[i] = ch in self.PUNCTUATION

    @staticmethod
    def is_iso_control(char):
        return unicodedata.category(char)[0] == 'C'

    @staticmethod
    def is_java_identifier(char):
        return char.isalpha() or char.isdigit() or char in ["_"]


str_const = StrConst()
str_const.set_values()


def any(arg: str, start: int, mask: typing.List[bool]) -> int:
    arg_len = len(arg)
    if start == 0 or arg is None or start > arg_len:
        return 0
    elif start < -arg_len:
        start = -arg_len
    pos = abs(start) - 1
    end = arg_len if start > 0 else -1
    while pos != end:
        c = arg[pos]
        c_ix = ord(c)  # str_const.CHARS.index(c)
        if mask[c_ix]:
            return pos + 1
        if start > 0:
            pos += 1
        else:
            pos -= 1
    return 0


def not_(arg: str, start: int, mask: typing.List[bool]) -> int:
    """
    Function NOT (not is a keyword in Python, so added underscore)

    """
    agr_len = len(arg)
    if start == 0 or arg is None or start > agr_len:
        return 0
    elif start < -agr_len:
        start = -agr_len
    pos = abs(start) - 1
    end = agr_len if start > 0 else -1
    while pos != end:
        c = arg[pos]
        c_ix = ord(c)  # str_const.CHARS.index(c)
        if not mask[c_ix]:
            return pos + 1
        if start > 0:
            pos += 1
        else:
            pos -= 1
    return 0


def iswhitespace(c: str) -> bool:
    if c in [' ', '\t', '\f', '\n', '\r']:
        return True
    else:
        return False


def _trim_(d: str, cr: bool = None) -> str:
    len_d = len(d)
    st = 0
    if cr is None:  # remove only spaces
        if d is None or d == '':
            return ''
        while st < len_d and d[st] == ' ':
            st += 1
        while st < len_d and d[len_d - 1] == ' ':
            len_d -= 1
    else:
        while st < len_d and iswhitespace(d[st]):
            st += 1
        while st < len_d and iswhitespace(d[len_d - 1]):
            len_d -= 1
    return d[st:len_d] if st > 0 or len_d < len(d) else d


def cats(*ss: typing.Tuple[str, ...]) -> str:
    out_str = ''
    for s in ss:
        if s is not None:
            out_str += _trim_(s)
    return out_str


def catt(*args: typing.Tuple[str, ...]) -> str:
    out_str = ''
    for s in args:
        if s is not None:
            out_str += s.rstrip()
    return out_str


def trimn(arg: str) -> str:
    """
     Remove the trailing spaces from the string
     param arg: the input string
     return: the string without trailing spaces
    """
    if arg is None or arg == '':
        return arg
    else:
        arg_len = len(arg)
        while 0 < arg_len and arg[arg_len - 1] == ' ':
            arg_len -= 1
        return arg[0:arg_len] if arg_len < len(arg) else arg


def catx(separator: str, *args: typing.Tuple[str, ...]) -> str:
    arg_list = [a.strip() for a in args if a.strip() not in ['', None]]
    return separator.join(arg_list)


def _missing_(arg: str) -> bool:
    """
    param arg: a string
    returns: True if arg in ['', None], False otherwise
    """
    if arg is None or arg == '':
        return True
    else:
        return False


def _compare_(arg1: str, arg2: str) -> int:
    if not _missing_(arg1) and not _missing_(arg2):
        left, right = len(arg1), len(arg2)
        while left > 0 and arg1[left - 1] == ' ':
            left -= 1
        while right > 0 and arg2[right - 1] == ' ':
            right -= 1
        i = 0
        while True:
            if i == left and i != right:
                return -i - 1
            if i == right and i != left:
                return i + 1
            if i == right and i == left:
                return 0
            c = ord(arg1[i]) - ord(arg2[i])
            if c < 0:
                return -i - 1
            elif c > 0:
                return i + 1
            i += 1
    elif arg1 is None and arg2 is None:
        return 0
    elif arg1 is None:
        return 1
    else:
        return -1


def compare(arg1: str, arg2: str, modifiers: str = None) -> int:
    if arg1 is None or arg2 is None or modifiers is None:
        return _compare_(arg1, arg2)
    modifiers = set(modifiers.strip().replace(' ', '').upper())
    for m in modifiers:
        if m == 'L':
            arg1 = arg1.strip()
            arg2 = arg2.strip()
        elif m == 'N':
            res1 = re.findall(str_const.NLITERAL, arg1)
            res2 = re.findall(str_const.NLITERAL, arg2)
            arg1 = (res1[0] if len(res1) > 0 else arg1).upper()
            arg2 = (res2[0] if len(res2) > 0 else arg2).upper()
        elif m == 'I':
            arg1 = arg1.upper()
            arg2 = arg2.upper()
        elif m == ':':
            if len(arg1) > len(arg2):
                arg1 = arg1[0:len(arg2)]
            elif len(arg1) < len(arg2):
                arg2 = arg2[0:len(arg1)]
        else:
            raise ValueError("Unknown modifier in function compare: {}".format(m))
    return _compare_(arg1, arg2)


def compbl(s: str) -> str:
    if _missing_(s):
        return s
    else:
        return re.sub(r'\s+', ' ', s)


def compress_cache(chars: str = None, modifiers: str = None) -> typing.Tuple[str, typing.Callable]:
    chars = '' if chars is None or chars == ' ' else chars
    modifiers = '' if modifiers is None else ''.join(set(modifiers.replace(' ', ''))).upper()
    if chars == '' and modifiers == '':
        return ' ', lambda pattern, source: source.replace(' ', '')
    else:
        _lambda = lambda pattern, source: re.sub(pattern, '', source)
        if 'A' in modifiers:
            # adds alphabetic characters to the list of characters
            chars += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
        if 'C' in modifiers:
            # adds control characters to the list of characters
            chars += ''.join(str_const.CHARS[0:32])
        if 'D' in modifiers:
            # adds digits to the list of characters
            chars += '1234567890'
        if 'F' in modifiers:
            # adds the underscore character and English letters to the list of characters
            chars += '_'
        if 'G' in modifiers:
            # adds graphic characters to the list of characters
            # TODO what is this ???
            raise NotImplementedError('Modifier G not implemented yet!')
        if 'H' in modifiers:
            # adds a horizontal tab to the list of characters
            chars += '\t'
        if 'I' in modifiers:
            # ignores case
            _lambda = lambda pattern, source: re.sub(pattern, '', source, flags=re.IGNORECASE)
        if 'K' in modifiers:
            # keeps the characters in the list instead of removing them
            # return ''.join([c for c in source if c in chars])
            _patt = '[' + re.escape(''.join(set(chars))) + ']+'
            _lambda = lambda pattern, source: "".join(re.findall(_patt, source))
            return _patt, _lambda
            # TODO: use the original list?
        if 'L' in modifiers:
            # adds lowercase letters to the list of characters
            chars += str_const.ENGLISH.split('_')[0]
        if 'O' in modifiers:
            # processes the second and third arguments once rather than every time the COMPRESS function is called
            # IGNORED
            pass
        if 'P' in modifiers:
            # adds punctuation marks to the list of characters
            chars += ";:',.()-"
        if 'S' in modifiers:
            # adds space characters (blank, horizontal tab, vertical tab, carriage return, line feed, form feed,
            # and NBSP ('A0'x, or 160 decimal ASCII) to the list of characters
            chars += " \t\v\n\r\f\xa0"
        if 'T' in modifiers:
            # trims trailing blanks from the first and second arguments
            chars = chars.rstrip()
            _lambda = lambda pattern, source: re.sub(pattern, '', source.rstrip())
        if 'U' in modifiers:
            # adds uppercase letters to the list of characters
            chars += str_const.ENGLISH.split('_')[1]  # A-Z
        if 'W' in modifiers:
            # adds printable characters to the list of characters
            chars += ''.join(str_const.CHARS[32:127])
        if 'X' in modifiers:
            # adds hexadecimal characters to the list of characters
            chars += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'
        _pattern = '[' + re.escape(''.join(set(chars))) + ']+'
        return _pattern, _lambda


def compress_lambda(source: str, pattern: str, func: typing.Callable) -> str:
    if _missing_(source):
        return source
    else:
        return func(pattern, source)


def compress(source: str, chars: str = None, modifiers: str = None,
             pattern: str = None, func: typing.Callable = None) -> str:
    if pattern is None or func is None:
        pattern, func = compress_cache(chars, modifiers)
    return compress_lambda(source, pattern, func)


def count(string: str, characters: str = None, modifiers: str = None) -> int:
    modifiers = '' if modifiers is None else modifiers.strip().upper().replace(' ', '')
    if _missing_(string) or characters is None or len(characters) == 0 or characters == ' ':
        return 0
    if len(modifiers) > 0:
        for c in modifiers:
            if c == 'I':
                string = string.upper()
                characters = characters.upper()
            if c == 'T':
                string = string.rstrip()
                characters = characters.rstrip()
            if c not in ['I', 'T']:
                raise ValueError("Unknown modifier in function find: " + modifiers)
    return len(re.findall(re.escape(characters), string))


def countc(string: str, characters: str = None, modifiers: str = None) -> int:
    modifiers = '' if modifiers is None else modifiers.strip().upper().replace(' ', '')
    if characters is None or len(characters) == 0:
        return 0
    if len(modifiers) > 0:
        if 'A' in modifiers:
            # adds alphabetic characters to the list of characters
            characters += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
        if 'B' in modifiers:
            # scans string from right to left, instead of from left to right.
            string = string[::-1]
        if 'C' in modifiers:
            # adds control characters to the list of characters
            characters += ''.join(str_const.CHARS[0:32])
        if 'D' in modifiers:
            # adds digits to the list of characters
            characters += '1234567890'
        if 'F' in modifiers:
            # adds the underscore character and English letters to the list of characters
            characters += str_const.ENGLISH  # '_' add the underscore only?
        if 'G' in modifiers:
            # adds graphic characters to the list of characters
            # TODO what is this ???
            raise NotImplementedError('Modifier G not implemented yet!')
        if 'H' in modifiers:
            # adds a horizontal tab to the list of characters.
            characters += '\t'
        if 'I' in modifiers:
            # ignores case
            string = string.upper()
            characters = characters.upper()
        if 'L' in modifiers:
            # adds lowercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[0]
        if 'N' in modifiers:
            # adds digits, an underscore, and English letters
            characters += str_const.ENGLISH + '1234567890'
        if 'O' in modifiers:
            # processes the character-list and modifier arguments only once, at the first call to this instance of COUNTC
            # IGNORED
            pass
        if 'P' in modifiers:
            # adds punctuation marks to the list of characters
            characters += ";:',.()-"
        if 'S' in modifiers:
            # adds space characters to the list of characters (blank, horizontal tab, vertical tab, carriage return,
            # line feed, and form feed)
            characters += " \t\v\n\r\f"
        if 'T' in modifiers:
            # trims trailing blanks from the first and second arguments
            string = string.rstrip()
            characters = characters.rstrip()
        if 'U' in modifiers:
            # adds uppercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[1]  # A-Z
        if 'W' in modifiers:
            # adds printable characters to the list of characters
            characters += ''.join(str_const.CHARS[32:127])
        if 'X' in modifiers:
            # adds hexadecimal characters to the list of characters
            characters += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'
        if 'V' in modifiers:
            # counts characters that do not appear in the list of characters
            string = re.sub('[' + re.escape(''.join(set(characters))) + ']+', '', string)
            characters = string
    cnt = Counter(string)
    characters = set(characters)
    counts = [cnt.get(c, 0) for c in characters]
    return sum(counts)


def countw(string: str, characters: str = None, modifiers: str = None) -> int:
    if string is None or len(string) == 0:
        return 0
    characters = '' if characters is None else characters
    modifiers = '' if modifiers is None else modifiers.strip().upper().replace(' ', '')
    if len(modifiers) > 0:
        # Apply modification rules:
        if 'A' in modifiers:
            # adds alphabetic characters to the list of characters
            characters += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
        if 'B' in modifiers:
            # scans string from right to left, instead of from left to right.
            # ? Right-to-left counting makes a difference only when you use the Q modifier
            # and the string contains unbalanced quotation marks
            string = string[::-1]
        if 'C' in modifiers:
            # adds control characters to the list of characters
            characters += ''.join(str_const.CHARS[0:32])
        if 'D' in modifiers:
            # adds digits to the list of characters
            characters += '1234567890'
        if 'F' in modifiers:
            # adds the underscore character and English letters to the list of characters
            characters += str_const.ENGLISH  # add the underscore only? '_'
        if 'G' in modifiers:
            # adds graphic characters to the list of characters
            # TODO what is this ???
            raise NotImplementedError('Modifier G not implemented yet!')
        if 'H' in modifiers:
            # adds a horizontal tab to the list of characters.
            characters += '\t'
        if 'I' in modifiers:
            # ignores case
            string = string.upper()
            characters = characters.upper()
        if 'K' in modifiers:
            # causes all characters that are not in the list of characters to be treated as delimiters
            characters = ''.join(set(string) - set(characters))
        if 'L' in modifiers:
            # adds lowercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[0]
        if 'N' in modifiers:
            # adds digits, an underscore, and English letters
            characters += str_const.ENGLISH + '1234567890'
        if 'O' in modifiers:
            # processes the character-list and modifier arguments only once, at the first call to this instance of COUNTC
            # IGNORED
            pass
        if 'P' in modifiers:
            # adds punctuation marks to the list of characters
            characters += ";:',.()-"
        if 'Q' in modifiers:
            # ignores delimiters that are inside substrings that are enclosed in quotation marks.
            # If the value of string contains unmatched quotation marks, scanning from left to right
            # produces different words than scanning from right to left
            string = re.sub('[' + '\'\"' + ']+', '', string)
        if 'S' in modifiers:
            # adds punctuation marks to the list of characters
            characters += " \t\v\n\r\f"
        if 'T' in modifiers:
            # trims trailing blanks from the first and second arguments
            string = string.rstrip()
            characters = characters.rstrip()
        if 'U' in modifiers:
            # adds uppercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[1]  # A-Z
        if 'W' in modifiers:
            # adds printable characters to the list of characters
            characters += ''.join(str_const.CHARS[32:127])
        if 'X' in modifiers:
            # adds hexadecimal characters to the list of characters
            characters += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'

    if 'M' not in modifiers:
        """
        specifies that multiple consecutive delimiters, and delimiters at the beginning or end of the string argument,
        refer to words that have a length of 0. If the M modifier is not specified, multiple consecutive delimiters
        are treated as one delimiter, and delimiters at the beginning or end of the string argument are ignored.
        """
        if len(characters) > 0:
            characters = list(set(characters))
            # Replace all delimiters with the first one:
            char0 = characters[0]
            string = re.sub('[' + re.escape(''.join(characters)) + ']+', char0, string)
            # Replace multiple consecutive delimiters:
            string = string.replace(char0 * 2, char0)
            # Remove leading delimiters
            string = string[1:] if string[0] == char0 else string
            # Remove trailing delimiters:
            string = string[:-1] if string[-1] == char0 else string
            characters = char0

    # Calculate word count:
    delimiters = set(str_const.DELIMITERS if len(characters) == 0 else characters)
    count = 0
    len_str = len(string)
    for i in range(len_str):
        for ch in delimiters:
            if string[i] == ch and i != 0 and i != len_str - 1:
                count += 1
            if string[i] == ch and 'M' in modifiers and i in [0, len_str - 1]:
                count += 1
    count += 1
    return count


def trim(arg: str) -> str:
    if arg is None:
        return arg
    else:
        res = trimn(arg)
        return res if len(res) != 0 else ' '


def upcase(arg1: str) -> str:
    return arg1.upper()


def lowcase(arg1: str) -> str:
    return arg1.lower()


def substr(string: str, position: int, length: int = None) -> str:
    if _missing_(string):
        return string
    else:
        l = len(string)
        length = l if length is None else length
        if position > l:
            raise ValueError('The position {} exceeds length of character.'.format(position))
        if position < 1:
            raise ValueError('The position is should be greater or equal 1'.format(position))
        return string[position - 1: position - 1 + length]


def missing(arg: str) -> bool:
    for c in arg:
        if c in ['\0', '\t', '\r', ' ', chr(255)]:
            break
        else:
            return False
    return True


def index(source: str, excerpt: str) -> int:
    try:
        return source.index(excerpt) + 1
    except ValueError:
        return 0


def indexc(source: str, *excerpt: typing.Tuple[str, ...]) -> int:
    chars = set(''.join(excerpt))
    if len(chars) == 0 or excerpt is None:
        raise ValueError('No value specified for parameter excerpt.')
    ix_min = float('inf')
    for c in chars:
        ix = source.find(c)
        if ix >= 0 and ix < ix_min:
            ix_min = ix
    return 0 if ix_min == float('inf') else ix_min + 1


def indexw(source: str, excerpt: str, delimiters: str = ' ') -> int:
    if (len(source) == 0 and len(excerpt) == 0) or (source.strip() == '' and excerpt.strip() == ''):
        return 1
    elif len(excerpt.strip()) == 0:
        return 0
    else:
        excerpt = excerpt.strip()
        delims = set(delimiters)
        pattern = '[' + re.escape(''.join(set(delims))) + ']+'
        source = re.sub(pattern, '', source)
        ix = source.find(excerpt)
        return ix + 1 if ix >= 0 else 0


def find(string: str, characters: str, modifiers: str = None, startpos: int = 1) -> int:
    modifiers = '' if modifiers is None else modifiers.strip().upper()
    if 'I' in modifiers:
        string = string.upper()
        characters = characters.upper()
    if 'T' in modifiers:
        string = string.rstrip()
        characters = characters.rstrip()

    len_str = len(string)
    if startpos == 0 or startpos > len_str:
        return 0
    elif startpos > 0 and startpos <= len_str:
        # starts the search at position start-position and the direction of the search is to the right.
        ix = string.find(characters, startpos - 1)
    elif startpos < 0:
        pos_ = len_str if -startpos > len_str else -startpos
        # starts the search at position start-position and the direction of the search is to the left.
        # If start-position is greater than the length of string, the search starts at the end of string.
        ix = string[0:pos_].rfind(characters)
    return ix + 1 if ix >= 0 else 0


def findc(string: str, characters: str, modifiers: str = None, startpos: int = 1) -> int:
    characters = '' if characters is None else characters
    modifiers = '' if modifiers is None else modifiers.strip().upper()
    len_str = len(string)
    if startpos == 0 or startpos > len_str:
        return 0

    if 'A' in modifiers:
        # adds alphabetic characters to the list of characters
        characters += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
    if 'B' in modifiers:
        # searches from right to left, instead of from left to right,
        # regardless of the sign of the start-position argument.
        pass
    if 'C' in modifiers:
        # adds control characters to the list of characters
        characters += ''.join(str_const.CHARS[0:32])
    if 'D' in modifiers:
        # adds digits to the list of characters
        characters += '1234567890'
    if 'F' in modifiers:
        # adds the underscore character and English letters to the list of characters
        characters += str_const.ENGLISH  # add the underscore only? '_'
    if 'G' in modifiers:
        # adds graphic characters to the list of characters
        # TODO
        raise NotImplementedError('Modifier G not implemented yet!')
    if 'H' in modifiers:
        # adds a horizontal tab to the list of characters.
        characters += '\t'
    if 'I' in modifiers:
        # ignores case
        string = string.upper()
        characters = characters.upper()
    if 'L' in modifiers:
        # adds lowercase letters to the list of characters
        characters += str_const.ENGLISH.split('_')[0]
    if 'N' in modifiers:
        # adds digits, an underscore, and English letters
        characters += str_const.ENGLISH + '1234567890'
    if 'O' in modifiers:
        # processes the character-list and modifier arguments only once, at the first call to this instance of COUNTC
        # TODO raise NotImplementedError('Modifier O not implemented yet!')
        pass
    if 'P' in modifiers:
        # adds punctuation marks to the list of characters
        characters += ";:',.()-"
    if 'S' in modifiers:
        # adds space characters to the list of characters
        characters += " \t\v\n\r\f"
    if 'T' in modifiers:
        # trims trailing blanks from the first and second arguments
        string = string.rstrip()
        characters = characters.rstrip()
    if 'U' in modifiers:
        # adds uppercase letters to the list of characters
        characters += str_const.ENGLISH.split('_')[1]  # A-Z
    if 'W' in modifiers:
        # adds printable characters to the list of characters
        characters += ''.join(str_const.CHARS[32:127])
    if 'X' in modifiers:
        # adds hexadecimal characters to the list of characters
        characters += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'
    if 'K' in modifiers or 'V' in modifiers:
        # searches for any character that does not appear in the list of characters.
        # If you do not specify this modifier,  then FINDC searches for any character that appears in the list of characters.
        characters = ''.join(set(string) - set(characters))

    if 'B' in modifiers or startpos < 0:
        # starts the search at position start-position and the direction of the search is to the left.
        # If start-position is greater than the length of string, the search starts at the end of string.
        ix_m = float('-inf')
        for c in characters:
            pos_ = len_str if -startpos > len_str else -startpos
            ix = string[0:pos_].rfind(c)
            if ix != -1 and ix > ix_m:
                ix_m = ix
        return ix_m + 1 if ix_m >= 0 else 0
    elif startpos > 0 and startpos <= len_str:
        # starts the search at position start-position and the direction of the search is to the right.
        ix_m = float('inf')
        for c in characters:
            pos_ = startpos
            ix = string.find(c, pos_ - 1)
            if ix != -1 and ix < ix_m:
                ix_m = ix
        return ix_m + 1 if ix_m >= 0 and ix_m != float('inf') else 0


def left(string: str) -> str:
    s_count = 0
    for c in string:
        if c == ' ':
            s_count += 1
        else:
            break
    return string.lstrip() + ' ' * s_count


def right(string: str) -> str:
    s_count = 0
    for c in string[::-1]:
        if c == ' ':
            s_count += 1
        else:
            break
    return ' ' * s_count + string.rstrip()


def repeat(argument: str, n: int) -> str:
    if n >= 0:
        return argument * (n + 1)
    else:
        raise ValueError('Parameter n must be > 0 !')


def quote(arg: str, quote: str = '"') -> str:
    quote = '"' if quote not in ['"', "'"] else quote
    if quote in arg:
        arg = arg.replace(quote, quote * 2)
    return quote + arg + quote


def _isvalidstring_(string: str) -> bool:
    pattern = "^[a-zA-Z_][a-zA-Z0-9_]{0,31}$"
    return False if re.match(pattern, string) is None else True


def nliteral(string: str) -> str:
    string = trimn(string)
    if _isvalidstring_(string):
        return string
    elif re.match('.*[@|&].*', string) is not None:
        return '\'' + string + '\'N'
    elif re.match('.*[\'|\"].*', string) is not None:
        dqnumber = string.count('\"')
        sqnumber = string.count('\'')
        if dqnumber > sqnumber:
            return '\'' + string + '\'N'
        else:
            return '\"' + string + '\"N'
    else:
        return '\"' + string + '\"N'


def subpad(string: str, position: int, length: int = None) -> str:
    if position < 1:
        raise ValueError('Parameter position must be greater or equal to 1.')
    str_len = len(string)
    if position > str_len:
        raise ValueError('Parameter position exceeds the length of character.')
    if isinstance(length, int) and length < 0:
        raise ValueError('Parameter length must be greater or equal to 0.')
    if length is None:
        return string[position - 1:]
    elif str_len == 0 or length == 0:
        return ''
    else:
        return string[position - 1: position - 1 + length].ljust(length, ' ')


def trim(arg: str) -> str:
    if arg is None:
        return arg
    else:
        res = trimn(arg)
        return res if len(res) != 0 else ' '


def propcase(arg: str, delimiters: str = None) -> str:
    delimiters = " /-(.\t" if delimiters is None else delimiters
    pattern = '[' + re.escape(delimiters) + ']'
    words = re.split(pattern, arg)
    delims = re.findall(pattern, arg)
    if len(delims) == 0:
        return arg.capitalize()
    else:
        text_rec = ''.join([words[i].capitalize() + delims[i] for i in range(len(delims))]) + words[-1].capitalize()
        return text_rec


def findw(string: str, word: str, startpos: int = None, characters: str = None, modifiers: str = None) -> int:
    characters = '' if characters is None else characters
    modifiers = '' if modifiers is None else modifiers.strip().upper()

    if _missing_(string) or _missing_(word):
        return 0

    len_str = len(string)
    if startpos == 0 or startpos > len_str:
        return 0

    if 'A' in modifiers:
        # adds alphabetic characters to the list of characters
        characters += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
    if 'B' in modifiers:
        # searches from right to left, instead of from left to right,
        # regardless of the sign of the start-position argument.
        pass
    if 'C' in modifiers:
        # adds control characters to the list of characters
        characters += ''.join(str_const.CHARS[0:32])
    if 'D' in modifiers:
        # adds digits to the list of characters
        characters += '1234567890'
    if 'E' in modifiers:
        # counts the words that are scanned until the specified word is found,
        # instead of determining the character position of the specified word in the string.
        # Fragments of a word are not counted.
        # TODO
        raise NotImplementedError('Modifier E not implemented yet!')
    if 'F' in modifiers:
        # adds the underscore character and English letters to the list of characters
        characters += str_const.ENGLISH  # add the underscore only? '_'
    if 'G' in modifiers:
        # adds graphic characters to the list of characters
        # TODO
        raise NotImplementedError('Modifier G not implemented yet!')
    if 'H' in modifiers:
        # adds a horizontal tab to the list of characters.
        characters += '\t'
    if 'I' in modifiers:
        # ignores case
        string = string.upper()
        characters = characters.upper()
    if 'L' in modifiers:
        # adds lowercase letters to the list of characters
        characters += str_const.ENGLISH.split('_')[0]
    if 'M' in modifiers:
        # specifies that multiple consecutive delimiters, and delimiters at the beginning
        # or end of the string argument, refer to words that have a length of zero.
        # TODO
        raise NotImplementedError('Modifier M not implemented yet!')
    if 'N' in modifiers:
        # adds digits, an underscore, and English letters
        characters += str_const.ENGLISH + '1234567890'
    if 'O' in modifiers:
        # processes the character and modifier arguments only once, rather than every time the FINDW function is called.
        # TODO - IGNORED
        # raise NotImplementedError('Modifier O not implemented yet!')
        pass
    if 'P' in modifiers:
        # adds punctuation marks to the list of characters
        characters += ";:',.()-"
    if 'Q' in modifiers:
        # ignores delimiters that are inside substrings that are enclosed in quotation marks.
        # If the value of the string argument contains unmatched quotation marks,
        # then scanning from left to right produces different words than scanning from right to left.
        # TODO
        raise NotImplementedError('Modifier Q not implemented yet!')
    if 'R' in modifiers:
        # removes leading and trailing delimiters from the word argument.
        word = word.strip()
    if 'S' in modifiers:
        # adds space characters to the list of characters
        characters += " \t\v\n\r\f"
    if 'T' in modifiers:
        # trims trailing blanks from the first and second arguments
        string = string.rstrip()
        characters = characters.rstrip()
    if 'U' in modifiers:
        # adds uppercase letters to the list of characters
        characters += str_const.ENGLISH.split('_')[1]  # A-Z
    if 'W' in modifiers:
        # adds printable characters to the list of characters
        characters += ''.join(str_const.CHARS[32:127])
    if 'X' in modifiers:
        # adds hexadecimal characters to the list of characters
        characters += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'
    if 'K' in modifiers or 'V' in modifiers:
        # causes all characters that are not in the list of characters to be treated as delimiters.
        # If K is not specified, then all characters that are in the list of characters are treated as delimiters.
        characters = ''.join(set(string) - set(characters))

    if 'B' in modifiers or startpos < 0:
        # scans from right to left instead of from left to right, regardless of the sign of the start-position argument.
        ix_m = float('-inf')
        for c in [word]:  # characters:
            pos_ = len_str if -startpos > len_str else -startpos
            ix = string[0:pos_].rfind(c)
            if ix != -1 and ix > ix_m:
                ix_m = ix
        return ix_m + 1 if ix_m >= 0 else 0
    elif startpos > 0 and startpos <= len_str:
        # starts the search at position start-position and the direction of the search is to the right.
        ix_m = float('inf')
        for c in [word]:  # characters:
            pos_ = startpos
            ix = string.find(c, pos_ - 1)
            if ix != -1 and ix < ix_m:
                ix_m = ix
        return ix_m + 1 if ix_m >= 0 and ix_m != float('inf') else 0


def nvalid(string: str, nvalid: str = 'V7') -> int:
    string = trimn(string)
    nvalid = nvalid.strip().upper()
    str_len = len(string)
    if str_len == 0:
        return False
    if nvalid == 'V7':
        return int(_isvalidstring_(string))
    elif nvalid == 'ANY':
        return 1 if str_len <= 32 else 0
    elif nvalid == 'NLITERAL':
        if str_len <= 32 and re.match(str_const.NLITERAL2, string) is not None:
            return 1
        else:
            return 0
    else:
        raise ValueError("Incorrect value of parameter nvalid! Acceptable values: 'V7', 'ANY', 'NLITERAL'.")


def dequote(arg: str) -> str:
    if arg is None or len(arg) < 2:
        return arg
    c = arg[0]
    if c not in ['"', '\'']:
        return arg
    out_str = list(arg)
    i = 1
    while i < len(out_str):
        if out_str[i] == c:
            if i + 1 == len(out_str) or out_str[i + 1] != c:
                break
            del out_str[i]
        i += 1
    return ''.join(out_str[1:i])


def quote(arg: str, quote: str = '"') -> str:
    quote = quote if quote in ["'", '"'] else '"'
    return quote + arg.replace(quote, quote * 2) + quote


def verify(arg: str, *excerpt: typing.Tuple[str, ...]) -> int:
    if len(excerpt) == 0 or len(arg) == 0:
        return 0
    else:
        chars = ''.join(excerpt)
        not_in_chars = [c for c in arg if chars.find(c) == -1]
        if len(not_in_chars) == 0:
            return 0
        else:
            return arg.index(not_in_chars[0]) + 1


def soundex(arg: str) -> str:
    sx = jellyfish.soundex(arg)
    return sx[0] + sx[1:].replace('0', '')


def translate(source: str, *args: typing.Tuple[str, ...]) -> str:
    if _missing_(source):
        return source
    args = list(args)
    args_len = len(args)
    if args_len % 2 == 1:
        raise ValueError('To-characters "{}" have no corresponding From-characters.'.format(args[-1]))
    # Check and fix To- and From-characters:
    args_len_2 = int(args_len / 2)
    for i in range(0, args_len_2, 2):
        len_t, len_f = len(args[i]), len(args[i + 1])
        if len_t != len_f:
            max_len = max(len_t, len_f)
            args[i] = args[i].ljust(max_len, ' ')
            args[i + 1] = args[i + 1].ljust(max_len, ' ')
    to_chars = ''.join([args[i] for i in range(0, args_len, 2)])
    from_chars = ''.join([args[i + 1] for i in range(0, args_len, 2)])
    char_pairs = [(to_chars[i], from_chars[i]) for i in range(len(to_chars))]
    # Replace characters in sourse:
    out_str = source
    for p in char_pairs:
        out_str = out_str.replace(p[1], p[0])
    return out_str


def trantab(source: str, argto: str, argfrom: str) -> str:
    return translate(source, argto, argfrom)


def transtrn(source: str, target: str, replacement: str = None) -> str:
    if _missing_(source):
        return source
    if _missing_(replacement):
        replacement = " "
    return source.replace(target, replacement)


def tranwrd(source: str, target: str, replacement: str = None) -> str:
    if _missing_(source):
        return source
    if _missing_(replacement):
        replacement = " "
    return source.replace(target, replacement)


def _parse_quoted_words_(string: str,
                         quote: str = '\"',
                         delimiters: str = ' /-(.\t_',
                         unquoted: bool = False) -> typing.List[str]:
    """
    Parse a string containing words enclosed in quotes, i.e. when the 'Q' modifier specified
    param string: an input string
    param quote: a quote character, default "
    param unquoted: remove quotes from words
    param delimiters: a string containing word delimiters
    """
    quote_pattern = quote + '(.*?)' + quote
    split_pattern = re.escape('[' + delimiters + ']')
    quoted_words = list(re.finditer(quote_pattern, string))
    first_scans = [w.span() for w in quoted_words]
    # Find all ranges:
    all_ranges = list()
    qw_len = len(first_scans)
    str_len = len(string)
    for i in range(qw_len):
        if i == 0:
            if first_scans[i][0] > 0:
                ur = (0, first_scans[i][0] - 1)
                all_ranges.append(('UQ', ur))
            all_ranges.append(('Q', first_scans[i]))
            if i == qw_len - 1 and first_scans[i][1] + 1 <= str_len - 1:
                ur = (first_scans[i][1] + 1, str_len)
                all_ranges.append(('UQ', ur))
        else:
            if first_scans[i - 1][1] < first_scans[i][0] - 1:
                ur = (first_scans[i - 1][1] + 1, first_scans[i][0] - 1)
                all_ranges.append(('UQ', ur))
            all_ranges.append(('Q', first_scans[i]))
            if i == qw_len - 1 and first_scans[i][1] + 1 <= str_len - 1:
                ur = (first_scans[i][1] + 1, str_len - 1)
                all_ranges.append(('UQ', ur))
    # Get list of all words:
    all_words = []
    for r in all_ranges:
        if r[0] == 'Q':
            qw = string[r[1][0]:r[1][1]]
            all_words.append(qw.replace(quote, '') if unquoted else qw)
        elif r[0] == 'UQ':
            # parse subinterval
            words = re.split(split_pattern, string[r[1][0]:r[1][1]])
            all_words.extend(words)

    return all_words


def scan(string: str, count: int = 1, characters: str = None, modifiers: str = None) -> str:
    if string is None or len(string) == 0:
        return 0
    if count is None or count == 0:
        raise ValueError('Parameter count must be a non-zero integer!')
    characters = '' if characters is None else characters
    modifiers = '' if modifiers is None else modifiers.strip().upper().replace(' ', '')
    if len(modifiers) > 0:
        # Apply modification rules:
        if 'A' in modifiers:
            # adds alphabetic characters to the list of characters
            characters += str_const.ENGLISH.replace('_', '')  # 'a-zA-Z'
        if 'B' in modifiers:
            # scans string from right to left, instead of from left to right.
            # ? Right-to-left counting makes a difference only when you use the Q modifier
            # and the string contains unbalanced quotation marks
            # string = string[::-1]
            pass
        if 'C' in modifiers:
            # adds control characters to the list of characters
            characters += ''.join(str_const.CHARS[0:32])
        if 'D' in modifiers:
            # adds digits to the list of characters
            characters += '1234567890'
        if 'F' in modifiers:
            # adds the underscore character and English letters to the list of characters
            characters += str_const.ENGLISH  # add the underscore only? '_'
        if 'G' in modifiers:
            # adds graphic characters to the list of characters
            # TODO what is this ???
            raise NotImplementedError('Modifier G not implemented yet!')
        if 'H' in modifiers:
            # adds a horizontal tab to the list of characters.
            characters += '\t'
        if 'I' in modifiers:
            # ignores case
            string = string.upper()
            characters = characters.upper()
        if 'K' in modifiers:
            # causes all characters that are not in the list of characters to be treated as delimiters
            characters = ''.join(set(string) - set(characters))
        if 'L' in modifiers:
            # adds lowercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[0]
        if 'N' in modifiers:
            # adds digits, an underscore, and English letters
            characters += str_const.ENGLISH + '1234567890'
        if 'O' in modifiers:
            # processes the character-list and modifier arguments only once, at the first call to this instance of COUNTC
            # IGNORED
            pass
        if 'P' in modifiers:
            # adds punctuation marks to the list of characters
            characters += ";:',.()-"
        if 'Q' in modifiers:
            # ignores delimiters that are inside substrings that are enclosed in quotation marks.
            # If the value of string contains unmatched quotation marks, scanning from left to right
            # produces different words than scanning from right to left
            # The function parse_quoted_words() will be used
            pass
        if 'S' in modifiers:
            # adds punctuation marks to the list of characters
            characters += " \t\v\n\r\f"
        if 'T' in modifiers:
            # trims trailing blanks from the first and second arguments
            string = string.rstrip()
            characters = characters.rstrip()
        if 'U' in modifiers:
            # adds uppercase letters to the list of characters
            characters += str_const.ENGLISH.split('_')[1]  # A-Z
        if 'W' in modifiers:
            # adds printable characters to the list of characters
            characters += ''.join(str_const.CHARS[32:127])
        if 'X' in modifiers:
            # adds hexadecimal characters to the list of characters
            characters += str_const.HEX  # 'abcdeffABCDEF'  ? + '0123456789'

    if 'M' not in modifiers:
        """
        specifies that multiple consecutive delimiters, and delimiters at the beginning or end of the string argument,
        refer to words that have a length of 0. If the M modifier is not specified, multiple consecutive delimiters
        are treated as one delimiter, and delimiters at the beginning or end of the string argument are ignored.
        """
        if 'Q' not in modifiers and len(characters) > 0:
            characters = list(set(characters))
            # Replace all delimiters with the first one:
            char0 = characters[0]
            string = re.sub('[' + re.escape(''.join(characters)) + ']+', char0, string)
            # Replace multiple consecutive delimiters:
            string = string.replace(char0 * 2, char0)
            # Remove leading delimiters
            string = string[1:] if string[0] == char0 else string
            # Remove trailing delimiters:
            string = string[:-1] if string[-1] == char0 else string
            characters = char0

    # Find words basing on the 'Q' modifier or the list of delimiters:
    delimiters = ''.join(set(str_const.WORD_DELIMITERS if len(characters) == 0 else characters))
    if 'Q' in modifiers:
        words = _parse_quoted_words_(string, '\"', delimiters, False)
    else:
        pattern = '[' + re.escape(delimiters) + ']'
        words = re.split(pattern, string)

    # Select the word:
    words_len = len(words)
    if words_len == 0 or abs(count) > words_len:
        return ''
    elif count > 0:
        return words[count - 1]
    elif count < 0:
        return words[::-1][-count - 1]


def scanq(string: str, n: int, characters: str = None) -> str:
    chars = characters if not _missing_(characters) else ' _\t'
    return scan(string, n, chars, 'Q')


def strip(arg: str) -> str:
    return arg.strip()
