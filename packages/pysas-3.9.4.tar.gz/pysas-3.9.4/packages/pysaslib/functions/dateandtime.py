#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

# Category: Date and Time

import calendar as calendar
import datetime as dt
import typing

import dateutil.relativedelta as rd
import holidays as holidays
import numpy as np
import pandas as pd


def mdy(month: int, day: int, year: int) -> dt.date:
    """
    Function returns a datetime value constructed from year, month and day
    :param year: int
    :param month: int
    :param day: int
    :return: a datatime object
    """
    return dt.date(year, month, day)


def intck(interval: str, datefrom: dt.datetime, dateto: dt.datetime) -> int:
    interval = interval.lower()
    datefrom = np.datetime64(datefrom).astype(dt.datetime)
    dateto = np.datetime64(dateto).astype(dt.datetime)

    if interval == 'month':
        """
        Number of 1st days of month in a range [datefrom, dateto].
        Acceptable data types for datefrom and dateto parameters :
            datetime.datetime, numpy.datetime64, Pandas Timestamp, strings in ISO 8601 format
        :param datefrom: date from
        :param dateto: date to
        :return: Number of first days of month in the range [datefrom, dateto]
        """
        diff_m = __diff_month(datefrom, dateto)
        return diff_m
    else:
        raise Exception('function INTCK: Unsupported interval ' + str(interval))


def __diff_month(dt_from: dt.datetime, dt_to: dt.datetime) -> int:
    """
    Difference in months between dt_from and dt_to
    :param dt_from: a datetime object
    :param dt_to: a datetime object
    :return:  int
    """
    return (dt_to.year - dt_from.year) * 12 + dt_to.month - dt_from.month


def last_day_of_month(dtobj: dt.datetime) -> int:
    return calendar.monthrange(dtobj.year, dtobj.month)[1]


def middle_day_of_month(dtobj: dt.datetime) -> int:
    ld = calendar.monthrange(dtobj.year, dtobj.month)[1]
    if ld == 31:
        return 16
    elif ld in [30, 29]:
        return 15
    elif ld == 28:
        return 14


INTNX_LAMBDAS = {
    # DAY:
    ('DAY', 'B'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DAY', 'M'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DAY', 'E'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DAY', 'S'): lambda date, incr: date + rd.relativedelta(days=incr),
    # WEEK:
    ('WEEK', 'B'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('WEEK', 'M'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('WEEK', 'E'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('WEEK', 'S'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    # TENDAY:
    ('TENDAY', 'B'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('TENDAY', 'M'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('TENDAY', 'E'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('TENDAY', 'S'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    # SEMIMONTH:
    ('SEMIMONTH', 'B'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('SEMIMONTH', 'M'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('SEMIMONTH', 'E'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('SEMIMONTH', 'S'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    # MONTH:
    ('MONTH', 'B'): lambda date, incr: (date + rd.relativedelta(months=incr)).replace(day=1),
    ('MONTH', 'M'): lambda date, incr: (date + rd.relativedelta(months=incr)).replace(
        day=middle_day_of_month(date + rd.relativedelta(months=incr))),
    ('MONTH', 'E'): lambda date, incr: (date + rd.relativedelta(months=incr)).replace(
        day=last_day_of_month(date + rd.relativedelta(months=incr))),
    ('MONTH', 'S'): lambda date, incr: date + rd.relativedelta(months=incr),
    # QTR:
    ('QTR', 'B'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('QTR', 'M'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('QTR', 'E'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('QTR', 'S'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    # SEMIYEAR:
    ('SEMIYEAR', 'B'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('SEMIYEAR', 'M'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('SEMIYEAR', 'E'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('SEMIYEAR', 'S'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    # YEAR:
    ('YEAR', 'B'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=1, day=1),
    ('YEAR', 'M'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=6, day=30),
    ('YEAR', 'E'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=12, day=31),
    ('YEAR', 'S'): lambda date, incr: date + rd.relativedelta(years=incr),
    # DTDAY:
    ('DTDAY', 'B'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DTDAY', 'M'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DTDAY', 'E'): lambda date, incr: date + rd.relativedelta(days=incr),
    ('DTDAY', 'S'): lambda date, incr: date + rd.relativedelta(days=incr),
    # DTWEEK:
    ('DTWEEK', 'B'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('DTWEEK', 'M'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('DTWEEK', 'E'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    ('DTWEEK', 'S'): lambda date, incr: date + rd.relativedelta(weeks=incr),
    # DTTENDAY:
    ('DTTENDAY', 'B'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('DTTENDAY', 'M'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('DTTENDAY', 'E'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    ('DTTENDAY', 'S'): lambda date, incr: date + rd.relativedelta(days=incr * 10),
    # DTSEMIMONTH:
    ('DTSEMIMONTH', 'B'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('DTSEMIMONTH', 'M'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('DTSEMIMONTH', 'E'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    ('DTSEMIMONTH', 'S'): lambda date, incr: date + rd.relativedelta(days=incr * 15),
    # DTMONTH:
    ('DTMONTH', 'B'): lambda date, incr: dt.datetime.combine((date + rd.relativedelta(months=incr)).date(),
                                                             dt.datetime.min.time()),
    ('DTMONTH', 'M'): lambda date, incr: (date + rd.relativedelta(months=incr)).replace(
        day=middle_day_of_month(date + rd.relativedelta(months=incr))),
    ('DTMONTH', 'E'): lambda date, incr: dt.datetime.combine((date + rd.relativedelta(months=incr)).date(),
                                                             dt.datetime.max.time()),
    ('DTMONTH', 'S'): lambda date, incr: date + rd.relativedelta(months=incr),
    # DTQTR:
    ('DTQTR', 'B'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('DTQTR', 'M'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('DTQTR', 'E'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    ('DTQTR', 'S'): lambda date, incr: date + rd.relativedelta(months=incr * 3),
    # DTSEMIYEAR:
    ('DTSEMIYEAR', 'B'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('DTSEMIYEAR', 'M'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('DTSEMIYEAR', 'E'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    ('DTSEMIYEAR', 'S'): lambda date, incr: date + rd.relativedelta(months=incr * 6),
    # DTYEAR:
    ('DTYEAR', 'B'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=1, day=1),
    ('DTYEAR', 'M'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=6, day=30),
    ('DTYEAR', 'E'): lambda date, incr: (date + rd.relativedelta(years=incr)).replace(month=12, day=31),
    ('DTYEAR', 'S'): lambda date, incr: date + rd.relativedelta(years=incr),
    # SECOND:
    ('SECOND', 'B'): lambda date, incr: (date + rd.relativedelta(seconds=incr)).replace(second=0),
    ('SECOND', 'M'): lambda date, incr: (date + rd.relativedelta(seconds=incr)).replace(second=30),
    ('SECOND', 'E'): lambda date, incr: (date + rd.relativedelta(seconds=incr)).replace(second=59),
    ('SECOND', 'S'): lambda date, incr: date + rd.relativedelta(seconds=incr),
    # MINUTE:
    ('MINUTE', 'B'): lambda date, incr: (date + rd.relativedelta(minutes=incr)).replace(minute=0),
    ('MINUTE', 'M'): lambda date, incr: (date + rd.relativedelta(minutes=incr)).replace(minute=30),
    ('MINUTE', 'E'): lambda date, incr: (date + rd.relativedelta(minutes=incr)).replace(minute=59),
    ('MINUTE', 'S'): lambda date, incr: date + rd.relativedelta(minutes=incr),
    # HOUR:
    ('HOUR', 'B'): lambda date, incr: (date + rd.relativedelta(hours=incr)).replace(hour=0),
    ('HOUR', 'M'): lambda date, incr: (date + rd.relativedelta(hours=incr)).replace(hour=30),
    ('HOUR', 'E'): lambda date, incr: (date + rd.relativedelta(hours=incr)).replace(hour=59),
    ('HOUR', 'S'): lambda date, incr: date + rd.relativedelta(hours=incr)
}


def intnx_cache(interval: str,
                alignment: str) -> typing.Callable:
    invl = interval.strip().upper()
    almt = alignment.strip().upper()[0]
    return INTNX_LAMBDAS[(invl, almt)]


def intnx_lambda(datefrom: typing.Union[dt.datetime, dt.date],
                 increment: int,
                 func: typing.Callable) -> typing.Union[dt.datetime, dt.date]:
    return func(datefrom, increment)


def intnx(interval: str,
          datefrom: typing.Union[dt.datetime, dt.date],
          increment: int,
          alignment: str = 'SAME',
          func: typing.Callable = None) -> typing.Union[dt.datetime, dt.date]:
    """
    Add an increment of units specified by the interval to a datetime object
    :param interval: the basic interval type. Acceptable values:
            'year', 'month', 'week', 'day', 'hour', 'minute', 'second', 'microsecond'
    :param datefrom: an input date/datetime object
    :param increment: an increment in units specified by interval. Accepted positive or negative integer values.
    :param func: lambda function returned by the intnx_cache function, default None
    :return: the object datefrom incremented by increment.
    """
    if func is None:
        func = intnx_cache(interval, alignment)
    return func(datefrom, increment)


def dt_diff_year(dt1: dt.datetime, dt2: dt.datetime) -> int:
    return dt1.year - dt2.year


def dt_diff_month(dt1: dt.datetime, dt2: dt.datetime) -> int:
    return (dt1.year - dt2.year) * 12 + dt1.month - dt2.month


def dt_diff_day(dt1: dt.datetime, dt2: dt.datetime) -> int:
    return (dt1 - dt2).days


## Analogs of functions from FunDateTime.java ##

def month(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.month


def hms(hour: float, minute: float, second: float) -> float:
    return hour * 3600 + minute * 60 + second


def hour(dtobj: dt.datetime) -> float:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.hour


def datetime(utc: bool = True) -> dt.datetime:
    return dt.datetime.utcnow() if utc else dt.datetime.now()


def today(utc: bool = True) -> dt.date:
    return datetime(utc).date()


def dhms(dtobj: dt.date, h: float = 0, m: float = 0, s: float = 0) -> dt.datetime:
    """
    param dtobj: a Python date object
    param h: hours to be added
    param m: minutes to be added
    param s: seconds to be added
    returns: a Python datetime object
    """
    return dt.datetime(dtobj.year, dtobj.month, dtobj.day) + dt.timedelta(hours=h, minutes=m, seconds=s)


def datepart(dtobj: dt.datetime) -> dt.date:
    """
    param dtobj: a Python datetime object
    """
    return pd.to_datetime(dtobj).date()


def julian(y: int, day: int) -> dt.date:
    """
    Converts year and Julian day to Python datetime.date
    param y: 4-digits year, int value
    param day: julian day, int value
    returns: a Python datetime.date object
    """
    if y < dt.date.min.year or y > dt.date.max.year:
        return None
        # raise ValueError("Year must be in the range [{0}, {1}]".format(dtm.date.min.year, dtm.date.max.year))
    if day < 1 or day > 366:
        return None
        # raise ValueError("Julian day must be in the range [1, 366]")
    if not is_leap(y) and day > 365:
        return None
        # raise ValueError("Julian day must be in the range [1, 365] for non-leap years")
    y_ = str(y).rjust(4, '0')
    d_ = str(day).rjust(3, '0')
    j_dt = y_ + d_
    py_dt = dt.datetime.strptime(j_dt, '%Y%j').date()
    return py_dt


def datejul(juliandate: int) -> dt.date:
    year = juliandate // 1000
    day = juliandate % 1000
    return julian(year, day)


def juldate(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    d = dtobj.timetuple().tm_yday
    y = dtobj.year
    return y * 1000 + d


def juldate7(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    d = dtobj.timetuple().tm_yday
    y = dtobj.year
    return y * 1000 + d


def century(year: int) -> int:
    return int(str(year).rjust(4, '0')[0:2]) + 1


def time() -> dt.time:
    return dt.datetime.now().time()


def timepart(dtobj: dt.datetime) -> dt.time:
    """
    param dtobj: a Python datetime object
    """
    # return dt.time(dtobj.hour, dtobj.minute, dtobj.day, dtobj.secomd, dtobj.microsecond)
    return dtobj.time()


def week(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.isocalendar()[1]


def day(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.day


def weekday(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.weekday() + 1


def is_leap(year: int) -> bool:
    return calendar.isleap(year)


def yrdif(dtfrom: dt.datetime, dtto: dt.datetime, basis: str) -> float:
    """
    param dtfrom: start date, a Python datetime object
    param dtto: end date, a Python datetime object
    param basis: basis for calculating difference, one of character values:
                         "act/act", "actual", "act/365", "act/360", "30e/360", "30u/360", "30/360", "360"
    returns: difference between sdate and edate in years
    """
    if dtfrom == dtto:
        return 0.  # to fix tiny reminders if compute special code next
    elif basis == "30e/360":
        d = datdif(dtfrom, dtto, "30e/360")
        return d / 360.0
    elif basis == "30u/360" or basis == "30/360" or basis == "360":
        d = datdif(dtfrom, dtto, "30u/360")
        return d / 360.0
    elif basis == "act/360":
        return (dtto - dtfrom).days / 360.0  # TODO: (dtto - dtfrom) / 360.0 is wrong ?
    elif basis == "act/365":
        return (dtto - dtfrom).days / 365.0
    elif basis == "act/act" or basis == "actual":
        fromYear = dtfrom.year
        toYear = dtto.year
        head = mdy(1, 1, fromYear + 1) - dtfrom
        tail = dtto - mdy(1, 1, toYear)
        dif = toYear - fromYear - 1  # whole years in between dates
        dif += head.days / (366 if is_leap(fromYear) else 365)
        dif += tail.days / (366 if is_leap(toYear) else 365)
        return dif
    elif basis == "age":
        fromYear = dtfrom.year
        toYear = dtto.year
        head = mdy(1, 1, fromYear + 1) - dtfrom
        tail = dtto - mdy(1, 1, toYear)
        dif = toYear - fromYear - 1  # whole years in between dates
        # it appears an AGE basis takes into account leap year only for the
        # end of interval, when computes fractions for start-date and end-date
        # search a doc 66300 for a page containing "A YRDIF('07AUG1968'd,"
        # see 66300\chap5ex\ex5_10.sas,
        # see UG\NESUG\12\ff03\20.sas
        dif += (head.days + tail.days) / (366 if is_leap(toYear) else 365)
        return dif
    else:
        raise ValueError('Incorrect value of basis. Acceptable values: '
                         '"act/act", "actual","act/365", "act/360", "30e/360", "30u/360", "30/360", "360"')


def datdif(sdate: dt.datetime, edate: dt.datetime, basis: str) -> int:
    """
    param sdate: start date, a Python datetime object
    param edate: end date, a Python datetime object
    param basis: basis for calculating difference, one of character values:
                         "act/act", "actual", "act/365", "act/360", "30e/360", "30u/360", "30/360", "360"
    returns: difference between sdate and edate in days
    """
    if basis == "act/act" or basis == "actual":
        return (edate - sdate).days
    elif basis == "act/365":
        return date_dif(sdate, edate, 0, 365)
    elif basis == "act/360":
        return date_dif(sdate, edate, 0, 360)
    elif basis == "30e/360":
        return date_dif(sdate, edate, 30, 360, True)
    elif basis == "30u/360" or basis == "30/360" or basis == "360":
        return date_dif(sdate, edate, 30, 360, False)
    else:
        raise ValueError('Incorrect value of basis. Acceptable values: '
                         '"act/act", "actual","act/365", "act/360", "30e/360", "30u/360", "30/360", "360"')


def date_dif(dt1: dt.datetime, dt2: dt.datetime, month: int, year: int, eu: bool = False) -> int:
    """
    param dt1: date 1, a Python datetime object
    param dt2: date 2, a Python datetime object
    param month: number of month, int
    param year: number of years, int
    param eu: EU indicator, bool, default False - US (NASD) method for 30/360 by default
    returns: diffrerence in days
    """
    y1, y2 = dt1.year, dt2.year
    m1, m2 = dt1.month, dt2.month
    d1, d2 = dt1.day, dt2.day
    l1 = (dt1.replace(day=1) + rd.relativedelta(months=1) + rd.relativedelta(days=-1)).day
    l2 = (dt2.replace(day=1) + rd.relativedelta(months=1) + rd.relativedelta(days=-1)).day
    if month > 0:
        dif = (y2 - y1) * year + (m2 - m1) * month
        # last day adjustment to fixed month
        if d1 == l1:
            d1 = month
        if d2 == l2:
            d2 = month + (1 if d1 < month and not eu else 0)  # see DAYS360() in Excel
        dif += d2 - d1
    elif y2 > y1:
        dif = (y2 - y1 - 1) * year
        # first year months and days
        m = m1 + 1
        while m <= 12:
            dif += (dt1.replace(day=1).replace(month=m) + rd.relativedelta(months=1) + rd.relativedelta(days=-1)).day
            m += 1
        dif += l1 - d1 + 1
        # last year months and days
        m = 1
        while m < m2:
            dif += (dt2.replace(day=1).replace(month=m) + rd.relativedelta(months=1) + rd.relativedelta(days=-1)).day
            m += 1
        dif += d2 - 1
    else:
        dif = 0
        # whole months
        m = m1 + 1
        while m < m2:
            dif += (dt1.replace(day=1).replace(month=m) + rd.relativedelta(months=1) + rd.relativedelta(days=-1)).day
            m += 1
        # first month days
        dif += l1 - d1 + 1
        # last month days
        dif += d2 - 1
    return dif


def year(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.year


def yyq(year: int, quarter: int) -> dt.date:
    """
    param year:
    param quarter: integer
    return: a date corresponding the 1st day of a quarter in a year
    """
    return dt.date(year, quarter * 3 - 2, 1)


def qtr(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return (dtobj.month - 1) // 3 + 1


def second(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.second


def minute(dtobj: dt.datetime) -> int:
    """
    param dtobj: a Python datetime object
    """
    return dtobj.minute


def mdy(month: int, day: int, year: int) -> dt.date:
    return dt.date(year, month, day)


def calc_easter_day(year: int) -> dt.date:
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l_ = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l_) // 451
    month_ = (h + l_ - 7 * m + 114) // 31
    day_ = (h + l_ - 7 * m + 114) % 31 + 1
    return dt.date(year, month_, day_)


def calc_victoria_day(year: int) -> dt.date:
    d = dt.date(year, 5, 24)
    while d.weekday() != 0:  # 'Monday'
        d = d + dt.timedelta(days=-1)
    return d


def month_week_day(year: int, month: int, weekday: int, wdc: int) -> dt.date:
    """
    param year:
    param month: 1- January, 2 - February, ..., 12 - December
    param weekday: 0 - Sunday, 1 - Monday, ..., 6 - Saturday
    param wdc:
    """
    if wdc > 0:
        d = dt.date(year, month, 1)
        sgn = 1
    elif wdc < 0:
        d = dt.date(year, month + 1, 1) + dt.timedelta(days=-1)
    else:
        raise ValueError('Wrong parameter - Zero counter')
    while d.weekday() != weekday:
        d = d + dt.timedelta(days=sgn)
    return d + dt.timedelta(days=(wdc - 1) * 7 * sgn)


def calc_mothers_day(year: int) -> dt.date:
    return month_week_day(year, 5, 6, 2)


def calc_fathers_day(year: int) -> dt.date:
    return month_week_day(year, 6, 6, 3)


def calc_veteransusg_day(year: int) -> dt.date:
    d = dt.date(year, 11, 11)
    if d.weekday() == 5:  # 'SATURDAY'
        offset = -1
    elif d.weekday() == 6:  # 'SUNDAY'
        offset = 1
    else:
        offset = 0
    return d + dt.timedelta(days=offset)


def calc_veteransusps_day(year: int) -> dt.date:
    d = dt.date(year, 11, 11)
    offset = 1  # TODO, it is still unclear +1 or -1; the only confirmed case was found for year 2012 calendar
    if d.weekday() == 6:  # 'SUNDAY'
        offset = 1
    else:
        offset = 0
    return d + dt.timedelta(days=offset)


def holiday(hol: str, year: int) -> dt.date:
    """
    param hol: acronym for holiday value within a set of values. Example : 'NEWYEAR' .
    param year:  four-digit year.
    return: a date value of a specified holiday for a specified year.
    """
    ha = str(hol).strip().upper()
    ha_vals = check_holiday(ha)

    if ha_vals[0] == 'permanent':
        d = dt.date(year, ha_vals[3], ha_vals[4])
    elif ha_vals[0] == 'pypackage':
        d = {name: dt for dt, name in holidays.CountryHoliday(country=ha_vals[2], years=year).items()}[ha_vals[1]]
    elif ha_vals[0] == 'pyfunc':
        if ha == "EASTER":
            d = calc_easter_day(year)
        elif ha == "FATHERS":
            d = calc_fathers_day(year)
        elif ha == "MOTHERS":
            d = calc_mothers_day(year)
        elif ha == 'VETERANSUSG':
            d = calc_veteransusg_day(year)
        elif ha == 'VETERANSUSPS':
            d = calc_veteransusps_day(year)
        elif ha == "VICTORIA":
            d = calc_victoria_day(year)
    else:
        raise NotImplementedError('Holiday type "{0}" not implemented yet.'.format(ha_vals[0]))
    return d


def check_holiday(holiday: str) -> typing.Tuple[str, str, str, int, int]:
    """
    param holiday: acronym for holiday value within a set of values. Example : 'NEWYEAR' .
    return: if holiday==None: full dictionary holiday_acronyms
            Otherwise: a tuple corresponding the holiday value, for example ("permanent", "New Year's Day",  None, 1, 1)
            Exception is raised if holiday not found in the holiday_acronyms dictionary
    """
    # Dictionary with holiday acronyms (values of the parameter holiday):
    # '<KEY>' : ('<type>', '<description>', '<Country>', ...)
    holiday_acronyms = {
        "BOXING": ("permanent", "Boxing Day (Observed)", "CA", 12, 26),
        "BOXINGOBSERVED": ("pypackage", "Boxing Day (Observed)", "CA"),
        "CANADA": ("permanent", "Canada Day", "CA", 7, 1),
        "CANADAOBSERVED": ("pypackage", "Canada Day (Observed)", "CA"),
        "CHRISTMAS": ("permanent", "Christmas Day", None, 12, 25),
        "COLUMBUS": ("pypackage", "Columbus Day", "US"),
        "EASTER": ("pyfunc", "Easter Sunday", None),
        "FATHERS": ("pyfunc", "Father's Day", None),
        "HALLOWEEN": ("permanent", "Halloween", None, 10, 31),
        "LABOR": ("pypackage", "Labor Day", "US"),
        "MLK": ("pypackage", "Martin Luther King Jr. Day", "US"),
        "MEMORIAL": ("pypackage", "Memorial Day", "US"),
        "MOTHERS": ("pyfunc", "Mother's Day", None),
        "NEWYEAR": ("permanent", "New Year's Day", None, 1, 1),
        "THANKSGIVING": ("pypackage", "Thanksgiving", "US"),
        "THANKSGIVINGCANADA": ("pypackage", "Thanksgiving", "CA"),
        "USINDEPENDENCE": ("pypackage", "Independence Day", "US"),
        "USINDEPENDENCEOBSERVED": ("pypackage", "Independence Day (Observed)", "US"),
        "USPRESIDENTS": ("pypackage", "Washington's Birthday", "US"),
        "VALENTINES": ("permanent", "Valentine's Day", None, 2, 14),
        "VETERANS": ("pypackage", "Veterans Day", "US"),
        "VETERANSUSG": ("pyfunc", "Veterans Day - U.S. government-observed", "US"),
        "VETERANSUSPS": ("pyfunc", "Veterans Day - U.S. post office observed", "US"),
        "VICTORIA": ("pyfunc", "Victoria Day", "CA")
    }
    if holiday is None:
        return holiday_acronyms
    else:
        return holiday_acronyms[holiday]
