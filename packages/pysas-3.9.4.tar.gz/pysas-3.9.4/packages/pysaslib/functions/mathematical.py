#  Copyright 2008-2020 Dulles Research LLC. All Rights Reserved.

#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

# Category: Mathematical

import datetime
import math
import sys
import typing
from functools import reduce

import numpy as np
from scipy import special, stats, optimize


class MathConstants:
    EPS = 1e-10
    FUZZ = 1e-12
    POWER10 = [1, 10, 100, 1000, 10000, 100000, 1000000, 10000000, 100000000, 1000000000, 10000000000, 100000000000,
               1000000000000, 10000000000000, 100000000000000, 1000000000000000, 10000000000000000, 100000000000000000]
    POSITIVE_INFINITY = float('inf')
    NEGATIVE_INFINITY = float('-inf')
    METER_TO_MILE = 1.0 / 1609  # SAS uses rounded number, the exact conversion should be 1609.344 by NIST
    CONSTANTS = {
        'golden': math.sqrt(5) - 1,
        'pi': math.pi,
        'e': math.exp(1),
        'euler': 0.5772156649015328606065120900,
        'big': sys.float_info.max,
        'logbig': math.log(sys.float_info.max),
        'sqrtbig': math.sqrt(sys.float_info.max),
        'small': sys.float_info.min,
        'sqrtsmall': math.sqrt(sys.float_info.min),
        'maceps': 1e-53,

        'logmaceps': math.log(1e-53),
        'sqrtmaceps': math.sqrt(1e-53)
    }
    DISTRIBUTIONS = ['BERNOULLI', 'BERN', 'BINOMIAL', 'BINO', 'GAMMA', 'IGAUSS', 'WALD',
                     'GAUSSIAN', 'GAUSS', 'NORMAL', 'POISSON', 'POIS']


math_constants = MathConstants()


def is_numeric(val):
    if isinstance(val, int) or isinstance(val, float):
        return True
    else:
        return False


def divide(x: float, y: float) -> float:
    if is_numeric(x) and is_numeric(y):
        if x > 0:
            if y == 0:
                return math_constants.POSITIVE_INFINITY
            else:
                return x / y
        elif x == 0:
            if y == 0:
                return None
            else:  # y != 0
                return 0.0
        else:  # x < 0
            if y == 0:
                return math_constants.NEGATIVE_INFINITY
            else:  # y < 0
                return x / y
    else:
        return None


def airy(x: float) -> float:
    return special.airy(x)[0]


def beta(a: float, b: float) -> float:
    return math.gamma(a) * math.gamma(b) / math.gamma(a + b)


def betainv(p: float, a: float, b: float) -> float:
    return stats.beta.ppf(p, a, b)


def constant(constant: str, parameter: int = None) -> float:
    constant = constant.lower()
    val = math_constants.CONSTANTS.get(constant)
    if val is not None:
        return val
    elif constant == 'exactint':
        parameter = 8 if parameter is None else parameter
        if isinstance(parameter, int) and parameter >= 2 and parameter <= 8:
            return (1 << parameter * 8 - 1) - 1
        else:
            raise ValueError('Function EXACTINT expects 2 <= parameter <= 8.')
    else:
        raise NotImplementedError('The constant {} not supported yet.'.format(constant.upper()))


def convx(y: float, f: float, *c: typing.Tuple[float, ...]) -> float:
    if f > 0 and 0 < y < 1 and len(c) != 0:
        sum, p, con = 0, 0, f * y + 1
        for i in range(len(c)):
            p += c[i] / math.pow(con, i + 1)
            sum += (i + 1) * (i + 2) * (c[i] / math.pow(con, i + 1))
        return sum / (p * con * con)
    else:
        raise ValueError("Function CONVX expects f > 0, 0 < y < 1, and length(c) != 0")


def convxp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    con = 1 + y / n
    sum_, p_ = 0, 0
    tk_ = n * k0 - 1
    for i in range(1, k + 1):
        tk = tk_ + i
        ck = (1 + c / n) * a if i == k else c / n * a
        val_k = ck / math.pow(con, tk)
        sum_ += tk * (tk + 1) * val_k
        p_ += val_k
    return sum_ / p_ / math.pow(con, 2) / math.pow(n, 2)


def daccdbsl(p: float, v: float, y: float, r: float) -> float:
    if not (y > 0 and r >= 0):
        raise ValueError("Function DACCDBSL expects y > 0 and r >= 0")
    sum = 0
    for i in range(p):
        sum += depdbsl(i + 1, v, y, r)
    return sum


def depdbsl(p: float, v: float, y: float, r: float) -> float:
    if p < 0 or p > y:
        return 0
    t = int(y - y / r + 1)
    con = 1 - r / y
    st = p - 1
    if p <= t:
        return math.pow(con, st) * v * r / y
    else:
        return v * math.pow(con, t) / (y - t)


def depdb(p: float, v: float, y: float, r: float) -> float:
    if not (y > 0 and r >= 0):
        raise ValueError("Function DEPDB expects y > 0 and r >= 0")
    return daccdb(p, v, y, r) - daccdb(p - 1, v, y, r)


def daccdb(p: float, v: float, y: float, r: float) -> float:
    if not (y > 0 and r > 0):
        raise ValueError("Function DACCDB expects y > 0 and r > 0")
    if p <= 0:
        return 0
    else:
        int_p = int(p)
        con = 1 - r / y
        return v * (1 - math.pow(con, int_p)) * (1 - (p - int_p) * r / y)


def dacctab(p: float, v: float, *t: typing.Tuple[float, ...]) -> float:
    if not (v > 0):
        raise ValueError("Function DACCTAB expects v > 0")
    len_t = len(t)
    if len_t == 1 and isinstance(t[0], tuple):
        t = t[0]
        len_t = len(t)
    if p <= 0:
        return 0
    if p >= len_t:
        return v
    else:
        int_p = int(p)
        sum_ = sum([t[i] for i in range(int_p)])
        sum_ += t[int_p] * (p - int_p)
        sum_ *= v
        return round_(sum_)


def deptab(p: float, v: float, *t: typing.Tuple[float, ...]) -> float:
    if not (v > 0):
        raise ValueError("Function DEPTAB expects v > 0")
    d1 = dacctab(p, v, t)
    d2 = dacctab(p - 1, v, t)
    return d1 - d2


def depsl(p: float, v: float, y: float) -> float:
    if not (y > 0):
        raise ValueError("Function DEPSL expects y > 0")
    return daccsl(p, v, y) - daccsl(p - 1, v, y)


def daccsl(p: float, v: float, y: float) -> float:
    if not (y > 0):
        raise ValueError("Function DACCSL expects y > 0")
    if p < 0:
        return 0
    if p > y:
        return v
    else:
        return v * p / y


def dairy(x: float) -> float:
    return special.airy(x)[1]


def depsyd(p: float, v: float, y: float) -> float:
    if not (y > 0):
        raise ValueError("Function DEPSYD expects y > 0")
    return daccsyd(p, v, y) - daccsyd(p - 1, v, y)


def daccsyd(p: float, v: float, y: float) -> float:
    if not (y > 0):
        raise ValueError("Function DACCSYD expects y > 0")
    if p < 0:
        return 0
    if p > y:
        return v
    else:
        int_p, int_y = int(p), int(y)
        numerator = int_p * (y - (int_p - 1) / 2) + (p - int_p) * (y - int_p)
        denumerator = int_y * (y - (int_y - 1) / 2) + (y - int_y) * (y - int_y)
        return v * (numerator / denumerator)


def digamma(x: float) -> float:
    return special.digamma(x)


def dur(y: float, f: float, *c: typing.Tuple[float, ...]) -> float:
    if not (y > 0 and f > 0):
        raise ValueError("Function DUR expects y > 0 and f > 0")
    p, sum_, st, curr = 0, 0, 0, 0
    con = f * y + 1
    for i in (range(len(c))):
        st = (i + 1) / f
        curr = c[i] / math.pow(con, st)
        sum_ += (i + 1) * curr
        p += curr
    return sum_ / (p * (1 + y))


def durp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    if a > 0 and (0 <= c < 1) and (n > 0 and k > 0) and (0 < k0 <= 1.0 / n) and y > 0:
        p, sum_, curr, tk = 0, 0, 0, 0
        con = y / n + 1
        ck = c * a / n
        last = (c / n + 1) * a
        for i in range(k - 1):
            tk = n * k0 + i
            curr = ck / math.pow(con, tk)
            sum_ += tk * curr
            p += curr
        tk = n * k0 + k - 1
        curr = last / math.pow(con, tk)
        sum_ += tk * curr
        p += curr
        return sum_ / (n * con * p)
    else:
        raise ValueError("Function DURP expects a > 0, 0 <= c < 1, n > 0, k > 0, 0 < k0 <= 1/n, and y > 0")


def erf(x: float) -> float:
    return math.erf(x)


def erfc(x: float) -> float:
    return math.erfc(x)


def finv(p: float, ndf: float, ddf: float) -> float:
    return stats.f.ppf(p, ndf, ddf)


def floor(x: float) -> float:
    return math.floor(x)


def fuzz(arg: float) -> float:
    shift_ = arg + (math_constants.FUZZ if arg > 0 else -math_constants.FUZZ)
    floor_ = int(shift_)
    if arg > 0:
        return floor_ if floor_ <= shift_ and arg <= floor_ + math_constants.FUZZ else arg
    else:
        return floor_ if floor_ - math_constants.FUZZ < arg and shift_ <= floor_ else arg


def fact(n: int) -> int:
    return math.factorial(n)


def perm(n: int, v: int = None) -> float:
    if not (n >= 0):
        raise ValueError("Function PERM expects n >= 0")
    if v is None:
        return fact(n)
    else:
        if not (0 <= v <= n):
            raise ValueError("Function PERM expects 0 <= v <= n")
        return fact(n) / fact(n - v)


def gaminv(p: float, a: float) -> float:
    return stats.gamma.ppf(p, a)


def gamma(arg: float) -> float:
    return special.gamma(arg)


def ibessel(n: int, x: float, k: int) -> float:
    if not (n >= 0 and x >= 0 and k >= 0):
        raise ValueError("Function IBESSEL expects n >= 0, x >= 0, and k >= 0")
    if k == 0:
        return special.iv(n, x)
    else:
        return special.ive(n, x)


def int_(d: float) -> int:
    if d is None:
        return None
    else:
        return math.floor(d + math_constants.FUZZ) if d >= 0 else math.ceil(d - math_constants.FUZZ)


def intrr(freq: float, *c: typing.Tuple[float, ...]) -> float:
    import numpy_financial
    if not (freq >= 0):
        raise ValueError("Function INTRR expects freq >= 0.")
    if isinstance(c, np.ndarray):
        c_arr = c
    elif isinstance(c[0], tuple) or isinstance(c[0], list):
        c_arr = np.array([c_ for c_ in c[0]])
    else:
        c_arr = np.array(c)
    return numpy_financial.irr(c_arr)


def irr(freq: float, *c: typing.Tuple[float, ...]) -> float:
    if not (freq >= 0):
        raise ValueError("Function IRR expects freq >= 0.")
    return intrr(freq, c) * 100


def jbessel(n: float, x: float) -> float:
    if not (n >= 0 and x >= 0):
        raise ValueError("Function JBESSEL expects n >= 0 and x >= 0.")
    return special.jn(n, x)


def largest(n: int, *values: typing.Tuple[float, ...]) -> float:
    len_v = len(values)
    if n <= 0 or n > len_v:
        raise ValueError("Function LARGEST expects n > 0 and n <= len(values).")
    max_list = list()
    for i in range(n):
        max_ = max([v for v in values if v not in max_list])
        max_list.append(max_)
    return max_list[-1]


def sort(array: typing.List[float], convert: bool = False) -> typing.Tuple[int, typing.List[float]]:
    """
    param array: a list of values
    param convert: convert all values to the str type, default False
    return: a tuple (1, <Sorted array>) in the case of successful sorting, (0, <array>) otherwise
    """
    arr_ = list(array)
    # Classsify types of values in array:
    type_arr = list()
    for a in arr_:
        if isinstance(a, (int, float, complex)):
            type_ = 'numeric'
        elif isinstance(a, str):
            type_ = 'str'
        elif isinstance(a, bool):
            type_ = 'bool'
        elif a is None:
            type_ = 'None'
        else:
            type_ = 'other'
        type_arr.append(type_)
    # Convert all elements of array to str type if the array contains different value types:
    if len(set(type_arr)) > 1 and convert:
        arr_ = [str(a) for a in arr_]
    # Try to sort the list and return the result:
    try:
        arr_.sort()
        return (1, arr_)
    except:
        return (0, array)


def tinv(p: float, df: float, nc: float = 0) -> float:
    if nc == 0:
        return stats.t.ppf(p, df)
    else:
        return stats.nct.ppf(p, df, nc)


def ranuni(seed: int) -> float:
    """
    if seed ≤ 0, the time of day is used to initialize the seed stream
    """
    if seed <= 0:
        seed = int(datetime.datetime.now().timestamp() * 1e6)
    np.random.seed(seed)
    return np.random.uniform(0.0, 1.0, 1)[0]


def ceil(x: float) -> float:
    if not math.isnan(x):
        return math.ceil(x)
    else:
        return math.nan


def compound(a: float, f: float, r: float, n: float) -> float:
    if math.isnan(a):
        if not (f >= 0 and r >= 0 and n >= 0):
            raise ValueError('Function COMPOUND expects f >= 0, r >= 0, and n >= 0.')
        return round(f / math.pow(1 + r, n))
    elif math.isnan(f):
        if not (a >= 0 and r >= 0 and n >= 0):
            raise ValueError('Function COMPOUND expects a >= 0, r >= 0, and n >= 0.')
        return a * math.pow(1 + r, n)
    elif math.isnan(r):
        if not (a >= 0 and f >= 0 and n >= 0):
            raise ValueError('Function COMPOUND expects a >= 0, f >= 0, and n >= 0.')
        return math.exp(math.log(f / a) / n) - 1
    elif math.isnan(n):
        if not (a >= 0 and f >= 0 and r >= 0):
            raise ValueError('Function COMPOUND expects a >= 0, f >= 0, and r >= 0.')
        return round(math.log(f / a) / math.log(1 + r))
    else:
        raise ValueError('Function COMPOUND expects a correct combitation of input parameters.')
        # new IllegalArgumentException("data.runtime.function.compound");


def log2(x: float) -> float:
    return math.log2(x)


def npv(r: float, freq: float, *c: typing.Tuple[float, ...]) -> float:
    return netpv(r, freq, c)


def netpv(r: float, freq: float, *c: typing.Tuple[float, ...]) -> float:
    if len(c) == 1 and isinstance(c[0], (list, tuple)):
        vals = list(c[0])
    else:
        vals = [v for v in c]
    if freq < 0:
        raise ValueError('Function NETPV expects freq >= 0.')
    else:
        x = 0
        if freq > 0:
            x = 1 / math.pow(r + 1, 1 / freq)
        else:
            x = math.exp(-r)
        lst_ = map(lambda i: vals[i] * math.pow(x, i), range(0, len(vals)))
        return reduce(lambda x, y: x + y, lst_)


def ordinal(n: int, *values: typing.Tuple[float, ...]) -> float:
    if n <= 0 or n > len(values):
        raise ValueError('Function ORDINAL expects n > 0 and n <= len(values)')
    return sort(values, True)[1][n - 1]


def pvp(a: float, c: float, n: int, k: int, k0: float, y: float) -> float:
    p, tk = 0, 0
    con = y / n + 1
    ck = c * a / n
    last = (c / n + 1) * a
    lst_ = map(lambda i: (ck if i < k - 1 else last) / math.pow(con, n * k0 + i), range(0, k))
    return reduce(lambda x, y: x + y, lst_)


def round_(number: float, digits: int = 0) -> float:
    return round(number, digits)


def round_sas(arg: float, unit: float = 1) -> float:
    if not (unit > 0):
        raise ValueError('Function ROUND_SAS expect unit > 0.')
    if arg is None:
        return None
    else:
        # if unit is integer , special case
        if unit >= 1 and int(unit) == unit:
            n = int(unit)
            r = round_(arg / n)
            return r * n

        scale = 1 / unit
        # check that the scale is power of 10 with difference limited to at most to 4 significant bits
        log = math.log10(scale)
        degree = int(round_(log))
        if abs(degree - log) < 1e-8 and degree <= 15:
            # special case from documentation, we scale by the power of 10
            if 0 <= degree and degree < len(math_constants.POWER10):
                n = math_constants.POWER10[degree]
                r = math.floor(arg * (1 + math_constants.FUZZ) * n + .5)
                return r / n
            else:
                n = math.pow(10, degree)
                r = math.floor(arg * (1 + math_constants.FUZZ) * n + .5)
                return r / n
        else:
            r = arg / unit
            n = math.floor(r)
            floor = n * unit
            ceil = floor + unit
            mid = floor + unit * 0.5 - math_constants.FUZZ
            return ceil if r - n >= 0.5 or arg >= mid else floor


def rounde(argument: float, unit: float) -> float:
    if not (unit > 0):
        raise ValueError('Function ROUNDE expects unit > 0.')
    is_small = unit < 1
    divided = argument * (1 / unit) if is_small else argument / unit
    if abs(divided - int(divided)) == 0.5:
        floor_ = int(math.floor(divided))
        ceil_ = int(math.ceil(divided))
        divided = float(floor_) if floor_ % 2 == 0 else float(ceil_)
    else:
        divided = round_(divided)
    if is_small:
        return divided / (1 / unit)
    else:
        return divided * unit


def roundz(argument: float, unit: float) -> float:
    if not (unit > 0):
        raise ValueError('Function ROUNDZ expects unit > 0.')
    is_small = unit < 1
    divided = argument * (1 / unit) if is_small else argument / unit
    if abs(divided - int(divided)) == 0.5:
        floor_ = int(math.floor(divided))
        ceil_ = int(math.ceil(divided))
        divided = float(floor_) if floor_ % 2 == 0 else float(ceil_)
    else:
        divided = round_(divided)
    if is_small:
        return divided / (1 / unit)
    else:
        return divided * unit


def smallest(n: int, *values: typing.Tuple[float, ...]) -> float:
    len_v = len(values)
    if n <= 0 or n > len_v:
        raise ValueError('Function SMALLEST expects n > 0 and n <= len(values).')
    min_list = list()
    for i in range(n):
        lst_ = [v for v in values if v not in min_list and not math.isnan(v)]
        if len(lst_) > 0:
            min_list.append(min(lst_))
    # Add NaN values to the list:
    if n > len(min_list):
        min_list = min_list + [v for v in values if math.isnan(v)]
    return min_list[-1]


def mod(arg1: float, arg2: float) -> float:
    norm = abs(arg2)
    ratio = int(fuzz(arg1 / norm))
    return fuzz(arg1 - ratio * norm)


def modz(arg1: float, arg2: float) -> float:
    norm = abs(arg2)
    return arg1 - int(arg1 / norm) * norm


def geodist(lat1: float, lon1: float, lat2: float, lon2: float, miles: bool, radian: bool) -> float:
    a, b, f = 6378137, 6356752.314245, 1 / 298.257223563  # WGS-84 ellipsoid params
    l = lon2 - lon1 if radian else math.radians(lon2 - lon1)
    u1 = math.atan((1 - f) * math.tan(lat1 if radian else math.radians(lat1)))
    u2 = math.atan((1 - f) * math.tan(lat2 if radian else math.radians(lat2)))
    sinu1, cosu1 = math.sin(u1), math.cos(u1)
    sinu2, cosu2 = math.sin(u2), math.cos(u2)

    lambda_ = l
    iter_limit = 100
    lambda_p = 0
    while abs(lambda_ - lambda_p) > 1e-12 and iter_limit > 0:
        sin_lambda = math.sin(lambda_)
        cos_lambda = math.cos(lambda_)
        sin_sigma = math.sqrt((cosu2 * sin_lambda) * (cosu2 * sin_lambda)
                              + (cosu1 * sinu2 - sinu1 * cosu2 * cos_lambda) * (
                                      cosu1 * sinu2 - sinu1 * cosu2 * cos_lambda))
        if sin_sigma == 0:
            return 0  # co-incident points
        cos_sigma = sinu1 * sinu2 + cosu1 * cosu2 * cos_lambda
        sigma = math.atan2(sin_sigma, cos_sigma)
        sin_alpha = cosu1 * cosu2 * sin_lambda / sin_sigma
        cossq_alpha = 1 - sin_alpha * sin_alpha
        cos2_sigma_m = cos_sigma - 2 * sinu1 * sinu2 / cossq_alpha
        if math.isnan(cos2_sigma_m):
            cos2_sigma_m = 0  # equatorial line: cossq_alpha=0 (§6)
        c = f / 16 * cossq_alpha * (4 + f * (4 - 3 * cossq_alpha))
        lambda_p = lambda_
        lambda_ = l + (1 - c) * f * sin_alpha \
                  * (sigma + c * sin_sigma * (cos2_sigma_m + c * cos_sigma * (-1 + 2 * cos2_sigma_m * cos2_sigma_m)))
        iter_limit -= 1

    if iter_limit == 0:
        return math.nan  # formula failed to converge

    u_sq = cossq_alpha * (a * a - b * b) / (b * b)
    A = 1 + u_sq / 16384 * (4096 + u_sq * (-768 + u_sq * (320 - 175 * u_sq)))
    B = u_sq / 1024 * (256 + u_sq * (-128 + u_sq * (74 - 47 * u_sq)))
    delta_sigma = B * sin_sigma * (cos2_sigma_m + B / 4 * (cos_sigma * (-1 + 2 * cos2_sigma_m * cos2_sigma_m)
                                                           - B / 6 * cos2_sigma_m * (-3 + 4 * sin_sigma * sin_sigma) * (
                                                                   -3 + 4 * cos2_sigma_m * cos2_sigma_m)))
    dist = b * A * (sigma - delta_sigma)
    return dist * math_constants.METER_TO_MILE if miles else dist * 0.001


def deviance(distr: str, var: float, *params: typing.Tuple[float, ...]) -> float:
    distr = distr.strip().upper()
    length = len(params)
    if distr in ('BERNOULLI', 'BERN'):
        if not (var == 0 or (var == 1 and length != 0)):
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'
                             .format(distr, 'var = 0 or (var = 1 and len(params) != 0)'))
        p, e = params[0], params[1]
        if length == 2:
            p = e if p <= e or p >= 1 - e else p
        return -2 * math.log(1 - p) if var == 0 else -2 * math.log(p)
    elif distr in ('BINOMIAL', 'BINO'):
        n = 0
        if not (0 <= var <= 1 and params[1] >= 0 and params[1] >= params[0] >= 0):
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'
                             .format(distr, '0 <= var <= 1 and params[1] >= 0 and params[1] >= params[0] >= 0'))
        if length == 3:
            mu, n, e = params[0], params[1], params[2]
            if mu <= n * e and mu >= 0:
                mu = n * e
            elif mu <= n and mu >= n * (1 - e):
                mu = n * (1 - e)
        elif length == 2:
            mu, n = params[0], params[1]
        else:
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'.format(distr, '2 <= len(params) <= 3'))
        if var < 0 or var > n:
            return math.nan
        else:
            return 2 * (var * math.log(var / mu) + (n - var) * math.log((n - var) / (n - mu)))
    elif distr in ('GAMMA'):
        mu, e = 0, 0
        if length == 2:
            mu, e = params[0], params[1]
            mu = e if mu <= e and mu >= 0 else mu
            var = e if var <= e and var >= 0 else var
        elif length == 1:
            mu = params[0]
        else:
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'.format(distr, 'len(params) <= 2'))
        return math.nan if var < 0 else 2 * (-math.log(var / mu) + (var - mu) / mu)
    elif distr in ('IGAUSS', 'WALD'):
        mu, e = 0, 0
        if length == 2:
            mu, e = params[0], params[1]
            mu = e if mu <= e and mu >= 0 else mu
            var = e if var <= e and var >= 0 else var
        elif length == 1:
            mu = params[0]
        else:
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'.format(distr, 'len(params) <= 2'))
        return 0 if var < 0 else math.pow(var - mu, 2) / (mu * mu * var)
    elif distr in ('GAUSSIAN', 'GAUSS', 'NORMAL'):
        if not (length == 1):
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'.format(distr, 'len(params) = 1'))
        return (var - params[0]) * (var - params[0])
    elif distr in ('POISSON', 'POIS'):
        mu, e = 0, 0
        if length == 2:
            mu, e = params[0], params[1]
            mu = e if e >= mu >= 0 else mu
        elif length == 1:
            mu = params[0]
        else:
            raise ValueError('Function DEVIANCE for {} distribution expects {}.'.format(distr, 'len(params) <= 2'))
        return math.nan if var < 0 else 2 * (var * math.log(var / mu) - (var - mu))
    else:
        raise NotImplementedError('The {} distribution not implemented yet in the function DEVIANCE.'.format(distr))


def mort(a: float, p: float, r: float, n: float) -> float:
    import numpy_financial
    if a is None:
        return p * (math.pow(1 + r, n) - 1) / (r * math.pow(1 + r, n))
    elif p is None:
        return -numpy_financial.pmt(r, n, a)
    elif r is None:
        def func_deriv(x):
            fun = math.pow(1 + x, n) * (p - a * x) - p
            drv1 = n * math.pow(1 + x, n - 1) * (p - a * x) - a * math.pow(1 + x, n)
            return fun, drv1

        sl = optimize.root_scalar(func_deriv, fprime=True, x0=0.1, method='newton', maxiter=50, xtol=math_constants.EPS)
        return sl.root
    elif n is None:
        return float(numpy_financial.nper(r, -p, a))
    else:
        raise ValueError('Function MORT expects either a = None, p = None, or r = None.')


def saving(f: float, p: float, r: float, n: float) -> float:
    # if n <= 0 :
    #    raise ValueError('Function SAVING expects n > 0.')
    if n is None and f >= 0 and p >= 0 and r >= 0:
        return math.log(1 + (f * r) / (p * (1 + r))) / math.log(1 + r)
    elif r is None and f >= 0 and p >= 0 and n >= 0:
        def func_deriv(x):
            fun = p * math.pow(1 + x, n + 1) - x * (p + f) - p
            drv1 = p * (n + 1) * math.pow(1 + x, n) - (p + f)
            return fun, drv1

        sl = optimize.root_scalar(func_deriv, fprime=True, x0=1, method='newton', maxiter=100, xtol=math_constants.EPS)
        return sl.root
    elif p is None and f >= 0 and r >= 0 and n >= 0:
        return (f * r) / ((1 + r) * (math.pow(1 + r, n) - 1))
    elif f is None and p >= 0 and r >= 0 and n >= 0:
        return p * (1 + r) * (math.pow(1 + r, n) - 1) / r
    else:
        raise ValueError('Function SAVING expects either f = None, p = None, r = None, or n = None.')


def probbnrm(x: float, y: float, r: float) -> float:
    if abs(r) > 1:
        raise ValueError('Function PROBBNRM expects -1 <= r <= 1')
    var = stats.multivariate_normal(mean=[0, 0], cov=[[1, r], [r, 1]])
    return var.cdf([x, y])


def probchi(x: float, df: float, nc: float = 0) -> float:
    if not (x >= 0 and df > 0 and nc >= 0):
        raise ValueError('Function PROBCHI expects x >= 0, df > 0, and nc >= 0.')
    var = stats.chi2(df) if nc == 0 else stats.ncx2(df, nc)
    return var.cdf(x)


def cnonct(x: float, df: float, p: float) -> float:
    if not (x >= 0 and df > 0 and 0 < p < 1):
        raise ValueError('Function CNONCT expects x >= 0, df > 0, and 0 < p < 1.')
    if p > probchi(x, df, 0):
        raise ValueError('A root to this problem does not exist because p > probchi(x, df, 0).')
    else:
        def func(z):
            return probchi(x, df, z) - p

        sl = optimize.root_scalar(func, bracket=[0, 1000], method='brentq', maxiter=100, xtol=math_constants.EPS)  #
        return sl.root


def blackclprc(e: float, t: float, f: float, r: float, sigma: float) -> float:
    if t >= 0:
        d1 = (math.log(f / e) + (sigma * sigma / 2.0) * t) / (sigma * math.sqrt(t))
        d2 = d1 - sigma * math.sqrt(t)
        nd1, nd2 = stats.norm.cdf(d1), stats.norm.cdf(d2)
        return math.exp(-r * t) * (f * nd1 - e * nd2)
    else:
        return 0


def blackptprc(e: float, t: float, f: float, r: float, sigma: float) -> float:
    if t >= 0:
        return blackclprc(e, t, f, r, sigma) + math.exp(-r * t) * (e - f)
    else:
        return 0


def cdf(name: str, quantile: float, *args: typing.Tuple[float, ...]):
    name = name.strip().upper()
    arg_len = len(args)
    if name in ['BERNOULLI', 'BERN']:
        if not (len(args) == 1 and 0 <= args[0] <= 1):
            raise ValueError('Function CDF (the {} distribution) expects {}.'.
                             format(name, 'len(args) = 1 and 0 <= args[0] <= 1'))
        else:
            p = args[0]
            if quantile > 0 or quantile < 1:
                return 1 - p
            elif quantile > 1:
                return 1
            else:
                return 0

    elif name in ['BETA']:
        l, r = 0, 1
        if arg_len == 4:
            r = args[3]
        elif arg_len == 3:
            l = args[2]
        elif arg_len == 2:
            pass
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '2 <= len(args) <= 4'))
        # TODO I haven't changed here anything,test works correct.
        # But CDF BETA does not support this case!!!
        if not (l == 0 and r == 1):
            raise NotImplementedError('Function CDF (the {} distribution) does not support {}.'
                                      .format(name, 'l != 0 or r != 1'))
        a, b = args[0], args[1]
        return stats.beta.cdf(quantile, a, b)

    elif name in ['BINOMIAL', 'BINOM']:
        if arg_len == 2:
            return stats.binom.cdf(quantile, args[1], args[0])
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))

    elif name in ['CAUCHY']:
        if arg_len == 0:
            median, scale = 0, 1
        elif arg_len == 1:
            median, scale = args[0], 1
        elif arg_len == 2:
            median, scale = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        return stats.cauchy.cdf(quantile, median, scale)

    elif name in ['CHISQUARE']:
        if arg_len == 1:
            return stats.chi2.cdf(quantile, args[0])
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['EXPONENTIAL', 'EXPO']:
        if arg_len == 0:
            lmb = 1
        elif arg_len == 1:
            lmb = args[0]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 1'))
        return stats.expon.cdf(quantile, scale=1 / lmb)

    elif name in ['F']:
        if arg_len == 2:
            dfn, dfd, nc = args[0], args[1], 0
        elif arg_len == 3:
            dfn, dfd, nc = args[0], args[1], args[2]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '2 <= len(args) <= 3'))
        # TODO Here is also not supported feature, but test case works fine:
        if not (nc == 0):
            raise NotImplementedError('Function CDF (the {} distribution) does not support {}.'
                                      .format(name, 'nc != 0'))
        return stats.f.cdf(quantile, dfn, dfd)

    elif name in ['GAMMA']:
        if arg_len == 1:
            a, lmd = args[0], 1
        elif arg_len == 2:
            a, lmd = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        return stats.gamma.cdf(quantile, a=a, scale=lmd)

    elif name in ['GEOMETRIC']:
        if arg_len == 1:
            p = args[0]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))
        return stats.geom.cdf(quantile, p)

    elif name in ['HYPERGEOMETRIC', 'HYPER']:
        # SAS -> Python: n_ -> M, r_ -> n, n -> N,
        if arg_len == 3:
            n_, r_, n, o = args[0], args[1], args[2], 1
        elif arg_len == 4:
            n_, r_, n, o = args[0], args[1], args[2], args[3]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '3 <= len(args) <= 4'))
        # TODO Here is also not supported feature:
        if not (o == 1):
            raise NotImplementedError('Function CDF (the {} distribution) does not support {}.'
                                      .format(name, 'o != !'))
        return stats.hypergeom.cdf(quantile, n_, r_, n)

    elif name in ['LAPLACE']:
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if lamb <= 0:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[1] > 0'))
        return stats.laplace.cdf(quantile, teta, lamb)

    elif name in ['LOGISTIC']:
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if lamb <= 0:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[1] > 0'))
        return stats.logistic.cdf(quantile, teta, lamb)

    elif name in ['LOGNORMAL', 'LOGN']:
        # SAS -> Python: teta -> loc, lamb -> s
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if lamb <= 0:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[1] > 0'))
        return stats.lognorm.cdf(quantile, s=lamb, loc=teta)

    elif name in ['NEGBINOMIAL', 'NEGB']:
        if arg_len == 2:
            p, n = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))
        return stats.nbinom.cdf(quantile, n, p)

    elif name in ['NORMAL', 'GAUSS', 'GAUSSIAN']:
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if lamb <= 0:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[1] > 0'))
        return stats.norm.cdf(quantile, scale=lamb, loc=teta)

    elif name in ['NORMALMIX']:
        # (x, n, p, m, s) -> (x, n, [p1, p2, ..., pn], [m1, m2, ..., mn], [s1, s2, ..., sn])
        n = args[0]
        if not (n > 0):
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[0] > 0'))
        if not (len(args) == n * 3 + 1):
            raise ValueError('Function CDF (the {} distribution) expects len(args) = {} if arg[0] = {} .'
                             .format(name, n * 3 + 1, n))
        # Read parameters:
        p, m, s = list(), list(), list()
        for i in range(n):
            p.append(args[i + 1])
            m.append(args[i + 1 + n])
            s.append(args[i + 1 + 2 * n])
            if s[i] <= 0:
                raise ValueError('Function CDF (the {} distribution) expects standard deviations > 0 (args[{}..{}]).'
                                 .format(name, 1 + 2 * n, 3 * n))
        # Check proportions:
        if sum(p) != 1:
            raise ValueError('Function CDF (the {} distribution) expects the sum of proportions = 1 (args[{}..{}]).'
                             .format(name, 1, n))
        return sum([p[i] * stats.norm.cdf(quantile, loc=m[i], scale=s[i]) for i in range(n)])

    elif name in ['PARETO']:
        if arg_len == 1:
            a, k = args[0], 1
        elif arg_len == 2:
            a, k = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        if not (a > 0 and k > 0):
            raise ValueError('Function CDF (the {} distribution) expects {}.'
                             .format(name, 'args[0] > 0 and args[1] > 0'))
        return 0 if quantile < k else 1 - math.pow(k / quantile, a)

    elif name in ['POISSON']:
        if arg_len == 1:
            return stats.poisson.cdf(quantile, args[0])
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['TWEEDIE']:
        import tweedie
        if arg_len == 1:
            p, mu, phi = args[0], 1, 1
        elif arg_len == 2:
            p, mu, phi = args[0], args[1], 1
        elif arg_len == 3:
            p, mu, phi = args[0], args[1], args[2]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 1 <= 'len(params) <= 3'))
        return tweedie.tweedie(mu=mu, p=p, phi=phi).cdf(quantile)

    elif name in ['T']:
        if arg_len == 1:
            df, nc = args[0], 0
        elif arg_len == 2:
            df, nc = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        if not (df > 0):
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[0] > 0'))
        return stats.t.cdf(quantile, df, nc)

    elif name in ['UNIFORM']:
        if arg_len == 0:
            l, r = 0, 1
        elif arg_len == 1:
            l, r = args[0], 1
        elif arg_len == 2:
            l, r = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if not (l < r):
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, 'args[0] < args[1]'))
        return stats.uniform.cdf(quantile, l, r)

    elif name in ['WALD', 'IGAUSS']:
        if arg_len == 1:
            l, m = args[0], 1
        elif arg_len == 2:
            l, m = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        if not (l > 0 and m > 0):
            raise ValueError('Function CDF (the {} distribution) expects {}.'
                             .format(name, 'args[0] > 0 and args[1] > 0'))
        if quantile < 0:
            return 0
        else:
            return cdf('NORMAL', math.sqrt(l / quantile) * (quantile / m - 1)) \
                   + math.exp(2 * l / m) * cdf('NORMAL', - math.sqrt(l / quantile) * (quantile / m + 1))

    elif name in ['WEIBULL']:
        if arg_len == 1:
            a, l = args[0], 1
        elif arg_len == 2:
            a, l = args[0], args[1]
        else:
            raise ValueError('Function CDF (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        if not (a > 0 and l > 0):
            raise ValueError('Function CDF (the {} distribution) expects {}.'
                             .format(name, 'args[0] > 0 and args[1] > 0'))
        return stats.weibull_min.cdf(quantile, a, loc=0, scale=l)

    else:
        raise NotImplementedError('The {} distribution not implemented yet in the function CDF.'.format(name))


def cinv(p: float, df: float, nc: float = 0) -> float:
    return stats.chi2.ppf(p, df, loc=nc)


def comb(n: int, r: int) -> float:
    return math.factorial(n) / math.factorial(r) / math.factorial(n - r)


def lgamma(x: float) -> float:
    return math.log(special.gamma(x))


def logbeta(a: float, b: float) -> float:
    return math.log(beta(a, b))


def poisson(mean: float, arg: float) -> float:
    return stats.poisson.cdf(arg, mean)


def probbeta(x: float, a: float, b: float) -> float:
    return stats.beta.cdf(x, a, b)


def probbnml(p: float, n: int, m: int) -> float:
    return stats.binom.cdf(m, n, p)


def probf(x: float, ndf: float, ddf: float) -> float:
    return stats.f.cdf(x, ndf, ddf)


def probgam(x: float, a: float) -> float:
    return stats.gamma.cdf(x, a)


def probhypr(N: int, K: int, n: int, x: int, r: float = 1.0) -> float:
    if r != 1.0:
        raise NotImplementedError('The function PROBHYPR supports only r = 1.')
    # SAS -> Python: n_ -> M, r_ -> n, n -> N,
    return stats.hypergeom.cdf(x, M=N, n=K, N=n)


def probnorm(x: float) -> float:
    return stats.norm.cdf(x)


def probit(p: float) -> float:
    return stats.norm.ppf(p)


def probnegb(p: float, n: int, m: int) -> float:
    return stats.nbinom.cdf(m, n, p)


def probt(x: float, freedom: float, nc: float) -> float:
    return stats.t.cdf(x, freedom, loc=nc)


def rannor(seed: int) -> float:
    return stats.norm.rvs(size=1, random_state=seed)[0]


def sdf(distr: str, quantile: float, *args: typing.Tuple[float, ...]) -> float:
    return 1 - cdf(distr, quantile, *args)


def logsdf(distr: str, quantile: float, *args: typing.Tuple[float, ...]) -> float:
    return math.log(sdf(distr, quantile, *args))


def ranbin(seed: int, n: int, p: float) -> float:
    return stats.binom.rvs(n, p, random_state=seed)


def ranexp(seed: int) -> float:
    return stats.expon.rvs(random_state=seed)


def rangam(seed: int, alpha: float) -> float:
    return stats.gamma.rvs(alpha, random_state=seed)


def ranpoi(seed: int, mean: int) -> float:
    return stats.poisson.rvs(mean, random_state=seed)


def logcdf(name: str, quantile: float, *args: typing.Tuple[float, ...]) -> float:
    """
    TODO in base SAS documentation they say that LOGCDF computes
    the logarithm of a LEFT cumulative distribution function
    What it is?
    """
    return math.log(cdf(name, quantile, *args))


def logpdf(name: str, x: float, *params: typing.Tuple[float, ...]) -> float:
    return math.log(pdf(name, x, *params))


def pdf(name: str, x: float, *params: typing.Tuple[float, ...]) -> float:
    name = name.strip().upper()
    param_len = len(params)
    if name in ['BERNOULLI', 'BERN']:
        if not (param_len == 1 and 0 <= params[0] <= 1):
            raise ValueError('Function PDF (the {} distribution) expects {}.'.
                             format(name, 'len(params) = 1 and 0 <= params[0] <= 1'))
        else:
            p = params[0]
            return stats.bernoulli.pmf(x, p)

    elif name in ['BETA']:
        l, r = 0, 1
        if param_len == 4:
            r = params[3]
        elif param_len == 3:
            l = params[2]
        elif param_len == 2:
            pass
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '2 <= len(params) <= 4'))
        if not (l < r):
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[3] > params[2]'))
        a, b = params[0], params[1]
        return stats.beta.pdf(x, a, b, l, r)

    elif name in ['BINOMIAL', 'BINOM']:
        if param_len == 2:
            return stats.binom.pmf(x, params[1], params[0])
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 2'))

    elif name in ['CAUCHY']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        return stats.cauchy.pdf(x, teta, lamb)

    elif name in ['CHISQUARE']:
        if param_len == 1:
            return stats.chi2.pdf(x, params[0])
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))

    elif name in ['EXPONENTIAL', 'EXPO']:
        if param_len == 0:
            lmb = 1
        elif param_len == 1:
            lmb = params[0]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 1'))
        return stats.expon.pdf(x, scale=1 / lmb)

    elif name in ['F']:
        if param_len == 2:
            dfn, dfd, nc = params[0], params[1], 0
        elif param_len == 3:
            dfn, dfd, nc = params[0], params[1], params[2]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '2 <= len(params) <= 3'))
        return stats.f.pdf(x, dfn, dfd, loc=nc)

    elif name in ['GAMMA']:
        if param_len == 1:
            a, lmd = params[0], 1
        elif param_len == 2:
            a, lmd = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        return stats.gamma.pdf(x, a=a, scale=lmd)

    elif name in ['GEOMETRIC', 'GEOM']:
        if param_len == 1:
            p = params[0]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))
        return stats.geom.pmf(x, p)

    elif name in ['GENPOISSON']:
        if param_len == 2:
            t, e = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 2'))
        return t * math.pow(t + e * x, x - 1) * math.exp(-t - e * x) / math.factorial(x)

    elif name in ['HYPERGEOMETRIC', 'HYPER']:
        # SAS -> Python: n_ -> M, r_ -> n, n -> N,
        if param_len == 3:
            n_, r_, n, o = params[0], params[1], params[2], 1
        elif param_len == 4:
            n_, r_, n, o = params[0], params[1], params[2], params[3]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '3 <= len(params) <= 4'))
        return stats.hypergeom.pmf(x, n_, r_, n)

    elif name in ['LAPLACE']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.laplace.pdf(x, teta, lamb)

    elif name in ['LOGISTIC']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if not (teta >= 0 and lamb > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'
                             .format(name, 'params[0] >= 0 and params[1] > 0'))
        return stats.logistic.pdf(x, teta, lamb)

    elif name in ['LOGNORMAL', 'LOGN']:
        # SAS -> Python: teta -> loc, lamb -> s
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if not (teta >= 0 and lamb > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'
                             .format(name, 'params[0] >= 0 and params[1] > 0'))
        return stats.lognorm.pdf(x, s=lamb, loc=teta)

    elif name in ['NEGBINOMIAL', 'NEGB']:
        if param_len == 2:
            p, n = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 2'))
        return stats.nbinom.pmf(x, n, p)

    elif name in ['NORMAL', 'GAUSSIAN', 'GAUSS']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.norm.pdf(x, scale=lamb, loc=teta)

    elif name in ['NORMALMIX']:
        # (x, n, p, m, s) -> (x, n, [p1, p2, ..., pn], [m1, m2, ..., mn], [s1, s2, ..., sn])
        n = params[0]
        if not (n > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[0] > 0'))
        if not (len(params) == n * 3 + 1):
            raise ValueError('Function PDF (the {} distribution) expects len(params) = {} if arg[0] = {} .'
                             .format(name, n * 3 + 1, n))
        # Read parameters:
        p, m, s = list(), list(), list()
        for i in range(n):
            p.append(params[i + 1])
            m.append(params[i + 1 + n])
            s.append(params[i + 1 + 2 * n])
            if s[i] <= 0:
                raise ValueError('Function PDF (the {} distribution) expects standard deviations > 0 (params[{}..{}]).'
                                 .format(name, 1 + 2 * n, 3 * n))
        # Check proportions:
        if sum(p) != 1:
            raise ValueError('Function PDF (the {} distribution) expects the sum of proportions = 1 (params[{}..{}]).'
                             .format(name, 1, n))
        return sum([p[i] * stats.norm.pdf(x, loc=m[i], scale=s[i]) for i in range(n)])

    elif name in ['PARETO']:
        if param_len == 1:
            a, k = params[0], 1
        elif param_len == 2:
            a, k = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (a > 0 and k > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        return 0 if x < k else a * math.pow(k / x, a + 1) / k

    elif name in ['POISSON']:
        if param_len == 1:
            return stats.poisson.pmf(x, params[0])
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))

    elif name in ['T']:
        if param_len == 1:
            df, nc = params[0], 0
        elif param_len == 2:
            df, nc = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (df > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[0] > 0'))
        return stats.t.pdf(x, df, nc)

    elif name in ['TWEEDIE']:
        import tweedie
        if param_len == 1:
            p, mu, phi = params[0], 1, 1
        elif param_len == 2:
            p, mu, phi = params[0], params[1], 1
        elif param_len == 3:
            p, mu, phi = params[0], params[1], params[2]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 1 <= 'len(params) <= 3'))
        return tweedie.tweedie(mu=mu, p=p, phi=phi).pdf(x)

    elif name in ['UNIFORM']:
        if param_len == 0:
            l, r = 0, 1
        elif param_len == 1:
            l, r = params[0], 1
        elif param_len == 2:
            l, r = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if not (l < r):
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 'params[0] < params[1]'))
        return stats.uniform.pdf(x, l, r)

    elif name in ['WALD', 'IGAUSS']:
        if param_len == 1:
            l, m = params[0], 1
        elif param_len == 2:
            l, m = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (l > 0 and m > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        if x < 0:
            return 0
        else:
            return math.sqrt(l / (2 * math.pi * math.pow(x, 3))) * math.exp(l - l * x / 2 - l / 2 / x)

    elif name in ['WEIBULL']:
        if param_len == 1:
            a, l = params[0], 1
        elif param_len == 2:
            a, l = params[0], params[1]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (a > 0 and l > 0):
            raise ValueError('Function PDF (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        return stats.weibull_min.pdf(x, a, loc=0, scale=l)

    else:
        raise NotImplementedError('The {} distribution not implemented yet in PDF function.'.format(name))


def rand(name: str, seed: int, *args: typing.Tuple[float, ...]) -> float:
    name = name.strip().upper()
    arg_len = len(args)

    if name in ['BETA']:
        if arg_len == 2:
            a, b = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))
        if not (a < b):
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'args[0] < args[1]'))
        return stats.beta.rvs(a, b, size=1, random_state=seed)[0]

    elif name in ['BERNOULLI', 'BERN']:
        if not (arg_len == 1 and 0 <= args[0] <= 1):
            raise ValueError('Function RAND (the {} distribution) expects {}.'.
                             format(name, 'len(args) = 1 and 0 <= args[0] <= 1'))
        else:
            p = args[0]
            return stats.bernoulli.rvs(p, size=1, random_state=seed)[0]

    elif name in ['BINOMIAL', 'BINOM']:
        if arg_len == 2:
            p, n = args[0], args[1]
            return stats.binom.rvs(n, p, size=1, random_state=seed)[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))

    elif name in ['CAUCHY']:
        if arg_len != 0:
            raise ValueError('Function RAND (the {} distribution) expects no arguments.'.format(name))
        return stats.cauchy.rvs(size=1, random_state=seed)[0]

    elif name in ['CHISQUARE']:
        if arg_len == 1:
            return stats.chi2.rvs(df=args[0], size=1, random_state=seed)[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['ERLANG']:
        if arg_len == 1:
            return stats.erlang.rvs(a=args[0], size=1, random_state=seed)[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['EXPONENTIAL', 'EXPO']:
        if arg_len == 0:
            sigma = 1
        elif arg_len == 1:
            sigma = args[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 1'))
        return stats.expon.rvs(scale=1 / sigma, size=1, random_state=seed)[0]

    elif name in ['F']:
        if arg_len == 2:
            dfn, dfd = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))
        return stats.f.rvs(dfn, dfd, size=1, random_state=seed)[0]

    elif name in ['GAMMA']:
        if arg_len == 1:
            a, lmd = args[0], 1
        elif arg_len == 2:
            a, lmd = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        return stats.gamma.rvs(a=a, scale=lmd, size=1, random_state=seed)[0]

    elif name in ['GEOMETRIC', 'GEOM']:
        if arg_len == 1:
            p = args[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))
        return stats.geom.rvs(p, size=1, random_state=seed)[0]

    elif name in ['HYPERGEOMETRIC', 'HYPER']:
        # SAS -> Python: n_ -> M, r_ -> n, n -> N,
        if arg_len == 3:
            n_, r_, n = args[0], args[1], args[2]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 3'))
        return stats.hypergeom.rvs(n_, r_, n, size=1, random_state=seed)[0]

    elif name in ['LOGNORMAL', 'LOGN']:
        # SAS -> Python: teta -> loc, lamb -> s
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if not (teta >= 0 and lamb > 0):
            raise ValueError('Function RAND (the {} distribution) expects {}.'
                             .format(name, 'args[0] >= 0 and args[1] > 0'))
        return stats.lognorm.rvs(s=lamb, loc=teta, size=1, random_state=seed)[0]

    elif name in ['NEGBINOMIAL', 'NEGB']:
        if arg_len == 2:
            p, n = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 2'))
        return stats.nbinom.rvs(n, p, size=1, random_state=seed)[0]

    elif name in ['GAUSSIAN', 'NORMAL']:
        if arg_len == 0:
            teta, lamb = 0, 1
        elif arg_len == 1:
            teta, lamb = args[0], 1
        elif arg_len == 2:
            teta, lamb = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if lamb <= 0:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'args[1] > 0'))
        return stats.norm.rvs(scale=lamb, loc=teta, size=1, random_state=seed)[0]

    elif name in ['POISSON']:
        if arg_len == 1:
            return stats.poisson.rvs(args[0], size=1, random_state=seed)[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['T']:
        if arg_len == 0:
            df = 0
        elif arg_len == 1:
            df = args[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 1'))
        if not (df > 0):
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'args[0] > 0'))
        return stats.t.rvs(df, size=1, random_state=seed)[0]

    elif name in ['TABLE']:
        if arg_len > 0:
            x = stats.uniform.rvs(size=1, random_state=seed)
            sum_ = 0
            for i in range(arg_len):
                sum_ += args[i]
                if x <= sum_:
                    return i + 1
            return arg_len + 1
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) > 0'))

    elif name in ['TRIANGLE']:
        if arg_len == 1:
            h = args[0]
            return stats.triang.rvs(h, size=1, random_state=seed)[0]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'len(args) = 1'))

    elif name in ['UNIFORM']:
        if arg_len == 0:
            l, r = 0, 1
        elif arg_len == 1:
            l, r = args[0], 1
        elif arg_len == 2:
            l, r = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '0 <= len(args) <= 2'))
        if not (l < r):
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, 'args[0] < args[1]'))
        return stats.uniform.rvs(l, r, size=1, random_state=seed)[0]

    elif name in ['WEIBULL']:
        if arg_len == 1:
            a, l = args[0], 1
        elif arg_len == 2:
            a, l = args[0], args[1]
        else:
            raise ValueError('Function RAND (the {} distribution) expects {}.'.format(name, '1 <= len(args) <= 2'))
        if not (a > 0 and l > 0):
            raise ValueError('Function RAND (the {} distribution) expects {}.'
                             .format(name, 'args[0] > 0 and args[1] > 0'))
        return stats.weibull_min.rvs(a, loc=0, scale=l, size=1, random_state=seed)[0]

    else:
        raise NotImplementedError('The {} distribution not implemented yet in RAND function.'.format(name))


def quantile(name: str, probability: float, *params: typing.Tuple[float, ...]) -> float:
    name = name.strip().upper()
    param_len = len(params)

    if name in ['BERNOULLI', 'BERN']:
        if not (len(params) == 1 and 0 <= params[0] <= 1):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.
                             format(name, 'len(params) = 1 and 0 <= params[0] <= 1'))
        else:
            p = params[0]
            return stats.bernoulli.ppf(probability, p)

    elif name in ['BETA']:
        if param_len == 0:
            a, b = 0, 1
        if param_len == 1:
            a, b = params[0], 1
        elif param_len == 2:
            a, b = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        return stats.beta.ppf(probability, a, b)

    elif name in ['BINOMIAL', 'BINOM']:
        if param_len == 2:
            return stats.binom.ppf(probability, params[1], params[0])
        else:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'len(params) = 2'))

    elif name in ['CAUCHY']:
        if param_len == 0:
            median, scale = 0, 1
        elif param_len == 1:
            median, scale = params[0], 1
        elif param_len == 2:
            median, scale = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        return stats.cauchy.ppf(probability, median, scale)

    elif name in ['CHISQUARE']:
        if param_len == 1:
            return stats.chi2.ppf(probability, params[0])
        else:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))

    elif name in ['EXPONENTIAL', 'EXPO']:
        if param_len == 0:
            lmb = 1
        elif param_len == 1:
            lmb = params[0]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 1'))
        return stats.expon.ppf(probability, scale=1 / lmb)

    elif name in ['F']:
        if param_len == 2:
            dfn, dfd, nc = params[0], params[1], 0
        elif param_len == 3:
            dfn, dfd, nc = params[0], params[1], params[2]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '2 <= len(params) <= 3'))
        # TODO Here is also not supported feature, but test case works fine:
        if not (nc == 0):
            raise NotImplementedError('Function QUANTILE (the {} distribution) does not support {}.'
                                      .format(name, 'nc != 0'))
        return stats.f.ppf(probability, dfn, dfd)

    elif name in ['GAMMA']:
        if param_len == 1:
            a, lmd = params[0], 1
        elif param_len == 2:
            a, lmd = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        return stats.gamma.ppf(probability, a=a, scale=lmd)

    elif name in ['GEOMETRIC']:
        if param_len == 1:
            p = params[0]
        else:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))
        return stats.geom.ppf(probability, p)

    elif name in ['HYPERGEOMETRIC', 'HYPER']:
        # SAS -> Python: n_ -> M, r_ -> n, n -> N,
        if param_len == 3:
            n_, r_, n, o = params[0], params[1], params[2], 1
        elif param_len == 4:
            n_, r_, n, o = params[0], params[1], params[2], params[3]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '3 <= len(params) <= 4'))
        # TODO Here is also not supported feature:
        if not (o == 1):
            raise NotImplementedError('Function QUANTILE (the {} distribution) does not support {}.'
                                      .format(name, 'o != !'))
        return stats.hypergeom.ppf(probability, n_, r_, n)

    elif name in ['LAPLACE']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.laplace.ppf(probability, teta, lamb)

    elif name in ['LOGISTIC']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.logistic.ppf(probability, teta, lamb)

    elif name in ['LOGNORMAL', 'LOGN']:
        # SAS -> Python: teta -> loc, lamb -> s
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.lognorm.ppf(probability, s=lamb, loc=teta)

    elif name in ['NEGBINOMIAL', 'NEGB']:
        if param_len == 2:
            p, n = params[0], params[1]
        else:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'len(params) = 2'))
        return stats.nbinom.ppf(probability, n, p)

    elif name in ['NORMAL', 'GAUSS', 'GAUSSIAN']:
        if param_len == 0:
            teta, lamb = 0, 1
        elif param_len == 1:
            teta, lamb = params[0], 1
        elif param_len == 2:
            teta, lamb = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if lamb <= 0:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[1] > 0'))
        return stats.norm.ppf(probability, scale=lamb, loc=teta)

    elif name in ['NORMALMIX']:
        # (x, n, p, m, s) -> (x, n, [p1, p2, ..., pn], [m1, m2, ..., mn], [s1, s2, ..., sn])
        n = params[0]
        if not (n > 0):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[0] > 0'))
        if not (len(params) == n * 3 + 1):
            raise ValueError('Function QUANTILE (the {} distribution) expects len(params) = {} if arg[0] = {} .'
                             .format(name, n * 3 + 1, n))
        # Read parameters:
        p, m, s = list(), list(), list()
        for i in range(n):
            p.append(params[i + 1])
            m.append(params[i + 1 + n])
            s.append(params[i + 1 + 2 * n])
            if s[i] <= 0:
                raise ValueError(
                    'Function QUANTILE (the {} distribution) expects standard deviations > 0 (params[{}..{}]).'
                        .format(name, 1 + 2 * n, 3 * n))
        # TODO - Check proportions:
        # if sum(p) != 1:
        #     raise ValueError('Function QUANTILE (the {} distribution) expects the sum of proportions = 1 (params[{}..{}]).'
        #                          .format(name, 1, n))
        ps = [stats.norm.ppf(probability, loc=m[i], scale=s[i]) for i in range(n)]
        if n != 1:
            return sum([p[i] * stats.norm.ppf(probability, loc=m[i], scale=s[i]) for i in range(n)])
        else:
            return stats.norm.ppf(probability, loc=m[0], scale=s[0])

    elif name in ['PARETO']:
        if param_len == 0:
            a, k = 0, 1
        elif param_len == 1:
            a, k = params[0], 1
        elif param_len == 2:
            a, k = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (a > 0 and k > 0):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        return k * a / (1 - probability)

    elif name in ['POISSON']:
        if param_len == 1:
            return stats.poisson.ppf(probability, params[0])
        else:
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'len(params) = 1'))

    elif name in ['TWEEDIE']:
        import tweedie

        if param_len == 1:
            p, mu, phi = params[0], 1, 1
        elif param_len == 2:
            p, mu, phi = params[0], params[1], 1
        elif param_len == 3:
            p, mu, phi = params[0], params[1], params[2]
        else:
            raise ValueError('Function PDF (the {} distribution) expects {}.'.format(name, 1 <= 'len(params) <= 3'))
        return tweedie.tweedie(mu=mu, p=p, phi=phi).ppf(probability)


    elif name in ['T']:
        if param_len == 1:
            df, nc = params[0], 0
        elif param_len == 2:
            df, nc = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (df > 0):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[0] > 0'))
        return stats.t.ppf(probability, df, nc)

    elif name in ['UNIFORM']:
        if param_len == 0:
            l, r = 0, 1
        elif param_len == 1:
            l, r = params[0], 1
        elif param_len == 2:
            l, r = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '0 <= len(params) <= 2'))
        if not (l < r):
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, 'params[0] < params[1]'))
        return stats.uniform.ppf(probability, l, r)

    elif name in ['WALD', 'IGAUSS']:
        if param_len == 1:
            l, m = params[0], 1
        elif param_len == 2:
            l, m = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (l > 0 and m > 0):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        return stats.wald.ppf(probability, loc=m, scale=l)

    elif name in ['WEIBULL']:
        if param_len == 1:
            a, l = params[0], 1
        elif param_len == 2:
            a, l = params[0], params[1]
        else:
            raise ValueError(
                'Function QUANTILE (the {} distribution) expects {}.'.format(name, '1 <= len(params) <= 2'))
        if not (a > 0 and l > 0):
            raise ValueError('Function QUANTILE (the {} distribution) expects {}.'
                             .format(name, 'params[0] > 0 and params[1] > 0'))
        return stats.weibull_min.ppf(probability, a, loc=0, scale=l)

    else:
        raise NotImplementedError('The {} distribution not implemented yet in the function QUANTILE.'.format(name))


def rantbl(seed: int, *p: typing.Tuple[float, ...]) -> float:
    n = len(p)
    singletons = [i + 1 for i in range(n + 1)]
    probabilities = [p[i] if i < n else 1 - sum(p) for i in range(n + 1)]
    np.random.seed(seed)
    return np.random.choice(a=singletons, p=probabilities, size=1, replace=False)[0]
