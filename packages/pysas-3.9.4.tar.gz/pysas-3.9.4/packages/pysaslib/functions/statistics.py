#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#

# Category: Descriptive Statistics
import math
import typing


def max(data: typing.List[float]) -> float:
    result = - math.inf
    for x in data:
        if result < x:
            result = x
    return math.nan if result == - math.inf else result


def mean(data: typing.List[float]) -> float:
    sum = 0
    count = 0
    for x in data:
        if not math.isnan(x):
            sum += x
            count += 1
    return sum / count if count > 0 else math.nan


def min(data: typing.List[float]) -> float:
    result = math.inf
    for x in data:
        if x < result:
            result = x
        elif math.isnan(x):
            return math.nan
    return math.nan if result == math.inf else result
