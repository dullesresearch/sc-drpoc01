#
# PySAS version 3a286549-3.9.4/32121b93/20210511210538
# Use is subject to the PySAS Software License Agreement.
#
import datetime as dt


def loop(start, by=1.0, to=None, while_=lambda: True, until=lambda: False):
    """
    a range generator matching DO loop logic
    """
    if by <= 0:
        while start >= to:
            if not while_():
                return
            yield start
            if until():
                return
            start += by
    else:
        while start <= to:
            if not while_():
                return
            yield start
            if until():
                return
            start += by


def get_arg_info(func, pname=None):
    """
    Returns parameter annotation(s) for a function
    :param func: a function
    :param pname: parameter name
    :return: type of parameter if defined, ValueError raised otherwise
    """
    args = func.__code__.co_varnames
    anns = func.__annotations__

    if pname is None:
        # Return dictionary with all annotations
        return anns
    elif pname == 'return' or pname in args:
        arginfo = anns.get(pname)
        if not arginfo:
            raise KeyError('Argument {} in function {} has no annotations defined.', pname, func.__name__)
        return arginfo
    else:
        raise ValueError('Function {} has no argument with name {}'.format(func.__name__, pname))


def missing(arg: str) -> bool:
    return arg is None or len(str.strip()) == 0


def days(days: float):
    return dt.date(1970, 1, 1) + dt.timedelta(days=days)
