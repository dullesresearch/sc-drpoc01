### Running PySAS-generated code in conda environments

```shell
conda env create -n pysas -f $PYSAS_HOME/packages/conda/environment.yml
conda activate pysas
```