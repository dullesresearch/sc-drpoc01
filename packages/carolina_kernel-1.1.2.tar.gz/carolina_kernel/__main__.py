"""
 * Copyright 2017 Dulles Research LLC.
 * All Rights Reserved.
 * Dulles Research CONFIDENTIAL AND TRADE SECRET.
 *
"""

from ipykernel.kernelapp import IPKernelApp
from .kernel import CarolinaKernel

IPKernelApp.launch_instance(kernel_class=CarolinaKernel)
