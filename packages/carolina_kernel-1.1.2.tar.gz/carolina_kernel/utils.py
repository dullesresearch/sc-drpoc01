

def add_highlights(original):
    """
    Inserts ANSI color codes 'ESC[n{;n}' to highlight the text.
    See https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
    :param original: original text
    :return: colored text
    """
    if original.startswith('NOTE:'):
        line = '\033[30m' + original + '\033[39m'  # black
    elif original.startswith('WARN:') | original.startswith('WARN :') | original.startswith('WARNING:'):
        line = '\033[33m' + original + '\033[39m'  # blue
    elif original.startswith('UNSUPPORTED:'):
        line = '\033[33m' + original + '\033[39m'  # magenta
    elif original.startswith('UNDOCUMENTED:'):
        line = '\033[33m' + original + '\033[39m'  # magenta
    elif original.startswith('ERROR:'):
        # line = '\033[31m' + line + '\033[39m' # red
        line = '\033[38;2;255;0;0m' + original + '\033[39m'  # bright red
    else:
        line = '\033[38;2;85;85;85m' + original + '\033[39m'
    return line

def print_log_line(line):
    print(add_highlights(line))

def html_lst(lines):
    from IPython.display import HTML
    return HTML('<html><body><pre>' + '\n'.join(lines) + '</pre></body></html>')
