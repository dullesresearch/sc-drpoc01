from IPython.core.getipython import get_ipython
from IPython.core.interactiveshell import InteractiveShell
from IPython.core.magic import cell_magic, Magics, magics_class

from .session import CarolinaSession
from .utils import html_lst
from .utils import print_log_line


class SessionContainer:
    def __init__(self, proxy):
        self.proxy = proxy


@magics_class
class CarolinaMagics(Magics):
    def __init__(self, shell: InteractiveShell):
        super(CarolinaMagics, self).__init__(shell)

    def get_kernel_type(self):
        try:
            ip = get_ipython()
            kernel_type = ip.kernel.language_info['name']
        except:
            kernel_type = ''
        return kernel_type

    def run_carolina(self, code):
        session = self.get_session('carolina')
        session.submit(code, print_log_line)
        return html_lst(session.get_results()['lst'])

    def run_pysas(self, code):
        session = self.get_session('pysas.cmd')
        session.submit(code, print_log_line)
        results = session.get_results()
        self.create_new_cell('\n'.join(results['python']))
        return html_lst(results['lst'])

    def get_session(self, executable):
        key = 'carolina_session_' + executable + '_'
        try:
            session = self.shell.user_ns[key].proxy
        except:
            session = CarolinaSession(executable=executable)
            self.shell.push({key: SessionContainer(session)}, True)
        return session

    @staticmethod
    def parse_magic_args(line):
        silent = False
        args = line.split()
        if len(args) > 0:
            for a in args:
                if a == '--silent' or a == '-s':
                    silent = True
                    break
        return silent

    @staticmethod
    def create_new_cell(contents):
        shell = get_ipython()
        payload = dict(
            source='set_next_input',
            text=contents,
            replace=False,
        )
        shell.payload_manager.write_payload(payload, single=False)

    @cell_magic
    def pysas(self, line='', cell=None):
        silent = self.parse_magic_args(line)
        return self.run_pysas(cell)

    @cell_magic
    def sas2python(self, line='', cell=None):
        return self.pysas(line, cell)

    @cell_magic
    def carolina(self, line='', cell=None):
        return self.run_carolina(cell)


def load_ipython_extension(ipython):
    ipython.register_magics(CarolinaMagics)
    print('Carolina magics module has been registered.')
