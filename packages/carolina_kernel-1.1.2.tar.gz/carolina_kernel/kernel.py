import os
import sys

from metakernel import MetaKernel

from .session import logger
from .session import CarolinaSession
from .utils import *


class CarolinaKernel(MetaKernel):
    """
    Carolina kernel for IPython based on MetaKernel.
    """

    kernel_json = {
        "argv": [sys.executable, "-m", "pysaslib.kernel", "-f", "{connection_file}"],
        "display_name": "Carolina",
        "codemirror_mode": "sas",
        "language": "sas",
        "name": "carolina"
    }

    carolina_session = None
    implementation = 'carolina_kernel'
    implementation_version = '1.0'
    language = 'sas'
    language_version = '9'
    banner = 'Carolina Kernel'
    language_info = \
        {
            'name': 'sas',
            'mimetype': 'text/x-sas',
            'codemirror_mode': 'sas',
            'file_extension': '.sas',
        }


    def __init__(self, **kwargs):
        super(CarolinaKernel, self).__init__(**kwargs)
        logger.info('Carolina kernel started as process #%s.', str(os.getpid()))
        from .magics_mk import CarolinaMagics_mk
        self.register_magics(CarolinaMagics_mk)

    def do_apply(self, content, bufs, msg_id, reply_metadata):
        pass

    def do_clear(self):
        pass

    def get_usage(self):
        return "This is the Carolina(tm) kernel."

    @staticmethod
    def code(code):
        if not code.strip():
            return None
        return code

    def do_execute_direct(self, code, silent=False):

        code = self.code(code)
        if code is None:
            return {'status': 'ok', 'execution_count': self.execution_count,
                    'payload': [], 'user_expressions': {}}

        if self.carolina_session is None:
            # launch Carolina in a separate OS process
            try:
                self.carolina_session = CarolinaSession()
            except Exception as e:
                self.carolina_session = None
                print(e)
                return {'status': 'failed', 'execution_count': self.execution_count,
                        'payload': [], 'user_expressions': {}}

        self.carolina_session.submit(code, print_log_line)
        results = self.carolina_session.get_results()

        # check Carolina is still alive
        log_is_alive = self.carolina_session.art_log.is_alive()
        lst_is_alive = self.carolina_session.art_lst.is_alive()
        if not log_is_alive:
            logger.critical('Carolina LOG helper was found finished.')
            print('Carolina LOG was closed')
        if not lst_is_alive:
            logger.critical('Carolina PRINT helper was found finished.')
            print('Carolina LST was closed')
        alive = log_is_alive and lst_is_alive
        if not alive:
            if self.carolina_session:
                print('Carolina kernel has been stopped. Restart the kernel to continue using Carolina.')
                self.carolina_session.stop()
                self.carolina_session = None
            else:
                print(add_highlights('WARNING: Session abnormally finished.'))
        return html_lst(results['lst'])

    def do_shutdown(self, restart):
        logger.info('Shutting down Carolina kernel...')
        if self.carolina_session:
            self.carolina_session.stop()
            self.carolina_session = None
        else:
            logger.info('No carolina session is active')
        return super(CarolinaKernel, self).do_shutdown(restart=restart)

