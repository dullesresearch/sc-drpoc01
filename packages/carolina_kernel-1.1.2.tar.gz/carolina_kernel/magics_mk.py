from __future__ import print_function

from IPython.core.display import HTML
from metakernel import Magic, option

from .session import CarolinaSession
from .utils import html_lst
from .utils import print_log_line


class CarolinaMagics_mk(Magic):

    def __init__(self, *args, **kwargs):
        super(CarolinaMagics_mk, self).__init__(*args, **kwargs)
        self.session = None

    def get_kernel_type(self):
        try:
            kernel_type = self.kernel.language_info['name']
        except:
            kernel_type = ''
        return kernel_type

    def run_pysas(self, code, silent=False):
        if self.session is None:
            self.session = CarolinaSession(executable='pysas', env_home="PYSAS_HOME")

        self.session.submit(code, print_log_line)
        results = self.session.get_results()

        if 'python' in results:
            cont = ''
            if self.get_kernel_type() != 'python':
                cont += '%%python\n'
            cont += '\n'.join(results['python'])
            self.kernel.payload.append({"source": "set_next_input",
                                        "text": cont})
        return results['lst']

    @option(
        "-s", "--silent", action="store_true", default=True,
        help="generate Python code in the silent mode"
    )
    def cell_pysas(self, silent=False):
        self.evaluate = False
        self.retval = self.run_pysas(self.code, silent=silent)

    def post_process(self, retval):
        return html_lst(self.retval)


def register_magics(kernel):
    kernel.register_magics(CarolinaMagics_mk)
