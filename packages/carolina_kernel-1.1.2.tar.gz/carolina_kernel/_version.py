"""
 * Copyright 2017 Dulles Research LLC.
 * All Rights Reserved.
 * Dulles Research CONFIDENTIAL AND TRADE SECRET.
 *
"""

version_info = (1, 1, 2)
__version__ = '.'.join(map(str, version_info))