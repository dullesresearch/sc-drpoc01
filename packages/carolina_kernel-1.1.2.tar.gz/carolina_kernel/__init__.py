"""
 * Copyright 2017 Dulles Research LLC.
 * All Rights Reserved.
 * Dulles Research CONFIDENTIAL AND TRADE SECRET.
 *
"""

from ._version import version_info, __version__
