import os
import logging.config
import signal
import string
import sys
import random
import time

from threading import Thread
from queue import Queue
from .utils import *

os_windows = os.getenv('windir', None) and os.getenv('OS', '').startswith('Windows')

if os_windows:
    from subprocess import PIPE, Popen, CREATE_NEW_PROCESS_GROUP
else:
    from subprocess import PIPE, Popen

__conf_file__ = 'kernel_logging.conf'

if os.path.isfile(__conf_file__):
    try:
        logging.config.fileConfig(__conf_file__)
    except Exception as e:
        print(e)
        print('Unable to configure log file using ' + __conf_file__)
logger = logging.getLogger(__name__)

enc_remap = {
    "wlatin1": "windows-1252"
}

appl_timeout = 1.0  # seconds
timeout_stop = 2.0  # seconds


class AsyncReaderThread(Thread):
    """
    Helper class to implement asynchronous reading of a stream
    in a separate thread. Pushes read lines on an async queue to
    be consumed in another thread.
    """

    def __init__(self, fd, thread_name, encoding='utf8'):
        """
        :param fd: file descriptor
        """
        assert callable(fd.readline)
        Thread.__init__(self, daemon=True, name=thread_name)
        self.queue = Queue()
        self._fd = fd
        self._encoding = encoding
        self.start()

    def run(self):
        """
        The body of the thread: read lines and put them on the queue.
        """
        for line in iter(self._fd.readline, b''):
            s = line.decode(encoding=self._encoding, errors='replace').replace('\r', '').replace('\n', '')
            logger.debug("put: " + s)
            self.queue.put(s)

    def eof(self):
        """
        Check whether there is no more content to expect.
        """
        return not self.is_alive() and self.queue.empty()


class CarolinaSession:
    """
    Controls Carolina process, including ID and IO helpers.
    """
    art_lst = None
    art_log = None
    process = None

    def __init__(self, env_home='CAROLINA_HOME', executable='carolina',
                 args=['--nonumber', '--nodate', '-code', '.carolina-codegen'], ext_args=[]):
        self.encoding = 'utf8'
        self.boundary = "#{}#-Carolina-" + ''.join(random.choice(string.ascii_lowercase) for i in range(10))
        self.home = env_home
        self.executable = executable
        self.args = args
        self.ext_args = ext_args
        self.results = {}
        self._start()

    def _start(self):
        home = os.getenv('%s' % self.home, None)
        logger.debug('%s=%s', self.home, home)
        if not home:
            logger.debug('%s is not defined' % self.home)
            home = ''  # system specific search is assumed
        path = os.path.join(home, self.executable)

        c_encoding = os.getenv('CAROLINA_ENCODING', self.encoding)
        self.encoding = enc_remap[c_encoding] if c_encoding in enc_remap else c_encoding
        logger.debug('CAROLINA_ENCODING=%s', c_encoding)
        logger.debug('Starting Carolina \'%s\'', path)
        command = [path] + self.args + ['-log', '-', '-print', '-', '-sysin', '-', '-sentinel', self.boundary,
                                        '--encoding', c_encoding] + self.ext_args

        python_exe = sys.executable
        if python_exe:
            command = command + ['-set', 'PYTHON', python_exe]

        logger.debug("Popen: " + ' '.join(command))
        if os_windows:
            self.process = Popen(command, stdout=PIPE, stderr=PIPE, stdin=PIPE, creationflags=CREATE_NEW_PROCESS_GROUP)
        else:
            self.process = Popen(command, stdout=PIPE, stderr=PIPE, stdin=PIPE)

        if self.process is None:
            logger.critical('Failed to start Carolina ' + path)
        else:
            logger.info('Carolina started as process #%s.', str(self.process.pid))
            self.art_lst = AsyncReaderThread(self.process.stdout, "process-stdout", self.encoding)
            self.art_log = AsyncReaderThread(self.process.stderr, "process-stderr", self.encoding)
            logger.debug('Carolina I/O readers started.')

    def stop(self):
        logger.debug('Stopping Carolina session ...')
        try:
            logger.debug('Terminating Carolina process ...')
            self.process.stdin.close()

            # on windows terminate() calls TerminateProcess, which does not run shutdown hooks
            # self.process.terminate()
            term_signal = signal.CTRL_C_EVENT if os_windows else signal.SIGTERM
            logger.debug("sending: " + str(term_signal))
            self.process.send_signal(term_signal)

            logger.debug('Waiting for LST helper to finish ...')
            self.art_lst.join(timeout_stop)
            logger.debug('Waiting for LOG helper to finish ...')
            self.art_log.join(timeout_stop)

            self.process.wait(timeout=timeout_stop)
            self.process.stdout.close()
            self.process.stderr.close()
            logger.info('Carolina session stopped.')
        except:
            logger.exception('Failed to stop Carolina process. Attempting to kill the process.')
            self.process.kill()
        finally:
            self.process = None

    def submit(self, code, log_handler):
        """
        Copies code to Carolina's stdin.
        :param self:
        :param code: code to submit.
        :param log_handler: function to handle each line of the log
        """
        logger.debug('Sending code to Carolina ...')
        logger.debug('Code: \n%s', code)

        ba = bytes(code + '\n' + self.boundary + '\n', encoding=self.encoding)
        logger.debug('Number of bytes prepared: %d', ba.__len__())
        if sys.version_info[0] >= 3:
            assert self.process.stdin.writable()
            logger.debug('stdin check #1 passed')
        assert callable(self.process.stdin.write)
        logger.debug('stdin check #2 passed')
        cn = self.process.stdin.write(ba)
        logger.debug('Number of bytes sent: %d', cn)
        # flush the stream to let Carolina read a sentinel
        self.process.stdin.flush()
        logger.info('Code has been sent to Carolina')

        self._process_log(log_handler)

    def _process_log(self, log_handler):
        """
        Provides Carolina stderr stream ("LOG") to Jupyter.
        :param self:
        :param log_handler: function to print
        :return:
        """
        logger.debug('Extracting Carolina LOG ...')
        cnt = 0
        attach_key = None
        self.results = {}
        while not self.art_log.eof():
            line = None
            # empty the queue and process everything from there
            while not self.art_log.queue.empty():
                line = self.art_log.queue.get()
                if line == self.boundary:
                    break
                elif line.startswith(self.boundary + ":"):
                    attach_key = line.split(":")[1]
                    self.results[attach_key] = []
                else:
                    if attach_key is not None:
                        self.results[attach_key].append(line)
                    else:
                        log_handler(line)

            # logger.debug('LOG queue has been emptied')
            if line == self.boundary:
                break
            else:
                time.sleep(0.01)

        logger.debug('LOG extracted into %d bytes', cnt)

    def get_results(self):
        logger.debug('Extracting Carolina results')
        lst_lines = []
        while not self.art_lst.queue.empty():
            lst_lines.append(self.art_lst.queue.get())

        self.results['lst'] = lst_lines
        return self.results

