A Jupyter kernel for Carolina
=======================================

Installation instructions::

1. Install Carolina application.

2. Set the environment variable CAROLINA_HOME pointing to the Carolina
home directory. If this variable is not set, the kernel will use the server
side CAROLINA_HOME variable or default to the carolina executable on PATH.

3. Set the environment variable JAVA_HOME pointing to the JVM home directory.
If this variable is not set, the kernel will use the server side JAVA_HOME
variable.

4. Install the Carolina kernel for Jupyter with the next command:

    4.1. In shared location:

        pip install carolina_kernel-1.0.8.tar.gz

    4.2. User location (--no-binary option is required with pip v.9.0.1 ):

        pip install     --no-binary=carolina_kernel carolina_kernel-1.0.8.tar.gz

6. Verify the kernel has been installed:

    pip show carolina_kernel

    A typical response will look like that:

    Name: carolina-kernel
    Version: 1.0.8
    Summary: A Carolina kernel for Jupyter
    Home-page: http://www.dullesresearch.com/
    Author: Dulles Research, LLC
    Author-email: support@dullesresearch.com
    Location: /<python env path>/site-packages
    Requires: metakernel, pygments, IPython, jupyter

7. Verify installed kernel is recognized by the Jupyter:

    jupyter kernelspec list

    A typical response will look like that:

    Available kernels:
      python3     /<jupyter path>/python3
      carolina    /<jupyter path>/kernels/carolina


Usage instructions::

1. Choose new Carolina notebook to start.

2. Type SAS code in a cell.

3. Run the code in the cell. The program execution log is displayed in the
cell output area as the program code runs. After the execution, the program
code listing, if any, is displayed in the Out area of the cell.

4. The Carolina kernel is based on `MetaKernel <http://pypi.python.org/pypi/metakernel>`_,
and includes the standard set of magics.

5. It is also possible to run SAS code in a Python notebook using a custom magic cell %%carolina.

    5.1. In a Python notebook create a new cell, type and execute the command
             %reload_ext carolina_kernel.magics
    5.2. Create one more cell, and type there %%carolina in the first line. Then type your SAS code under %%carolina.
    5.3. Run the code in the cell.


Cleanup (uninstall) instructions::

1. Remove kernel from Jupyter kernel listings.

    jupyter kernelspec remove carolina

2. Remove kernel software:

    pip uninstall carolina_kernel

