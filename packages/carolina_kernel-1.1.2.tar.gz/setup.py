"""
 * Copyright 2017 Dulles Research LLC.
 * All Rights Reserved.
 * Dulles Research CONFIDENTIAL AND TRADE SECRET.
 *
"""

try:
    from setuptools import setup, find_packages
except ImportError:
    from distutils.core import setup, find_packages
from distutils.command.install import install
from distutils import log
from carolina_kernel._version import __version__
import json
import os
import sys
import tempfile

__svem_flag__ = '--single-version-externally-managed'
if __svem_flag__ in sys.argv:
    sys.argv.remove(__svem_flag__)

__uk_flag__ = '--user'  # pip option, see https://pip.pypa.io/en/stable/reference/pip_install/#options
__uk__ = __uk_flag__ in sys.argv  # TODO because of bug in pip v.9.0.1, option --no-binary=carolina_kernel must be used to force appearance of the option

__ip_flag__ = '--ipython'  # wrapped option of pip --install-option <options>, see https://pip.pypa.io/en/stable/reference/pip_install/#options
__ip__ = False  # TODO __ip_flag__ in sys.argv

kernel_json = {
    "argv": [sys.executable, "-m", "carolina_kernel", "-f", "{connection_file}"],
    "display_name": "Carolina",
    "codemirror_mode": "sas",
    "language": "sas",
}

if sys.version_info[:2] >= (3, 2):
    tempdir = tempfile.TemporaryDirectory()
    temppath = tempdir.name
else:
    tempdir = None
    temppath = tempfile.mkdtemp()


class InstallWithKernelspec(install):

    user_options = install.user_options + [
        ('carolina-home=', None, 'Path to Carolina installation (CAROLINA_HOME env variable)'),
        ('pysas-home=', None, 'Path to PySAS installation (PYSAS_HOME env variable)'),
        ('java-home=', None, 'Path Java installation for use by Carolina (JAVA_HOME env variable)')
    ]

    def initialize_options(self):
        install.initialize_options(self)
        self.carolina_home = None
        self.pysas_home = None
        self.java_home = None

    def finalize_options(self):
        install.finalize_options(self)
        if self.carolina_home is None and self.pysas_home is not None:
            self.carolina_home = os.path.join(self.pysas_home, 'carolina')

    def run(self):
        try:
            if __ip__:
                from IPython.kernel.kernelspec import install_kernel_spec
            else:
                from jupyter_client.kernelspec import install_kernel_spec
        except ImportError:
            raise Exception(str.format("Please install %s before continuing", 'IPython' if __ip__ else 'Jupyter'))

        # Regular installation
        install.run(self)

        # Now write the kernelspec
        self.writeKernelSpec(temppath)
        log.info('files copied to kernel:')
        for i in os.listdir(temppath):
            log.info(i)
        try:
            prefix = None
            if "CONDA_BUILD" in os.environ:
                prefix = sys.prefix
            install_kernel_spec(temppath, 'Carolina', user=__uk__, prefix=prefix, replace=True)
            log.info("Carolina Kernel installed as %s package", 'user' if __uk__ else 'superuser')
        finally:
            if tempdir is None:
                import shutil as su
                su.rmtree(temppath)
            else:
                tempdir.cleanup()

    def writeKernelSpec(self, path):
        log.info('Installing Jupyter kernel spec')
        # capture current CAROLINA_HOME for the kernel
        home = self.carolina_home if self.carolina_home else os.getenv('CAROLINA_HOME', None)
        if home:
            env = kernel_json.get('env', {})
            env.update({'CAROLINA_HOME': home})
            kernel_json.update({'env': env})
            log.info('Carolina installation at "%s" is assigned.', home)
        else:
            log.warn('Server side \'CAROLINA_HOME\' setting will be used for Carolina installation.')

        home = self.pysas_home if self.pysas_home else os.getenv('PYSAS_HOME', None)
        if home:
            env = kernel_json.get('env', {})
            env.update({'PYSAS_HOME': home})
            kernel_json.update({'env': env})
            log.info('PySAS installation at "%s" is assigned.', home)
        else:
            log.warn('Server side \'PYSAS_HOME\' setting will be used for Carolina installation.')

        # capture current JAVA_HOME for the kernel
        home = self.java_home if self.java_home else os.getenv('JAVA_HOME', None)
        if home:
            env = kernel_json.get('env', {})
            env.update({'JAVA_HOME': home})
            kernel_json.update({'env': env})
            log.info('Java installation at "%s" is assigned.', home)
        else:
            log.warn('Server side \'JAVA_HOME\' setting will be used by Carolina kernel.')
        # create temp copy of kernel files
        os.chmod(path, 0o755)  # Starts off as 700, not user readable
        with open(os.path.join(path, 'kernel.json'), 'w') as f:
            json.dump(kernel_json, f, sort_keys=True, indent=4)


setup(name='carolina_kernel',
      version=__version__,
      description='A Carolina kernel for Jupyter',
      long_description=open('README.rst', 'rb').read().decode('utf-8'),
      platforms="Linux, Windows",
      license='Dulles Research, LLC',
      author='Dulles Research, LLC',
      author_email='support@dullesresearch.com',
      url='http://www.dullesresearch.com/',
      packages=find_packages(),
      cmdclass={'install': InstallWithKernelspec},
      package_data={'': [], 'carolina_kernel': ['data/*.png']},
      data_files=[(temppath, ['carolina_kernel/data/logo-64x64.png'])],
      install_requires=['metakernel>=0.14.0',
                        "subprocess32; os_name=='posix' and python_version<'3'"],
      classifiers=[
          'License :: Other/Proprietary License',
          'Programming Language :: Python :: 3',
          'Programming Language :: Python :: 2',
          'Framework :: IPython' if __ip__ else 'Framework :: Jupyter']
      )
